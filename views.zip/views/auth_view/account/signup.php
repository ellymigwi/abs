 <style>
 
 .validates{
	 font-weight:none; color:#929294; font-family:Verdana, Geneva, sans-serif; font-size:13px; text-transform:none;
 }
 
 </style>
 <!-- HOME --><!-- Breadcrumps -->
	<section message class="breadcrumbs">
		<div class="row">
			<div class="container">
				<div class="col-sm-6">
					<h1>Register</h1>
                </div>
				<div class="col-sm-6">
					<ol class="breadcrumb">
						<li>You are here: </li>
						<li><a href="<?php echo base_url('auth/index/');?>">Home</a> </li>
						<li>Pages </li>
						<li class="active">Register</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Breadcrumps -->


	<!-- Register -->
	<section class="Register section_sapces" style="margin-top: 20px;">
		<div class="row ">
			<div class="container">
				<div class="section-title margin-b30">
					<h2>Register</h2>
                </div>
				<div class="col-sm-12">
					<div class="Register-form-panel">
						<div class="row">
							<div class="col-sm-12 col-md-8 center-block register-form padding-b30 padding-t30 bg_gray border shadow">
								<div class="form">
                                
                                <div class="message p-top30 margin-bottom0"> </div>
                                <div id="outer_container">

                                	
										<form  id="signup-form" action="signin.html" class="login-form clearfix ">

									<div id="div1" style="display: block">
	                                    <input type="hidden" name="type" id="type" value="students" />
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">First Name <code>*</code><small></small></span></label><br />
												<input type="text" class="form-control margin-bottom-15" name="user_firstname" id="form-user_firstname" placeholder="Enter Firstname"   > </div>
											<div class="col-sm-6">
	                                        	<label for="form-user_lastname" class="form-label" style="float:left"><span class="validates">Last Name <code>*</code><small></small></span></label><br />
												<input type="text" class="form-control margin-bottom-15" name="user_lastname" id="form-user_lastname" placeholder="Enter Lastname" > </div>
											<div class="col-sm-6">
	                                        	<label for="form-user_email" class="form-label" style="float:left"><span class="validates">Email <code>*</code><small></small></span></label><br />
												<input  type="text"  class="form-control margin-bottom-15" name="user_email" id="form-user_email" placeholder="Enter Valid Email Address"> </div>
	                                        <div class="col-sm-6">
	                                        <label for="form-user_mobile" class="form-label" style="float:left"><span class="validates">Mobile <code>*</code><small></small></span></label><br />
											  <input type="text" class="form-control margin-bottom-15" name="user_mobile" id="form-user_mobile" placeholder="Enter Mobile Number" > </div>
											<div class="col-sm-6">
	                                         <label for="form-user_gender" class="form-label" style="float:left"><span class="validates">Gender <code>*</code><small></small></span></label><br />
											  <select class="form-control margin-bottom-15" name="user_gender" id="form-user_gender"  >
	                                          	<option value="" selected="selected">--Select Gender --</option>
	                                            <option value="Male">Male</option>
	                                             <option value="Female">Female</option>
										      </select>
									        </div>
											<div class="col-sm-6">
	                                        <label for="form-user_country" class="form-label" style="float:left"><span class="validates">Country <code>*</code><small></small></span></label><br />
											 <select class="form-control margin-bottom-15" name="user_country" id="form-user_country">
	                                          	<option value="" selected="selected">--Select Country --</option>
	                                            <?php
												
													foreach($countries as $row){
												?>
	                                            
	                                            	<option value="<?=$row->id; ?>"><?=$row->countryname; ?></option>
	                                            
	                                            <?php
												
													}
												?>
										      </select>
	                                        </div>
											<div class="col-sm-6">
	                                         	<label for="form-user_password" class="form-label" style="float:left"><span class="validates">Password <code>*</code><small></small></span></label><br />
												<input type="password" class="form-control margin-bottom-15" name="user_password" id="form-user_password" value="<?php echo set_value('user_password'); ?>"  placeholder="Enter Password" > </div>
											<div class="col-sm-6">
	                                        	<label for="form-password-conf" class="form-label" style="float:left"><span class="validates">Password <code>*</code><small></small></span></label><br />
												<input type="password" class="form-control margin-bottom-30" name="password-conf"   id="form-password-conf"  value="<?php echo set_value('password-conf'); ?>" placeholder="Confirm Password"> 
                                                </div>
	                                            <div class="col-sm-6" style="margin-left:23%;">
												
	                                             <label for="form-agreeterms" class="form-label"><small></small> </label><br />
	                                             <input id="agree" name="agreeterms" type="checkbox" checked="checked"> <code>*</code> <b>I accept</b> <a href="#">Terms and Conditions</a>
	                                             
	                                           </div>
	                                            
											<div class="col-sm-12 text-center">
												<button class="btn btn-new btn-lg col-sm-8 col-xs-12 center-block  margin-bottom-15 btn-next1">Next <i class="fa fa-arrow-circle-right"></i></button>	
											</div>
										 </div><!-- End of Div1 -->

										 <dv class="clearfix"></dv>

										 <div id="div2" style="display: none">
										 	<h2> Upload required documents </h2>
										 	<div class="col-sm-12">
	                                        	<!--<label for="form-user_lastname" class="form-label" style="float:left"><span class="validates">Last Name <code>*</code><small></small></span></label>-->
	                                        	<label for="form-userfile1" class="control-label" style="float:left"><span class="validates">Upload Copy of ID Card or Passport (JPG, PNG or GIF) <code>*</code><small></small></span></label><br />
												<input type="file" name="userfile1" id="userfile1" accept = "image/*" class="form-control margin-bottom-30" />
											</div>
											<div class="col-sm-12">
	                                        	<!--<label for="form-user_lastname" class="form-label" style="float:left"><span class="validates">Last Name <code>*</code><small></small></span></label>-->
	                                        	<label for="form-userfile2" class="control-label" style="float:left"><span class="validates">Upload Passport size Photo (JPG, PNG or GIF) <code>*</code><small></small></span></label><br />
												<input type="file" name="userfile2" id="userfile2" accept = "image/*" class="form-control margin-bottom-30" />
											</div>

											<div class="col-sm-6">
	                                        	<button class="btn btn-warning btn-lg col-sm-8 col-xs-12 center-block  margin-bottom-15 btn-prev1"><i class="fa fa-arrow-circle-left"></i> Previous </button>
											</div>

											<div class="col-sm-6">
	                                        	<button class="btn btn-new btn-lg col-sm-8 col-xs-12 center-block  margin-bottom-15 btn-next2">Next <i class="fa fa-arrow-circle-right"></i></button>
											</div>
										 </div><!-- End of Div 2 -->

										 <div id="div3" style="display: none"><!-- Start of Div3-->
										 	<h2> Preview and Save Details </h2>
											
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">First Name <code>*</code><small></small></span> <span id="fnames"></span></label><br />	
											</div>
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">Last Name <code>*</code><small></small></span> <span id="lname"></span></label><br />	
											</div>
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">Email<code>*</code><small></small></span> <span id="email"></span></label><br />	
											</div>
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">Mobile <code>*</code><small></small></span> <span id="mobile"></span></label><br />	
											</div>
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">Gender <code>*</code><small></small></span> <span id="gender"></span></label><br />	
											</div>
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">Country <code>*</code><small></small></span> <span id="country"></span></label><br />	
											</div>

											<div class="col-sm-12" style="border-top: 1px solid color: #000; padding: 4px;"></div>
											<br />
											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">ID Card or Passport (JPG, PNG or GIF) <code>*</code><small></small></span></label><br />	
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span id="idcard"></span></label>
											</div>

											<div class="col-sm-6">
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span class="validates">Passport size Photo (JPG, PNG or GIF) <code>*</code><small></small></span></label><br />	
	                                            <label for="form-user_firstname" class="form-label" style="float:left"><span id="pass"></span></label>
											</div>

											<br /><br /><br />


											<p style="padding-top: 20px;">
												<div class="col-sm-6">
		                                        	<button class="btn btn-warning btn-lg col-sm-8 col-xs-12 center-block  margin-bottom-15 btn-prev2"><i class="fa fa-arrow-circle-left"></i> Previous </button>
												</div>

												<div class="col-sm-6">
		                                        	<button class="btn btn-new btn-lg col-sm-8 col-xs-12 center-block  margin-bottom-15 btn-signup">Register <i class="fa fa-arrow-circle-right"></i></button>
												</div>
											</p>
										 </div><!-- End of Div3 -->

										 <div class="col-sm-12 text-center" style="border-top: 1px solid color:#ccc;">
												<p class="messages p-top30 margin-bottom0">Already registered ? <a href="<?=base_url('auth/signin'); ?>">Account Login</a></p>
											</div>

										</form>
                                 </div><!-- End outer Container -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- End of Register -->


<!--  Scripts -->
<script src="<?php echo base_url();?>assets/assets/vendor/jquery/jquery.js"></script>
    
    <script type="text/javascript">
		$(document).ready(function(){
			
			/*
			** next 1 values
			**********************************************************************************/
			//alert("yo");
			$( document ).on( "click", ".btn-next1", function(e) {
                    e.preventDefault(); 
			
					 var type=$('#type').val();
					 $(':input').css('border-color',''); 
					 $(':input').css('box-shadow',''); 
					 $('label small').css('color','').html(''); 
					 
					 $(".btn").attr("disabled", true);
					 //alert("<?= base_url() . 'account/save_form/frm_reg/insert'?>");

					  ////////////////////////////////////////////////////////////////////        
					  $.ajax({
						 url: "<?= base_url() . 'account/save_form/frm_reg/insert'?>",  
						 type: 'POST',
						 dataType: "html",
						 data: $("form").serialize(),
						 beforeSend: function(){
								// Replace this with your loading gif image
								$('html, body').animate({scrollTop: $(".message").offset().top-100}, 150);
								$('.message').show();
					 			$('.message').show().addClass('alert alert-danger').html('<?= img(array("src"=>"assets/images/loaders/loader7.gif","style"=>"vertical-align:text-bottom;"));?><span style="font-weight: bold; padding-left: 1em;font-size: 12px; color:#F00;">Processing please wait..!</span>');
																	
								//Disable Button
								$(".btn").attr("disabled", true);
						},
						error: function(){
								$('.message').fadeOut('slow');
								$('.message').fadeIn('slow').removeClass('info').addClass('alert alert-danger');
								$('.message').html('<strong><h5><i class="fa fa-warning"></i> Error!</h5></strong> Unable to complete your request. Please try again!. If the problem persists, please contact the administrator');
								$.magnificPopup.close();
								$(".btn").removeAttr("disabled");
						},
																
						success: function( result ) {
																	
							//alert(result);
							$(".btn").removeAttr("disabled");
							var data = result;
							var s =" ["+data+"]";
							var myObject = eval('(' + s + ')');
							for (i in myObject)
							{
								for (f in myObject[i] ){
									if (f === 'info'){
										if ((myObject[i][f])=== 'success'){
											$('#div1').hide();	
											$('#div2').show();			
											$('.message').hide();;
																						
																		
									}else if ((myObject[i][f])=== 'error'){
											$('.message').removeClass('alert-info').addClass('alert-danger').html('<b>Oops! </b>').append('<br />A problem occurred when creating your account. Please try again!');
										}
									}
								}
							}
						}
					});
			
			 	 e.preventDefault();
				 return false;
			});
			
			
			/*
			** next 2 values
			**********************************************************************************/
			//alert("yo");
			$( document ).on( "click", ".btn-next2", function(e) {
                    e.preventDefault(); 
			
					 var type=$('#type').val();
					 $(':input').css('border-color',''); 
					 $(':input').css('box-shadow',''); 
					 $('label small').css('color','').html(''); 
					 
					 $(".btn").attr("disabled", true);
					 //alert("yo");
					//////////////////////////////////////////////////////////////////////////////////	
					//var formElem = $("#formId");				
					//var formData = new FormData($(this)[0]);
					
					//////////////////////////////////////////////////////////////////////////////////
					var myForm = document.getElementById('signup-form');
					formData = new FormData(myForm);
					
					formData.append("userfile1", $('input[type=file]')[0].files[0]);
					formData.append("userfile2", $('input[type=file]')[1].files[0]);
					///////////////////////////////////////////////////////////////
																																					
					////////////////////////////////////////////////////////////////////        
					$.ajax({
						url: "<?= base_url() . 'account/save_form/frm_reg2/insert'?>",  
						type: 'POST',
						data: formData ? formData : form.serialize(),
						dataType: "html",
						cache       : false,
						contentType : false,
						processData : false,
					beforeSend: function(){
						// Replace this with your loading gif image
						$('html, body').animate({scrollTop: $(".message").offset().top-100}, 150);
						$('.message').show();
						$('.message').fadeIn('slow').removeClass('info').addClass('alert alert-danger').html('<p><img src = "<?=base_url(); ?>assets/assets/images/loaders/loader7.gif" class="loaders"/><span style="font-weight: bold; padding-left: 1em;font-size: 12px;">Processing please wait..!</span></p>');
						$('html, body').animate({scrollTop: $('.message').offset().top}, 100);
					},
					error: function(){
						$('.message').fadeOut('slow');
						$('.message').fadeIn('slow').removeClass('info').addClass('alert alert-danger');
						$('.message').html('<strong><h5><i class="fa fa-warning"></i> Error!</h5></strong> Unable to complete your request. Please try again!. If the problem persists, please contact the administrator');
						$('html, body').animate({scrollTop: $('.message').offset().top}, 100);
						$(".btn").removeAttr("disabled");
					},
					success: function( result ) {
						//alert(result);
						
						$(".btn").removeAttr("disabled");														
						//alert(result);
						var a = JSON.parse(result);
                      	var data = result;
						var s =" ["+data+"]";
						var myObject = eval('(' + s + ')');
						for (i in myObject)
							{
								for (f in myObject[i] ){
									
									if (f === 'cl_error'){
											if(a.cl_error){
												$('.message h3').show();
												$('.message').removeClass('alert alert-info alert-primary').addClass('alert alert-danger').html('<h5><i class="fa fa-warning"></i> <b>ID Card or Passport Upload Error! </b></h5>').append(a.cl_error);										
												//$('.fileupload').css({'border-color':'#a94442'});
												$("label[for='form-userfile1'] small").css('color','#a94442').html(a.cl_error);
												$('html, body').animate({scrollTop: $('.panel-title').offset().top}, 100);
												die();
											}
											die();
								
									}else if (f === 'info'){
											if ((myObject[i][f])=== 'success'){
																	
													$('#div2').hide();	
													$('#div3').show();			
													$('.message').hide();
													
													//alert("yo" + $("#form-user_gender :selected").text());
													$('#fnames').html($('#form-user_firstname').val());
													$('#lname').html($('#form-user_lastname').val());
													$('#email').html($('#form-user_email').val());
													$('#mobile').html($('#form-user_mobile').val());
													$('#gender').html($("#form-user_gender :selected").text());
													$('#country').html($("#form-user_country :selected").text());
													var file1=$('#userfile1').val();
													var req = file1.split("fakepath");
													//var idcard=req.split("\");
													$('#idcard').html(req[1]);
													
													/////////////////////////////////////////////////
													var file1=$('#userfile2').val();
													var req = file1.split("fakepath");
													
													$('#pass').html(req[1]);

											}
									
									}
						 }
					  }
                   }
			});			
			
			e.preventDefault();
			return false;
		 });
			
			//alert("yo");
			$( document ).on( "click", ".btn-signup", function(e) {
                    e.preventDefault(); 
			
					 var type=$('#type').val();
					 $(':input').css('border-color',''); 
					 $(':input').css('box-shadow',''); 
					 $('label small').css('color','').html(''); 
					 
					 $(".btn").attr("disabled", true);
					 //alert("<?= base_url() . 'auth/signup/'?>"+ type);

					  //////////////////////////////////////////////////////////////////////////////////
					var myForm = document.getElementById('signup-form');
					formData = new FormData(myForm);
					
					formData.append("userfile1", $('input[type=file]')[0].files[0]);
					formData.append("userfile2", $('input[type=file]')[1].files[0]);
					///////////////////////////////////////////////////////////////
																																					
					////////////////////////////////////////////////////////////////////        
					$.ajax({
						url: "<?= base_url() . 'auth/signup/'?>"+type,  
						type: 'POST',
						data: formData ? formData : form.serialize(),
						dataType: "html",
						cache       : false,
						contentType : false,
						processData : false,
					beforeSend: function(){
								// Replace this with your loading gif image
								$('html, body').animate({scrollTop: $(".message").offset().top-100}, 150);
								$('.message').show();
					 			$('.message').show().addClass('alert alert-danger').html('<?= img(array("src"=>"assets/images/loaders/loader7.gif","style"=>"vertical-align:text-bottom;"));?><span style="font-weight: bold; padding-left: 1em;font-size: 12px; color:#F00;">Processing please wait..!</span>');
																	
								//Disable Button
								$(".btn").attr("disabled", true);
						},
														
						success: function( result ) {
																	
							//alert(result);
							$(".btn").removeAttr("disabled");
							var data = result;
							var s =" ["+data+"]";
							var myObject = eval('(' + s + ')');
							for (i in myObject)
							{
								for (f in myObject[i] ){
									if (f === 'info'){
										if ((myObject[i][f])=== 'success'){
											$('#outer_container').hide(1000);			
																						
											if(type !="employers"){
												$('.message').removeClass('alert alert-danger').addClass('alert alert-success').html('<b> Success !</b><p>You have created an account' + 
												' on our Portal. Please check your  email address to activate your account.</p>');
											}else{
												$('.message').removeClass('alert alert-danger').addClass('alert alert-success').html('<b> Success !</b><p>Thank you for registering as an Employer on ABS Portal.</p>' + 
												'<p>Please check your  email address to activate your account.</p>');
											}
											
																				
									}else if ((myObject[i][f])=== 'error'){
											$('.message').removeClass('alert-info').addClass('alert-danger').html('<b>Oops! </b>').append('<br />A problem occurred when creating your account. Please try again!');
											$(".btn").removeAttr("disabled");
										}
									}
								}
							}
						}
					});
			
			 	 e.preventDefault();
				 return false;
			});
			
			
			//alert("yo");
			$( document ).on( "click", ".btn-prev1", function(e) {
                    e.preventDefault(); 
					
					$('#div2').hide();	
					$('#div1').show();			
					$('.message').hide();
			});
			
			//alert("yo");
			$( document ).on( "click", ".btn-prev2", function(e) {
                    e.preventDefault(); 
					
					$('#div3').hide();	
					$('#div2').show();			
					$('.message').hide();
			});
			
			
			
		});
		
	</script>