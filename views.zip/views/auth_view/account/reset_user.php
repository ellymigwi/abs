<!-- start: page -->
           <section class="body-sign animated fadeInDownBig">

			<div class="center-signs">
				<a href="/" class="logo pull-left">
					<!--<img src="assets/images/logo.png" height="54" alt="Porto Admin" />-->
				</a>

				<div class="panel panel-sign">
					<div class="panel-title-sign mt-xl text-right">
						<h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Reset Password</h2>
					</div>
					<div class="panel-body">
						<div class="message alert alert-info">
							<p class="m-none text-semibold h6"> <h4>Welcome, New user!</h4>  
							Reset your password on The Students portal by completing the form below.</p>
						</div>
						  <div id="reset_msg">
                            <form id="reset-form" class="form-login" method="post">
                              
                                <div class="clearfix">
                
                                    <label for="form-password" class="form-label">Enter new Password<code>*</code><small>(Should be alphanumeric with at least six characters.)</small></label>
                            
                                    <div class="form-input">
                                        <input type="password" class="form-control pword" id="form-password"  name="password" placeholder="Enter your password" >
                                    </div>
                            
                                </div>
                            
                                <div class="clearfix">
                            
                                    <label for="form-password-conf" class="form-label">Password confirmation<code>*</code><small>(Re-enter your password)</small></label>
                            
                                    <div class="form-input"><input type="password" class="form-control pword"  id="form-password-conf" name="password-conf" data-equals="password" placeholder="Confirm your password" maxlength="30" /></div>
                            
                                </div>
                                <br />
                                <div class="form-action clearfix">
                                    <button type="submit" class="btn btn-success" id="form-submit" >
                                        Reset Password <i class="fa fa-arrow-circle-right"></i>
                                    </button>
                                   <!-- <button class="button" id="form-submit" type="submit" data-icon-primary="ui-icon-circle-check">Reset Password</button>-->
                                </div>
                            </form>
                        </div>
					</div>
				</div>

				<p class="text-center text-muted mt-md mb-md">&copy; Copyright  <?php echo date("Y"); ?>. All Rights Reserved.</p>
			</div>
		</section>
		<!-- end: page -->
        
 <!--- Jquery Sturf -->
<script src="<?php echo base_url();?>assets/assets/vendor/jquery/jquery.js"></script>	
       
<script type="text/javascript">
$(document).ready(function(){
	$('#reset-form').unbind('submit').submit(function(e){

		//$('.message h3').html('Processing...');
		$('.message').removeClass('info').addClass('alert alert-danger').html('<?= img(array("src"=>"assets/assets/images/loaders/loader7.gif","style"=>"vertical-align:text-bottom;"));?><span style="font-weight: bold; padding-left: 1em;font-size: 12px;">Processing please wait..!</span>');
		$(':input').css('border-color',''); 
		$(':input').css('box-shadow',''); 
		$('label small').css('color','').html('');
		//alert($('form').serialize());
		
	 	$.post("<?= base_url() . 'auth/reset/'?>",  
		  $('form').serialize(),
			function(result) {
			 var data = result;
			 //alert(data);
			 var s =" ["+data+"]";
			  var myObject = eval('(' + s + ')');
			  for (i in myObject)
			  {
				  for (f in myObject[i] ){
					  if (f === 'info'){
						  if ((myObject[i][f])=== 'success'){
							  	$('.message').show().removeClass('alert alert-info').addClass('alert alert-danger ').html('Congratulations! You have reset the password to your account on The Students Portal, you can .<?php echo anchor("auth/signin","click here")?>. to log in!');
								$('#reset-form').hide(1000);
						  }
						  else if ((myObject[i][f])=== 'error'){
								$('.message').removeClass('info').addClass('alert alert-danger');
								$('.message').show().html('<h5> <b>Reset Error! </b></h5> <p>Your Account has been reset. To reset again , please request a reset code by clicking on forgot password link in Login page. Incase of any challenges please contact the administrator.!</p>')
						  }
					  }
					  
				  }
			  } 
			 },"html");
	  e.preventDefault();
	  return false;
	});
});  
</script>