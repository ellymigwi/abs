 <style>
 
 .validates{
	 font-weight:none; color:#929294; font-family:Verdana, Geneva, sans-serif; font-size:13px; text-transform:none;
 }
 
 </style>
 <!-- Breadcrumps -->
	<section class="breadcrumbs">
		<div class="row">
			<div class="container">
				<div class="col-sm-6">
					<h1>Reset Password</h1>
                </div>
				<div class="col-sm-6">
					<ol class="breadcrumb">
						<li>You are here: </li>
						<li><a href="<?php echo base_url('auth/index/');?>">Home</a> </li>
						<li>Pages </li>
						<li class="active">Reset Password</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Breadcrumps -->


	<!-- Reset Password -->
	<section class="login section_sapces" style="margin-top: 50px;  padding-bottom: 50px;">
		<div class="row ">
			<div class="container">
				<div class="section-title margin-b50">
					<h2>Password Reset</h2>
                </div>
				<div class="col-sm-12">
					<div class="login-form-panel">
						<div class="row">
							<div class="col-sm-8 col-md-5 center-block padding-b30 padding-t30 bg_gray border shadow">
                                 <div class="message p-top30 margin-bottom0" style="padding:5px"></div>
                                 
								 <div class="form password-reset" id="reset_msg">
									<form id="reset-form" class="login-form clearfix ">
										<div class="col-sm-12">
                           					 <label for="form-password" class="form-label" style="float:left"><span class="validates">Enter new Password<code>*</code><small></small></span></label><br />
                                            <input type="password" class="form-control margin-bottom-15" id="form-password"  name="password" placeholder="Enter your password" >
                                             
                                            <label for="form-password-conf" class="form-label" style="float:left"><span class="validates">Password confirmation<code>*</code><small></small></span></label><br />
                                            <input type="password" class="form-control margin-bottom-15" id="form-password-conf"  name="password-conf" placeholder="Confirm your password" >
                                                  
											<button class="btn btn-primary btn-lg margin-bottom-15  btn-block btn-resets">Reset Password <i class="fa fa-arrow-circle-right"></i></button>
										</div>
										<div class="col-sm-12">
											<p class="messages p-top30 ">Remember Password ? <a href="<?=base_url('auth/signin'); ?>">Account Login </a></p>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Reset Password -->

<!--  Scripts -->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
       
<script type="text/javascript">
$(document).ready(function(){
	
	
	$( document ).on( "click", ".btn-resets", function(e) {
        e.preventDefault(); 

		//$('.message h3').html('Processing...');
		$('.message').show().addClass('alert-danger').html('<?= img(array("src"=>"assets/images/loaders/loader7.gif","style"=>"vertical-align:text-bottom;"));?><span style="font-weight: bold; padding-left: 1em;font-size: 12px; color:#F00;">Processing please wait..!</span>');
		$(':input').css('border-color',''); 
		$(':input').css('box-shadow',''); 
		$('label small').css('color','').html('');
	
		//alert($('form').serialize());
	 	$.post("<?= base_url() . 'auth/reset/'.$url?>",  
		  $('form').serialize(),
			function(result) {
			 var data = result;
			 //alert(data);
			 var s =" ["+data+"]";
			  var myObject = eval('(' + s + ')');
			  for (i in myObject)
			  {
				  for (f in myObject[i] ){
					  if (f === 'info'){
						  if ((myObject[i][f])=== 'success'){
							  	$('.message').show().removeClass('alert alert-danger').addClass('alert alert-success ').html('<b>Congratulations!</b> You have reset the password to your account.You can <?php echo anchor("auth/signin","click here >>>")?> to log in!');
								$('#reset-form').hide(1000);
						  }
						  else if ((myObject[i][f])=== 'error'){
								$('.message').removeClass('alert-info').addClass('alert alert-danger');
								$('.message').show().html('<h5> <b>Reset Error! </b></h5> <p>Your Account has been reset. To reset again , please request a reset code by clicking on forgot password link in Login page. Incase of any challenges please contact the administrator.!</p>')
						  }
					  }
					 
				  }
			  } 
			 },"html");
	  e.preventDefault();
	  return false;
	});
});  
</script>