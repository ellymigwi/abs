 <style>
 
 .validates{
	 font-weight:none; color:#929294; font-family:Verdana, Geneva, sans-serif; font-size:13px; text-transform:none;
 }
 
 </style>
 <!-- Breadcrumps -->
	<section class="breadcrumbs">
		<div class="row">
			<div class="container">
				<div class="col-sm-6">
					<h1>Reset Password</h1>
                </div>
				<div class="col-sm-6">
					<ol class="breadcrumb">
						<li>You are here: </li>
						<li><a href="<?php echo base_url('auth/index/');?>">Home</a> </li>
						<li>Pages </li>
						<li class="active">Reset Password</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Breadcrumps -->


	<!-- Reset Password -->
	<section class="login section_sapces" style="margin-top: 50px;  padding-bottom: 50px;">
		<div class="row ">
			<div class="container">
				<div class="section-title margin-b50">
					<h2>Password Reset</h2>
                </div>
				<div class="col-sm-12">
					<div class="login-form-panel">
						<div class="row">
							<div class="col-sm-8 col-md-5 center-block padding-b30 padding-t30 bg_gray border shadow">
                                 <p> <div class="message alert-info p-top30 margin-bottom0" style="padding:5px"> Enter your email address and we'll send you an email with instructions to reset your password. </div> </p>
								 <div class="form password-reset" id="reset_msg">
									<form id="reset-form" class="login-form clearfix ">
										<div class="col-sm-12">
                                        	 <label for="reset-email_add" class="form-label" style="float:left"><span class="validates">Email <code>*</code><small></small></span></label><br />
                                            <input type="text"  class="form-control margin-bottom-15" id="reset-email_add" name="reset-email_add" placeholder="Enter your email address"/>
											<button class="btn btn-primary btn-lg margin-bottom-15  btn-block btn-reset">Reset Password <i class="fa fa-arrow-circle-right"></i></button>
										</div>
										<div class="col-sm-12">
											<p class="messages p-top30 ">Remember Password ? <a href="<?=base_url('auth/signin'); ?>">Account Login </a></p>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Reset Password -->

<!--  Scripts -->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
       
<script type="text/javascript">
			$(document).ready(function(){
				
				//Forgot password 
				$( document ).on( "click", ".btn-reset", function(e) {
                    e.preventDefault(); 
						
					$('.message').show().addClass('alert-danger').html('<?= img(array("src"=>"assets/images/loaders/loader7.gif","style"=>"vertical-align:text-bottom;"));?><span style="font-weight: bold; padding-left: 1em;font-size: 12px; color:#F00;">Processing please wait..!</span>');
					$(':input').css('border-color',''); 
					var email_add= $('#reset-email_add').val();
					
					/*Validate email*/
					if(email_add === ''){
						$('#reset-email_add').css({'border-color':'#a94442','box-shadow':'0 1px 1px #e8c8c8 inset'});
						$('.message').show().removeClass('alert-info').addClass('alert-danger ').html(' Enter your a email address !').focus();				
					}else{		  
							  //alert( $("#reset-form").serialize());
							  $.post("<?= base_url() . 'auth/forgot' ?>",  
							  $("#reset-form").serialize(),
							  function(result) {
								  //alert(result);
								  var data = result;
								  var s =" ["+data+"]";
								  var myObject = eval('(' + s + ')');
								  for (i in myObject)
								  {
									  for (f in myObject[i] ){
										  //alert("yo" + myObject[i][f]);
										  
										  if (f === 'info'){
											  if ((myObject[i][f])=== 'reset'){
													$('.message').show().removeClass('alert alert-danger').addClass('alert alert-success ').html('<b> Success !</b><p>A link to reset your password has been sent to your email address!')
													$('#reset-email_add').css({'border-color':'#a94442','box-shadow':'0 1px 1px #e8c8c8 inset'})
													$('#reset_msg').hide(1000);
											  }
											  else if ((myObject[i][f])=== 'invalid'){
												  	$('#reset-email_add').css({'border-color':'#a94442','box-shadow':'0 1px 1px #e8c8c8 inset'})
													$('.message').show().removeClass('alert alert-info').addClass('alert alert-danger ').html('Please enter a valid email address!')	;					  }
										 
									  }
								  } 
							 },"html");
						}
						
						
						e.preventDefault();
						return false;
					});
			});
		</script>