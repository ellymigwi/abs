  <!-- HOME -->
       <section style="background-color:#8596ba">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">

                        <div class="wrapper-page">

                            <div class="account-pages">
                                <div class="account-box">
                                    <div class="account-logo-box">
                                        <!--<h2 class="text-uppercase text-center">
                                            <a href="index.html" class="text-success">
                                                <span><img src="images/logo_dark.png" alt="" height="20"></span>
                                            </a>
                                        </h2>-->
                                        <h3 class="text-uppercase text-center font-bold mt-4">Log Out</h3>
                                    </div>
                                    <div class="account-content">
                                        <div class="text-center m-b-20">
                                            <div class="m-b-20">
                                                <div class="checkmark">
                                                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                         viewBox="0 0 161.2 161.2" enable-background="new 0 0 161.2 161.2" xml:space="preserve">
                                                    <path class="path" fill="none" stroke="#32c861" stroke-miterlimit="10" d="M425.9,52.1L425.9,52.1c-2.2-2.6-6-2.6-8.3-0.1l-42.7,46.2l-14.3-16.4
                                                        c-2.3-2.7-6.2-2.7-8.6-0.1c-1.9,2.1-2,5.6-0.1,7.7l17.6,20.3c0.2,0.3,0.4,0.6,0.6,0.9c1.8,2,4.4,2.5,6.6,1.4c0.7-0.3,1.4-0.8,2-1.5
                                                        c0.3-0.3,0.5-0.6,0.7-0.9l46.3-50.1C427.7,57.5,427.7,54.2,425.9,52.1z"/>
                                                    <circle class="path" fill="none" stroke="#32c861" stroke-width="4" stroke-miterlimit="10" cx="80.6" cy="80.6" r="62.1"/>
                                                    <polyline class="path" fill="none" stroke="#32c861" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="113,52.8
                                                        74.1,108.4 48.2,86.4 "/>

                                                    <circle class="spin" fill="none" stroke="#32c861" stroke-width="4" stroke-miterlimit="10" stroke-dasharray="12.2175,12.2175" cx="80.6" cy="80.6" r="73.9"/>

                                                </svg>

                                                </div>
                                            </div>

                                            <h5>See You Again !</h5>

                                            <p class="text-muted font-14 m-t-10"> You are now successfully sign out. Back to <a href="<?=base_url('auth/index/signin/'); ?>" class="text-primary m-r-5"><b>Sign In</b></a></p>
                                            <p class="text-center text-muted font-14 m-t-10"> <a href="<?=base_url('auth/index/'); ?>" class="text-primary m-r-5"><b> Back to Home Page</b></a></p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- end card-box-->


                        </div>
                        <!-- end wrapper -->

                    </div>
                </div>
            </div>
        </section>
        <!-- END HOME -->
  
  </main>
</div><!-- End wrapper-->