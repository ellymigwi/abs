<!-- Breadcrumps -->
	<section class="breadcrumbs">
		<div class="row">
			<div class="container">
				<div class="col-sm-6">
					<h1>Login</h1>
                </div>
				<div class="col-sm-6">
					<ol class="breadcrumb">
						<li>You are here: </li>
						<li><a href="<?php echo base_url('auth/index/');?>">Home</a> </li>
						<li>Pages </li>
						<li class="active">Login</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Breadcrumps -->


	<!-- Login -->
	<section class="login section_sapces" style="margin-top: 10px;  padding-bottom: 30px;">
		<div class="row ">
			<div class="container">
				<div class="section-title margin-b30">
					<h2>Login</h2>
                </div>
				<div class="col-sm-12">
					<div class="login-form-panel">
						<div class="row">
							<div class="col-sm-10 col-md-5 center-block bg_gray padding30 border shadow">
								<div class="login-form">
                                    <p><div class="message alert-info" style="padding:4px;"><p><span style="color:#F00; ">&nbsp;<?php echo " ".$message;?> </span></p></div></p>
									  <form id="form-login" class="form-login form-horizontal" style="padding-left:10px;padding-right:10px;">
                                        <input name="user_type" type="hidden" id="user_type" value="student" />
                            			<input name="user_number" type="hidden" id="user_number" value="<?php echo $number; ?>" />
                                        
										<input type="text" id="form-email_add" name="email_add" required=""  class="form-control margin-bottom-15" size="50" placeholder="Enter your E-mail address" />
										<input type="password" id="form-password"  name="password" class="form-control" size="20" placeholder="Enter your Password" />
										<p class="text-center btn-block margin-top-15">
                                        	<a href="<?=base_url('auth/index/forgot'); ?>">Forgot Password?</a>
                                        </p>
                                        <button class="btn btn-primary btn-lg margin-bottom-15  btn-block btn-login">Login <i class="fa fa-arrow-circle-right"></i></button>
										<p class="messages p-top10">Not registered?
                                        	<a href="<?=base_url('auth/index/signup/'); ?>">Create an account</a>
                                        </p>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Login -->


<!--  Scripts -->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>

<script type="text/javascript">
			$(document).ready(function(){
				
				//lert("yo");
				/**
				* Login in Form
				*/
				//$('#form-login').unbind('submit').submit(function(e){
				$( document ).on( "click", ".btn-login", function(e) {
                    e.preventDefault(); 
					
					$('.message').show().removeClass('alert-info').addClass('alert-danger').html('<?= img(array("src"=>"assets/images/loaders/loader7.gif","style"=>"vertical-align:text-bottom;"));?><span style="font-weight: bold; padding-left: 1em;font-size: 12px; color:#F00;">Processing please wait..!</span>');
					$(':input').css('border-color',''); 
					var email_add = $('#form-email_add').val();
					var password = $('#form-password').val();
					//alert(email_add + password);
					
					/*Validate email and password*/
					if((email_add === '') ||(password === '')){
						  if((email_add === '')){
							  $('#form-email_add').css({'border-color':'#a94442','box-shadow':'0 1px 1px #e8c8c8 inset'})
							  //box-shadow: 0 1px 1px rgba(0, 0, 0, 0.4) inset;
							  $('.message').show().removeClass('alert-info').addClass('alert-danger ').html(' <p><strong><code style="color:#F00; ">&nbsp; Enter your a email address ! </code></strong></p>').focus()
						  }
						  else if((password === '')){
							  $('#form-password').css({'border-color':'#a94442','box-shadow':'0 1px 1px #e8c8c8 inset'})
							   $('.message').show().removeClass('alert-info').addClass('alert-danger ').html(' <p><strong><code style="color:#F00; ">&nbsp; Enter your Password ! </code></strong></p>').focus()
						  }
						  
					}else{
		
						//Prepare Ajax call
						$.post("<?=base_url() . 'auth/signin' ?>",  
						$("form").serialize(),
						function(result) {
						 var data = result;
						 //alert(data);
						 var s =" ["+data+"]";
						  var myObject = eval('(' + s + ')');
						  for (i in myObject)
						  {
							  for (f in myObject[i] ){
								  //alert("yo"+(myObject[i][f]));
								  if (f === 'info'){
									  if ((myObject[i][f])=== 'warning'){
											$('.message').show().removeClass('info').addClass('alert alert-danger ').html('<p><strong><code style="color:#F00; ">&nbsp;The password entered is incorrect!</code></strong></p>')
											$('#form-password').css('border-color','red');
									  }
									  else if ((myObject[i][f])=== 'error'){
											$('.message').show().removeClass('info').addClass('alert alert-danger ').html('<p><strong><code style="color:#F00; ">A user with that email does not exist in the system!</code></strong></p>')
										   $('#form-email_add').css('border-color','red');
									  }
									  else if ((myObject[i][f])=== 'deactivated'){
											$('.message').show().removeClass('info').addClass('alert alert-danger ').html('<p><strong><code style="color:#F00; ">&nbsp;Your account is currently deactivated! Contact the administrator for more details!</code></strong></p>')
											$('#form-email_add').css('border-color','red');
											$('#error_msg').hide(1000);
									  }
									  else if ((myObject[i][f])=== 'inactive'){
											$('.message').show().removeClass('info').addClass('alert alert-danger ').html('<p><strong><code style="color:#F00; ">&nbsp;Please activate your account using the link sent to your email address during registration! </code></strong></p>')
											$('#form-email_add').css('border-color','red');
											$('#error_msg').hide(1000);
									  }
									  else if ((myObject[i][f])=== 'invalid'){
											$('.message').show().removeClass('info').addClass('alert alert-danger ').html(' <p><strong><code style="color:#F00; ">&nbsp; Please enter a valid email address!  </code></strong></p>')
											$('#form-email_add').css('border-color','red');
											
									  }
									  else if ((myObject[i][f])=== 'user_ban'){
											$('.message').show().removeClass('info').addClass('alert alert-danger ').html('Your account has been banned from accessing the portal! Contact the administrator for more details!')
											$('#form-email_add').css('border-color','red');
											$('#error_msg').hide(1000);
									  }
									   
									  else{
											window.location = "<?= base_url()?>"+myObject[i][f] 
									  }
								  }
								  else{
										// alert(f+' - '+myObject[i][f]);
										$('#form-'+f).css('border-color','red');
										$("label[for='form-"+f+"'] small").css('color','red').html(myObject[i][f])
								  }
							  }
						  } 
					 },"html");
				  }
				  e.preventDefault();
				  return false;
				});			 	
			});
		</script>