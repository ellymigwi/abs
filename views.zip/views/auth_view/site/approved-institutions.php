<!-- About Us Content-->
	<section class="about">
		<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/info-banners/5.jpg">
			<div class="section-title ">
				<h2>
                	<span>ABS Info</span> Approved Institutions
                </h2>
            </div>
		</section>
		<section class="section_sapce section_white">
			<div class="row">
				<div class="container">
					<div class="col-sm-12 col-md-12">
						<h1>A list of approved institutions for research affiliation purpose</h1>
                        <hr />
                        
                      <table width="100%">
                          <tr>
                            <td colspan="3"><p>Below please  find Public and Private Universities; and Public Research Institutions. Selected Faculties,  Schools and Institutes for the Public universities are also provided. For  further Information,  log onto their websites.</p></td>
                          </tr>
                          <tr>
                            <td colspan="3">&nbsp;</td>
                          </tr>
                          <tr>
                            <td colspan="3"><h4>1. PUBLIC UNIVERSITIES</h4></td>
                          </tr>
                          <tr>
                            <td width="2%"></td>
                            <td width="49%" valign="top">
                            	<p>UNIVERSITY OF  NAIROBI. <br />
                              P.O. Box  30197-00100<br />
                              Nairobi<br />
Website: <a href="http://www.uonbi.ac.ke">http://www.uonbi.ac.ke</a></p></td>
                            <td width="49%" valign="top">
                            <p> KENYATTA  UNIVERSITY<br />
P.O. Box  43844-00100<br />
Nairobi<br />
Website: <a href="http://www.ku.ac.ke">http://www.ku.ac.ke</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td valign="top"><p>EGERTON  UNIVERSITY<br />
P.O. Box  536-20115<br />
Egerton<br />
Website: http://www.egerton.ac.ke</p></td>
                            <td valign="top"><p>JOMO KENYATTA  UNIVERSITY OF AGRICULTURE AND TECHNOLOGY<br />
P.O. Box  6200-00200<br />
Nairobi<br />
Website:  <a href="http:// www.jkuat.ac.ke">http:// www.jkuat.ac.ke</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td valign="top"><p>MOI UNIVERSITY<br />
P.O. Box  3900-30100<br />
Eldoret<br />
Website:  http://www.mu.ac.ke</p></td>
                            <td valign="top"><p>MASENO  UNIVERSITY<br />
P.O. Box  333-40105<br />
Maseno<br />
Website:  <a href="http:// www.maseno.ac.ke">http:// www.maseno.ac.ke</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td valign="top"><p>MASINDE MULIRO  UNIVERSITY OF SCIENCE AND TECHNOLOGY<br />
P.O. Box  190-50100<br />
Kakamega<br />
Website:  <a href="http:// www.wust.ac.ke"> http:// www.wust.ac.ke</a></p></td>
                            <td valign="top">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2">&nbsp;</td>
                          </tr>
                          <tr>
                            <td colspan="3"><h4>2. PRIVATE UNIVERSITIES</h4></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td><p>University of  Eastern Africa – Baraton<br />
                              P.O. Box 2500-30200,<br />
                              Eldoret<br />
  							 Website: <a href="http://www.ueab.ac.ke">http:// www.ueab.ac.ke </a></p></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                          <tr>
                            <td colspan="3" valign="top"><h4>3. GOVERNMENT PUBLIC RESEARCH INSTITUTIONS</h4></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Kenya  Agricultural Research Institute (KARI)<br />
                              P.O. Box 57811-00200<br />
                              Nairobi.
                              Website:  <a href="http://www.kari.org">http://www.kari.org</a></p></td>
                            <td valign="top"><p>Kenya Medical  Research Institute (KEMRI)<br />
                              P.O. Box 4840-00200<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.kemri.org">http://www.kemri.org</a></p></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Kenya Marine  and Fisheries Research Institute (KEMFRI)<br />
                              P.O. Box 81651-080100<br />
                              Mombasa<br />
  							  Website:  <a href="http://www.kmfri.co.ke">http://www.kmfri.co.ke</a></p></td>
                            <td valign="top"><p>Kenya  Industrial Research and Development Institute (KIRDI)<br />
                              P.O. Box 30650-00100<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.kirdi.go.ke">http://www.kirdi.go.ke</a></p></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Kenya  Trypanosomiasis Research Institute (KETRI)<br />
                              P.O. Box 57811-00200<br />
                              Nairobi<br />
  							 Website:  <a href="http:// www.kari.org">http:// www.kari.org</a></p></td>
                          <td valign="top"><p>National  Museums of Kenya (NMK)<br />
                              P.O. Box 40658-00100<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.museums.or.ke">http://www.museums.or.ke</a></p></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Institute of  Primate Research (IPR)<br />
                              National  Museums of Kenya<br />
                              P.O. Box 24481-00502<br />
                              Nairobi.<br />
  							  Website:  <a href="http://www.museums.or.ke">http://www.museums.or.ke</a></p></td>
                            <td valign="top"><p>Kenya Wildlife  Service (KWS)<br />
                              P.O. Box 40241-00100<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.kws.org">http://www.kws.org</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td><p>Kenya Forestry  Research Institute (KEFRI)<br />
                              P.O. Box 20412-00200<br />
                              Nairobi<br />
  							  Website: <a href="http://www.kefri.org">http://www.kefri.org</a></p></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                      </table>
					</div>

				</div>
			</div>
		</section>