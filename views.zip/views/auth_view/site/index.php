<!--  Features -->
	<section class="section_sapces" style="padding-top: 50px;">
		<div class="row">
			<div class="container">
				<div class="section-title margin-b30">
					<h2><span>Welcome to ABS IT</span>ABS IT Permit Application System.</h2>
                </div>
			</div>
		</div>

		<div class="row">
			<div class="container">

			   <div class="col-md-12 margin-b50" style="text-align: center;">
					<p>The ABS Online permit application system was developed by the Kenyan government to expedite permit application process for researchers at the same
time improving the efficiency and transparency of the entire permit application process. The ABS Online permit application system also enforces and monitors the
MAT that the permit applicant signed with the respective lead agency that granted the permit.</p>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Features -->
        
        
	


   <!--Extra Info -->
	<section class="section_sapces bg_gray" style="padding-top:40px; padding-bottom:40px">
		<div class="container">
			<div class="section-title  margin-b50">
				<h2><span>Permits</span>ABS PERMITS IN KENYA</h2>
            </div>

			<div class="row faq">
					<div class="col-sm-12">
										<p>Below is information related to ABS permits in kenya. You are required to read and understand content before registration. </p>

										<!-- FAQ -->
										<div class="faq-questions margin-t50">
											<div id="accordion" class="panel-group">

												<div class="panel panel-default">
													<div class="panel-heading">
														<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Biological resources that require an ABS permit</a></h4> </div>
													<div id="collapse1" class="panel-collapse collapse in">
														<div class="panel-body">
															<p>
                                                            <ul class="list1">
                                                              <table width="100%">
                                                                <tr>
                                                                  <td><li>Animals</li></td>
                                                                  <td><li>Flowers</li></td>
                                                                  <td><li>Amphibians</li></td>
                                                                  <td><li>Birds</li></td>
                                                                  <td><li>Microbiota</li></td>
                                                                  <td> <li>Microbez</li></td>
                                                                  <td> <li>Insects</li></td>
                                                                </tr>
                                                              </table>
                                                             </ul>
                                                             </p>
														</div>
													</div>
												</div>

												<div class="panel panel-default">
													<div class="panel-heading">
														<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse2">A guideline to the Application process</a></h4> </div>
													<div id="collapse2" class="panel-collapse collapse">
														<div class="panel-body">
															<p><h3 class="p-bottom10">A. Information Guiding the Applicant</h3>
                         <h4>1. The Applicant accesses important information related to ABS system in Kenya:</h4>
						 <ul class="list1">
                        	<li><p>Biological resources that require an ABS permit</p> </li> 
                            <li><p>A guide to the application process</p> </li>
                            <li><p>Required documents for the application</p> </li>
                            <li><p>A list of approved institutions for research affiliation purposes</p> </li> 
                            <li><p>Lead agencies and their mandates</p> </li>
                            <li><p>Other information (e.g. regarding export of materials, applications for visas).</p> </li>
                        </ul>
                        
                        <!--Section 3-->
						<hr>
                        <h3 class="p-bottom10">B. Applicant Registration</h3>
                         <h4><p>1. The applicant creates an account by filling a registration form</h4>
						 <ul class="list1">
                        	<li><p>The applicant provides personal details: (bio data, email, address, identification details etc.) </p></li> 
                            <li><p>The Applicant uploads a passport-size photo, and copy of ID card or passport. </p>
                             <p>i. Applicant may preview, edit and save form details. </p>
                            </li>
                            <li><p>The applicant submits the registration form </p>
                            <p> ii. If all form fields are completed and required attachments are uploaded, a "Submit Successful" status is returned. </p>
                            <p> iii.Else, information is provided to the user regarding details that require correction, this is done by the system highlighting the sections where corrections or researcher input is required.</p>
							</li>
                            <li><p>The system creates an account and emails the user log-in credentials.</p></li> 
                        </ul>
                        
                        
                        <!--Section 3-->
						<hr>
                        <h3 class="p-bottom10">C. Harmonized Application Form</h3>
                        
						 <ol class="list1">
                        	<li><p>The Applicant logs in to fill in the necessary documents.</p></li> 
                            <li><p>The Applicant specifies whether he/she is a student or not.</p></li>
                            <li><p>The Applicant specifies whether he/she is applying as an individual, from an academic institution or company/research program.</p></li>
                            <li><p>The Applicant provides additional information such as legal officer contact details for their institution, researcher IDs etc.</p></li> 
                            <li><p>The Applicant is invited to upload a set of standard documents required by the authorities. This is likely to include.</p>
                                <ul class="list1">
                                    <li><p>Evidence of legal registration of the organisation. </p></li>
                                    <li><p>The research proposal and budget (principle of full transparency).</p></li>
                                    <li><p>Letter of affiliation with a local institution e.g. University of Nairobi. </p></li>
                                    <li><p>Curriculum Vitae.</p></li>
                                    <li><p>PIC and MAT.</p></li>
                                </ul>	
							</li> 
                            <li><p>The Applicant is required to answer a trigger question on whether they will be collecting biological or genetic material in Kenya (with due consideration for digital sequence information). <p> Where answer is negative the system opens up a standard NACOSTI application form. </p>
                            <p> i. The applicant completes the form as required (i.e. fills the form and uploads required attachments), and submits.</p>
                            <p> ii.NACOSTI's process follows.</p>
                            <li><p>If the answer is positive; the Applicant enters the ABS Pathway for the processing of applications.</p></li>
                            </li> 
                        </ol></p>
														</div>
													</div>
												</div>

												<div class="panel panel-default">
													<div class="panel-heading">
														<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Required documents for the application</a></h4> </div>
													<div id="collapse3" class="panel-collapse collapse">
														<div class="panel-body">
															<p><h3>1. Prior Informed Consent Description</h3>
<p>Prior Informed Consent (PIC) is the permission given by the provider or competent national authority of a provider country to a user prior to accessing genetic resources, in line with an appropriate national legal and institutional framework. It is the main ABS tool that is usually negotiated between the provider and the user of GR through an agreement involving mutually agreed terms (MAT). In Kenya, PIC is a written document and granted upon completing a Form modelled along Appendix I of the ABS Toolkit. PIC requires the user to disclose contact details, local affiliate, project type, location and nature of genetic resources to be accessed, method of collection, role of local community or lead agency, benefit sharing mechanisms and declaration of accrued benefits. It is the duty of the potential GR user to make full disclosure to the provider so as to make informed decision to grant access or not. In Kenya, PIC is a negotiated document (See appendix I) by parties and requires minutes of meetings with community or letter of support from lead agency. 
download templae</p>

<p><a href="<?=base_url('assets/uploads/Prior Informed Consent - template.pdf'); ?>">[Download Template]</a ></p>


						<hr />
                        <h3>2. Mutually Agreed Terms Description</h3>
<p>Mutually Agreed Terms (MAT) is an agreement reached between the providers of genetic resources and users on the conditions of access and use of the resources, and the benefits to be shared between both parties. This agreement is negotiated in the presence of relevant lead agencies to ensure a fair access and equitable sharing of the benefits. In Kenya, MAT is a negotiated agreement by parties and requires minutes of meetings with community, permit, licence or letter of support from relevant lead agency as modelled in Appendix II. download template
</p>
<p><a href="<?=base_url('assets/uploads/Mutually Agreed Terms - Template.pdf'); ?>">[Download Template]</a ></p>


						<hr />
                        <h3>3. Material Transfer Agreement Description</h3>
<p>Mutually Agreed Terms (MAT) is an agreement reached between the providers of genetic resources and users on the conditions of access and use of the resources, and the benefits to be shared between both parties. This agreement is negotiated in the presence of relevant lead agencies to ensure a fair access and equitable sharing of the benefits. In Kenya, MAT is a negotiated agreement by parties and requires minutes of meetings with community, permit, licence or letter of support from relevant lead agency as modelled in Appendix II. download template
</p>
<p><a href="<?=base_url('assets/uploads/Materials Transfer Agreement - Template.pdf'); ?>">[Download Template]</a ></p>
														</div>
													</div>
												</div>

												<div class="panel panel-default">
													<div class="panel-heading">
														<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse4">A list of approved  institutions for research affiliation purposes</a></h4> </div>
													<div id="collapse4" class="panel-collapse collapse">
														<div class="panel-body">
															<p><table width="100%">
                          <tr>
                            <td colspan="3"><p>Below please  find Public and Private Universities; and Public Research Institutions. Selected Faculties,  Schools and Institutes for the Public universities are also provided. For  further Information,  log onto their websites.</p></td>
                          </tr>
                          <tr>
                            <td colspan="3">&nbsp;</td>
                          </tr>
                          <tr>
                            <td colspan="3"><h4>1. PUBLIC UNIVERSITIES</h4></td>
                          </tr>
                          <tr>
                            <td width="2%"></td>
                            <td width="49%" valign="top">
                            	<p>UNIVERSITY OF  NAIROBI. <br />
                              P.O. Box  30197-00100<br />
                              Nairobi<br />
Website: <a href="http://www.uonbi.ac.ke">http://www.uonbi.ac.ke</a></p></td>
                            <td width="49%" valign="top">
                            <p> KENYATTA  UNIVERSITY<br />
P.O. Box  43844-00100<br />
Nairobi<br />
Website: <a href="http://www.ku.ac.ke">http://www.ku.ac.ke</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td valign="top"><p>EGERTON  UNIVERSITY<br />
P.O. Box  536-20115<br />
Egerton<br />
Website: http://www.egerton.ac.ke</p></td>
                            <td valign="top"><p>JOMO KENYATTA  UNIVERSITY OF AGRICULTURE AND TECHNOLOGY<br />
P.O. Box  6200-00200<br />
Nairobi<br />
Website:  <a href="http:// www.jkuat.ac.ke">http:// www.jkuat.ac.ke</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td valign="top"><p>MOI UNIVERSITY<br />
P.O. Box  3900-30100<br />
Eldoret<br />
Website:  http://www.mu.ac.ke</p></td>
                            <td valign="top"><p>MASENO  UNIVERSITY<br />
P.O. Box  333-40105<br />
Maseno<br />
Website:  <a href="http:// www.maseno.ac.ke">http:// www.maseno.ac.ke</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td valign="top"><p>MASINDE MULIRO  UNIVERSITY OF SCIENCE AND TECHNOLOGY<br />
P.O. Box  190-50100<br />
Kakamega<br />
Website:  <a href="http:// www.wust.ac.ke"> http:// www.wust.ac.ke</a></p></td>
                            <td valign="top">&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2">&nbsp;</td>
                          </tr>
                          <tr>
                            <td colspan="3"><h4>2. PRIVATE UNIVERSITIES</h4></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td><p>University of  Eastern Africa – Baraton<br />
                              P.O. Box 2500-30200,<br />
                              Eldoret<br />
  							 Website: <a href="http://www.ueab.ac.ke">http:// www.ueab.ac.ke </a></p></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                          <tr>
                            <td colspan="3" valign="top"><h4>3. GOVERNMENT PUBLIC RESEARCH INSTITUTIONS</h4></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Kenya  Agricultural Research Institute (KARI)<br />
                              P.O. Box 57811-00200<br />
                              Nairobi.
                              Website:  <a href="http://www.kari.org">http://www.kari.org</a></p></td>
                            <td valign="top"><p>Kenya Medical  Research Institute (KEMRI)<br />
                              P.O. Box 4840-00200<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.kemri.org">http://www.kemri.org</a></p></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Kenya Marine  and Fisheries Research Institute (KEMFRI)<br />
                              P.O. Box 81651-080100<br />
                              Mombasa<br />
  							  Website:  <a href="http://www.kmfri.co.ke">http://www.kmfri.co.ke</a></p></td>
                            <td valign="top"><p>Kenya  Industrial Research and Development Institute (KIRDI)<br />
                              P.O. Box 30650-00100<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.kirdi.go.ke">http://www.kirdi.go.ke</a></p></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Kenya  Trypanosomiasis Research Institute (KETRI)<br />
                              P.O. Box 57811-00200<br />
                              Nairobi<br />
  							 Website:  <a href="http:// www.kari.org">http:// www.kari.org</a></p></td>
                          <td valign="top"><p>National  Museums of Kenya (NMK)<br />
                              P.O. Box 40658-00100<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.museums.or.ke">http://www.museums.or.ke</a></p></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td colspan="2" valign="top"><hr /></td>
                          </tr>
                          <tr>
                            <td valign="top">&nbsp;</td>
                            <td valign="top"><p>Institute of  Primate Research (IPR)<br />
                              National  Museums of Kenya<br />
                              P.O. Box 24481-00502<br />
                              Nairobi.<br />
  							  Website:  <a href="http://www.museums.or.ke">http://www.museums.or.ke</a></p></td>
                            <td valign="top"><p>Kenya Wildlife  Service (KWS)<br />
                              P.O. Box 40241-00100<br />
                              Nairobi<br />
  							  Website:  <a href="http://www.kws.org">http://www.kws.org</a></p></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td><p>Kenya Forestry  Research Institute (KEFRI)<br />
                              P.O. Box 20412-00200<br />
                              Nairobi<br />
  							  Website: <a href="http://www.kefri.org">http://www.kefri.org</a></p></td>
                            <td>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>&nbsp;</td>
                            <td colspan="2"><hr /></td>
                          </tr>
                      </table></p>
														</div>
													</div>
												</div>

												<div class="panel panel-default">
													<div class="panel-heading">
														<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Lead agencies and their mandates</a></h4> </div>
													<div id="collapse5" class="panel-collapse collapse">
														<div class="panel-body">
															<p> <table width="100%">
                           <tr>
                             <td width="4%" valign="top"><strong>S.NO.</strong></td>
                             <td width="41%" valign="top"><strong>COMPETENT NATIONAL AUTHORITY</strong></td>
                             <td width="55%" valign="top"><strong>MANDATES/ MAIN ROLE</strong></td>
                           </tr>
                           <tr>
                             <td colspan="3" valign="top"><hr/></td>
                           </tr>
                           <tr>
                             <td valign="top">1.</td>
                             <td valign="top">Kenya Wildlife Service (KWS) </td>
                             <td valign="top">Management of wildlife genetic resources, and issuance of PIC, MAT and export permit</td>
                           </tr>
                           <tr>
                             <td valign="top">2.</td>
                             <td valign="top">Kenya Forest Service (KFS) </td>
                             <td valign="top">Management of forest genetic resources and associated biodiversity</td>
                           </tr>
                           <tr>
                             <td valign="top">3.</td>
                             <td valign="top">National Museums of Kenya (NMK) </td>
                             <td valign="top">Management of cultural heritage, natural history collections and GRs obtained from monuments and heritage sites. </td>
                           </tr>
                           <tr>
                             <td valign="top">4.</td>
                             <td valign="top">Department of Veterinary Services</td>
                             <td valign="top">Animal Health Certificate</td>
                           </tr>
                           <tr>
                             <td valign="top">5.</td>
                             <td valign="top">Public Universities &amp; Other Public Research  Institutes</td>
                             <td valign="top">Issuance of Letter of Affiliation and conclusion of Collaborative Research Agreements or MOUs</td>
                           </tr>
                           <tr>
                             <td valign="top">6.</td>
                             <td valign="top">Department of Immigration</td>
                             <td valign="top">Issuance of Researcher Pass</td>
                        </tr>
                           <tr>
                             <td valign="top">7.</td>
                             <td valign="top">National Commission for Science, Technology &amp; Innovation (NACOSTI)</td>
                             <td valign="top">Issuance of Research Licence</td>
                           </tr>
                      </table></p>
														</div>
													</div>
												</div>

												<div class="panel panel-default">
													<div class="panel-heading">
														<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse6">Documents to be uploaded</a></h4> </div>
													<div id="collapse6" class="panel-collapse collapse">
														<div class="panel-body">
                                                                <p> <ul class="list1">
                                                                    <li>Research Proposal</li>
                                                                    <li>Letter of affiliation</li>
                                                                    <li>Letter from academic/research institute</li>
                                                                    <li>Collaborative agreement</li>
                                                                    <li>Resume</li>
                                                            	</ul>
                            								</p>
														</div>
													</div>
												</div>

												
											</div>
										</div>
									</div>
									<!-- End of FAQ -->
                
			</div>
		</div>
	</section>
    <!--End of Extra Info -->