<!-- About Us Content-->
	<section class="about">
		<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/info-banners/5.jpg">
			<div class="section-title ">
				<h2>
                	<span>ABS Info</span> Application Guidline
                </h2>
            </div>
		</section>
		<section class="section_sapce section_white">
			<div class="row">
				<div class="container">
					<div class="col-sm-12 col-md-12">
						<h1>Guideline to the Application Process</h1>
                        <hr />
                        
                         <h3 class="p-bottom10">A. Information Guiding the Applicant</h3>
                         <h4>1. The Applicant accesses important information related to ABS system in Kenya:</h4>
						 <ul class="list1">
                        	<li><p>Biological resources that require an ABS permit</p> </li> 
                            <li><p>A guide to the application process</p> </li>
                            <li><p>Required documents for the application</p> </li>
                            <li><p>A list of approved institutions for research affiliation purposes</p> </li> 
                            <li><p>Lead agencies and their mandates</p> </li>
                            <li><p>Other information (e.g. regarding export of materials, applications for visas).</p> </li>
                        </ul>
                        
                        <!--Section 3-->
						<hr>
                        <h3 class="p-bottom10">B. Applicant Registration</h3>
                         <h4><p>1. The applicant creates an account by filling a registration form</h4>
						 <ul class="list1">
                        	<li><p>The applicant provides personal details: (bio data, email, address, identification details etc.) </p></li> 
                            <li><p>The Applicant uploads a passport-size photo, and copy of ID card or passport. </p>
                             <p>i. Applicant may preview, edit and save form details. </p>
                            </li>
                            <li><p>The applicant submits the registration form </p>
                            <p> ii. If all form fields are completed and required attachments are uploaded, a "Submit Successful" status is returned. </p>
                            <p> iii.Else, information is provided to the user regarding details that require correction, this is done by the system highlighting the sections where corrections or researcher input is required.</p>
							</li>
                            <li><p>The system creates an account and emails the user log-in credentials.</p></li> 
                        </ul>
                        
                        
                        <!--Section 3-->
						<hr>
                        <h3 class="p-bottom10">C. Harmonized Application Form</h3>
                        
						 <ol class="list1">
                        	<li><p>The Applicant logs in to fill in the necessary documents.</p></li> 
                            <li><p>The Applicant specifies whether he/she is a student or not.</p></li>
                            <li><p>The Applicant specifies whether he/she is applying as an individual, from an academic institution or company/research program.</p></li>
                            <li><p>The Applicant provides additional information such as legal officer contact details for their institution, researcher IDs etc.</p></li> 
                            <li><p>The Applicant is invited to upload a set of standard documents required by the authorities. This is likely to include.</p>
                                <ul class="list1">
                                    <li><p>Evidence of legal registration of the organisation. </p></li>
                                    <li><p>The research proposal and budget (principle of full transparency).</p></li>
                                    <li><p>Letter of affiliation with a local institution e.g. University of Nairobi. </p></li>
                                    <li><p>Curriculum Vitae.</p></li>
                                    <li><p>PIC and MAT.</p></li>
                                </ul>	
							</li> 
                            <li><p>The Applicant is required to answer a trigger question on whether they will be collecting biological or genetic material in Kenya (with due consideration for digital sequence information). <p> Where answer is negative the system opens up a standard NACOSTI application form. </p>
                            <p> i. The applicant completes the form as required (i.e. fills the form and uploads required attachments), and submits.</p>
                            <p> ii.NACOSTI's process follows.</p>
                            <li><p>If the answer is positive; the Applicant enters the ABS Pathway for the processing of applications.</p></li>
                            </li> 
                        </ol>
                        
					</div>

				</div>
			</div>
		</section>