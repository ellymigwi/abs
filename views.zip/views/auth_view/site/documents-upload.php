<!-- About Us Content-->
	<section class="about">
		<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/info-banners/5.jpg">
			<div class="section-title ">
				<h2>
                	<span>ABS Info</span> Document to be uploaded
                </h2>
            </div>
		</section>
		<section class="section_sapce section_white">
			<div class="row">
				<div class="container">
					<div class="col-sm-12 col-md-12">
						<h1>Document to be uploaded</h1>
                        <hr />
                            <ul class="list1">
                                <li>Research Proposal</li>
                                <li>Letter of affiliation</li>
                                <li>Letter from academic/research institute</li>
                                <li>Collaborative agreement</li>
                                <li>Resume</li>
                            </ul>
					</div>

				</div>
			</div>
		</section>