<!-- About Us Content-->
	<section class="about">
		<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/info-banners/5.jpg">
			<div class="section-title ">
				<h2>
                	<span>ABS Info</span> Biological Resources that Require ABS Permit
                </h2>
            </div>
		</section>
		<section class="section_sapce section_white">
			<div class="row">
				<div class="container">
					<div class="col-sm-12 col-md-12">
						<h1>Biological Resources that Require ABS Permit</h1>
                        <hr />
                            <ul class="list1">
                                <li>Insects</li>
                                <li>Animals</li>
                                <li>Flowers</li>
                                <li>Amphibians</li>
                                <li>Birds</li>
                                <li>Microbiota</li>
                                <li>Microbez</li>
                            </ul>
                        
                       
					</div>

				</div>
			</div>
		</section>