<!-- About Us Content-->
	<section class="about">
		<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/info-banners/5.jpg">
			<div class="section-title ">
				<h2>
                	<span>ABS Info</span> Lead Agencies
                </h2>
            </div>
		</section>
		<section class="section_sapce section_white">
			<div class="row">
				<div class="container">
					<div class="col-sm-12 col-md-12">
                        <h3 class="p-bottom10">Lead Agencies & Mandates</h3>
                        <hr />
                      <p>  
                      <table width="100%">
                           <tr>
                             <td width="4%" valign="top"><strong>S.NO.</strong></td>
                             <td width="41%" valign="top"><strong>COMPETENT NATIONAL AUTHORITY</strong></td>
                             <td width="55%" valign="top"><strong>MANDATES/ MAIN ROLE</strong></td>
                           </tr>
                           <tr>
                             <td colspan="3" valign="top"><hr/></td>
                           </tr>
                           <tr>
                             <td valign="top">1.</td>
                             <td valign="top">Kenya Wildlife Service (KWS) </td>
                             <td valign="top">Management of wildlife genetic resources, and issuance of PIC, MAT and export permit</td>
                           </tr>
                           <tr>
                             <td valign="top">2.</td>
                             <td valign="top">Kenya Forest Service (KFS) </td>
                             <td valign="top">Management of forest genetic resources and associated biodiversity</td>
                           </tr>
                           <tr>
                             <td valign="top">3.</td>
                             <td valign="top">National Museums of Kenya (NMK) </td>
                             <td valign="top">Management of cultural heritage, natural history collections and GRs obtained from monuments and heritage sites. </td>
                           </tr>
                           <tr>
                             <td valign="top">4.</td>
                             <td valign="top">Department of Veterinary Services</td>
                             <td valign="top">Animal Health Certificate</td>
                           </tr>
                           <tr>
                             <td valign="top">5.</td>
                             <td valign="top">Public Universities &amp; Other Public Research  Institutes</td>
                             <td valign="top">Issuance of Letter of Affiliation and conclusion of Collaborative Research Agreements or MOUs</td>
                           </tr>
                           <tr>
                             <td valign="top">6.</td>
                             <td valign="top">Department of Immigration</td>
                             <td valign="top">Issuance of Researcher Pass</td>
                        </tr>
                           <tr>
                             <td valign="top">7.</td>
                             <td valign="top">National Commission for Science, Technology &amp; Innovation (NACOSTI)</td>
                             <td valign="top">Issuance of Research Licence</td>
                           </tr>
                      </table></p>
					</div>

				</div>
			</div>
		</section>