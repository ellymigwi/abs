<!-- Breadcrumps -->
	<section class="breadcrumbs">
		<div class="row">
			<div class="container">
				<div class="col-sm-6">
					<h1>Contact</h1>
                </div>
				<div class="col-sm-6">
					<ol class="breadcrumb">
						<li>You are here: </li>
						<li><a href="<?php echo base_url('auth/index/');?>">Home</a> </li>
						<li>Pages </li>
						<li class="active">Contact</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Breadcrumps -->

	<!-- Contact -->
	<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/subbanners/4.jpg">
		<div class="section-title ">
			<h2><span>Contact Us</span>Get in Toutch</h2>
        </div>
	</section>


    <!-- Support -->
	<div class="needsupport section_sapce bg_gray">
		<div class="row">
			<div class="container">
				<div class="col-sm-12">
					<div class="section-title margin-b50">
						<h2><span>Help</span>Quick Support</h2>
                    </div>
                    <div class="col-sm-4 margin-b30">
                        <div class="text-center padding30  main-feature">
                        	<div class="ribbon ribbon-small text-white">
                                <div class="ribbon-content bg_dark text-uppercase">Tollfree</div>
                            </div>
                            <i class="fa fa-headphones fa-3x text_primary square-border-icon"></i>
                            <h3>24/7 Call Center Support</h3>
                            <p>	<?=$stel; ?></p>
                        </div>
                    </div>

                    <div class="col-sm-4 margin-b30">
                        <div class="text-center padding30  main-feature">
                            <i class="fa fa-envelope-open fa-3x text_primary square-border-icon"></i>
                            <h3>Email Support</h3>
                            <p>	<?=$semail; ?></p>
                        </div>
                    </div>

                    <div class="col-sm-4 margin-b30">
                        <div class="text-center padding30  main-feature relative">
                            <i class="fa fa-map-marker fa-3x text_primary square-border-icon"></i>
                            <h3>Locations</h3>
                            <p>	<?=$slocation; ?></p>
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>
	<!-- End of Support -->


	<section class="contact section_sapce2">
		<div class="row">
			<div class="container">
				<div class="col-sm-6 col-md-8">
					<h3 class="text-uppercase margin-bottom-0">Contact us <?=$site; ?></h3>
                    <div class="contactForm row m0">
                        <div class="contactForm">
                            <div class="row">
                                <div class="successMessage alert alert-success alert-dismissible fade in margin-top-30" role="alert" style="display: none">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="fa fa-times"></i></button>
                                    <strong>Well done !</strong> Thank You! We will contact you shortly.
                                </div>
                            </div>
							<br>
                            <form role="form" action="form/send.php" method="post" class="contact_form contactForm validateIt" data-email-subject="Contact Form" data-show-errors="true">

                            <div class="row">
                                <div class="form-group">
                                    <input required type="text" name="field[]" class="name form-control" placeholder="Name">
                                </div>
                                <div class="form-group">
                                    <input required type="email" name="field[]" class="email form-control"  value="<?=$semail; ?>" placeholder="E-mail" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <input required type="tel" name="field[]" class="phonenumber form-control" placeholder="Phone">
                                </div>
                                <div class="form-group">
                                    <textarea class="form-control" rows="4" name="field[]" required placeholder="Your message"></textarea>
                                </div>
                                <button type="submit" class="submit btn btn-block btn-primary">Send Message</button>
                            </div>
                            </form>
                        </div>
                    </div>

				</div>

				<div class="col-sm-6 col-md-3 col-md-offset-1">
					<!-- Contact Address Area Start -->
					<div class="contact-address">
						<h3 class="text-uppercase">get in touch</h3>

						<!-- Contact Address Area Start -->
                        <address>
                            <p><i class="fa fa-home"></i> <span><?=$side_menus; ?></span></p>
                            <p><i class="fa fa-fax"></i> <span><?=$contacts; ?></span></p>
                        </address>
						<!-- Contact Address Area End -->

						<!-- Contact Social Links Start -->
						<div>
							<ul class="list-inline" style="margin-left:30px;">
								<li><a href="<?=$facebook; ?>"><i class="fa fa-facebook"></i></a></li>
								<li><a href="<?=$twitter; ?>"><i class="fa fa-twitter"></i></a></li>
								<!--<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-behance"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-feed"></i></a></li>-->
							</ul>
						</div>
						<!-- Contact Social Links End -->
					</div>
					<!-- Contact Address Area End -->
				</div>
			</div>
		</div>
	</section>
	<!-- End of Contact  -->