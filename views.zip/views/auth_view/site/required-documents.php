<!-- About Us Content-->
	<section class="about">
		<section class="section_sapce section_primary cover-image" data-image-src="<?php echo base_url();?>assets/images/info-banners/5.jpg">
			<div class="section-title ">
				<h2>
                	<span>ABS Info</span> Required Documents for the Application
                </h2>
            </div>
		</section>
		<section class="section_sapce section_white">
			<div class="row">
				<div class="container">
					<div class="col-sm-12 col-md-12">
						<h1>Required Documents for the Application</h1>
                        <hr />
                        <h3>1. Prior Informed Consent Description</h3>
<p>Prior Informed Consent (PIC) is the permission given by the provider or competent national authority of a provider country to a user prior to accessing genetic resources, in line with an appropriate national legal and institutional framework. It is the main ABS tool that is usually negotiated between the provider and the user of GR through an agreement involving mutually agreed terms (MAT). In Kenya, PIC is a written document and granted upon completing a Form modelled along Appendix I of the ABS Toolkit. PIC requires the user to disclose contact details, local affiliate, project type, location and nature of genetic resources to be accessed, method of collection, role of local community or lead agency, benefit sharing mechanisms and declaration of accrued benefits. It is the duty of the potential GR user to make full disclosure to the provider so as to make informed decision to grant access or not. In Kenya, PIC is a negotiated document (See appendix I) by parties and requires minutes of meetings with community or letter of support from lead agency. 
download templae</p>

<p><a href="<?=base_url('assets/uploads/Prior Informed Consent - template.pdf'); ?>">[Download Template]</a ></p>


						<hr />
                        <h3>2. Mutually Agreed Terms Description</h3>
<p>Mutually Agreed Terms (MAT) is an agreement reached between the providers of genetic resources and users on the conditions of access and use of the resources, and the benefits to be shared between both parties. This agreement is negotiated in the presence of relevant lead agencies to ensure a fair access and equitable sharing of the benefits. In Kenya, MAT is a negotiated agreement by parties and requires minutes of meetings with community, permit, licence or letter of support from relevant lead agency as modelled in Appendix II. download template
</p>
<p><a href="<?=base_url('assets/uploads/Mutually Agreed Terms - Template.pdf'); ?>">[Download Template]</a ></p>


						<hr />
                        <h3>3. Material Transfer Agreement Description</h3>
<p>Mutually Agreed Terms (MAT) is an agreement reached between the providers of genetic resources and users on the conditions of access and use of the resources, and the benefits to be shared between both parties. This agreement is negotiated in the presence of relevant lead agencies to ensure a fair access and equitable sharing of the benefits. In Kenya, MAT is a negotiated agreement by parties and requires minutes of meetings with community, permit, licence or letter of support from relevant lead agency as modelled in Appendix II. download template
</p>
<p><a href="<?=base_url('assets/uploads/Materials Transfer Agreement - Template.pdf'); ?>">[Download Template]</a ></p>


					</div>

				</div>
			</div>
		</section>