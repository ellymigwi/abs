    <!--  Subscribe -->
	<!--<div class="subscribe section_sapce4 bg_dark">
		<div class="row">
			<div class="container">
				<div class="col-sm-12 col-md-6">
					<div id="mc_embed_signup">
						<form class="form-inline validate" action="" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" novalidate>
							<div class="row no-gutter">
								<div class="col-sm-9">
									<input type="email" value="" name="EMAIL" class="form-control" id="mce-EMAIL" placeholder="Subscribe to our newsletter" required>
									<div style="position: absolute; left: -5000px;">
										<input type="text" name="b_f86de306ae229d9cca9373ff6_44e7c219bf" tabindex="-1" value="">
                                    </div>
								</div>
								<div class="col-sm-3">
									<input type="submit" value="SUBSCRIBE" name="subscribe" id="mc-embedded-subscribe">
                                </div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-sm-12 col-md-6">
					<h3>Newsletter</h3>
					<p>Get latest updates and offers.</p>
				</div>
			</div>
		</div>
	</div>-->
    <!--  End of Subscribe -->
    
    <!--  Footer -->
    <footer class="footer" style="padding:10px;">
       
            
        <!--<div class="row bg_white copyright">
            <div class="container">
                <div class=" padding-t30 clearfix">
                    <div class="col-sm-6">
                        <h4>Follow us</h4>
                        <div class="social-links">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-google-plus"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-pinterest"></i></a>
                        </div>
                    </div>
                    <div class="col-sm-6 text-right">
                         <h4>Payment Modes</h4>
                        <ul class="list-inline payment-icons">
                          <li><i class="fa fa-cc-mastercard fa-3x"></i></li>
                          <li><i class="fa fa-cc-visa fa-3x"></i></li>
                          <li><i class="fa fa-cc-amex fa-3x"></i></li>
                          <li><i class="fa fa-cc-discover fa-3x"></i></li>
                          <li><i class="fa fa-cc-paypal fa-3x"></i></li>
                          <li><i class="fa fa-google-wallet fa-3x"></i></li>
                      </ul>
                    </div>
                </div>
            </div>-->
           <!-- <hr>-->
            <p class="copyright text-center">Copyright © 2017 - 2018 ABS. All Rights Reserved</p>
       <!-- </div>-->
    </footer>
    <!--  End of Footer -->


    <!--  Back to Top -->
    <a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

    <!--  Scripts -->
	<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/hoverIntent.js"></script>
	<script src="<?php echo base_url();?>assets/js/superfish.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/owl.carousel.js"></script>
	<script src="<?php echo base_url();?>assets/js/wow.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/video-popup.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.circliful.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/waypoints.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.responsiveTabs.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.counterup.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.sticky.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.slicknav.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.slicknav.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/retina.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/jquery.parallax-1.1.3.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.countdown.js"></script>
	<script src="<?php echo base_url();?>assets/js/custom.js"></script>

	<script>
	$(document).on("ready", function(e) {
		var sync1 = $("#mainslider");
		var sync2 = $("#mainslider-nav");
		sync1.owlCarousel({
			singleItem: true,
			slideSpeed: 1000,
			paginationSpeed: 800,
			navigation: false,
			pagination: false,
			autoPlay: 7500,
			afterAction: syncPosition,
			responsiveRefreshRate: 200,
		});
		sync2.owlCarousel({
			items: 4,
			itemsDesktop: [1199, 4],
			itemsDesktopSmall: [979, 4],
			itemsTablet: [768, 3],
			itemsMobile: [479, 2],
			pagination: false,
			responsiveRefreshRate: 100,
			afterInit: function(el) {
				el.find(".owl-item").eq(0).addClass("synced");
			}
		});

		function syncPosition(el) {
			var current = this.currentItem;
			$("#mainslider-nav").find(".owl-item").removeClass("synced").eq(current).addClass("synced")
			if($("#mainslider-nav").data("owlCarousel") !== undefined) {
				center(current)
			}
		}
		$("#mainslider-nav").on("click", ".owl-item", function(e) {
			e.preventDefault();
			var number = $(this).data("owlItem");
			sync1.trigger("owl.goTo", number);
		});

		function center(number) {
			var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
			var num = number;
			var found = false;
			for(var i in sync2visible) {
				if(num === sync2visible[i]) {
					var found = true;
				}
			}
			if(found === false) {
				if(num > sync2visible[sync2visible.length - 1]) {
					sync2.trigger("owl.goTo", num - sync2visible.length + 2)
				} else {
					if(num - 1 === -1) {
						num = 0;
					}
					sync2.trigger("owl.goTo", num);
				}
			} else if(num === sync2visible[sync2visible.length - 1]) {
				sync2.trigger("owl.goTo", sync2visible[1])
			} else if(num === sync2visible[0]) {
				sync2.trigger("owl.goTo", num - 1)
			}
		}
	});

	$(document).on("ready", function(e) {
		// ______________ TESTIMONIALS
		$("#testimonials-carousel").owlCarousel({
			items: 1,
			autoPlay: 5000,
			itemsDesktop: [1199, 1],
			itemsDesktopSmall: [979, 1],
			itemsTablet: [768, 1]
		});
		// ______________ PRICE TABS
		$('#shared-hosting-price-tabs').responsiveTabs({
			startCollapsed: 'accordion'
		});
		// ______________ FEATURES TABS
		$('#shared-hosting-features-tabs').responsiveTabs({
			startCollapsed: 'accordion'
		});
		// ______________ VIDEOPOPUP
		$("a.autoplay").VideoPopUp();
		$("a.noautoplay").VideoPopUp({
			autoplay: 0
		}); // Disable autoplay

		// ______________ COUNTDOWN
		$("#limited").countdown("2019/08/15", function(event) {
			$(this).text(
				event.strftime('%D Days %H:%M:%S')
			);
		});
		// ______________ PARTNERS
		$("#datacenter-partners").owlCarousel({
			autoPlay: 3000, //Set AutoPlay to 3 seconds
			items: 6,
			itemsDesktop: [1199, 5],
			itemsDesktopSmall: [979, 3],
			pagination: false
		});
		// ______________ PARALLAX
		$('.section-parallax').parallax("50%", 0.4);
		// ______________ STATS
		$('.statistics').waypoint(function() {
			$('#myStat1').circliful();
			$('#myStat2').circliful();
			$('#myStat3').circliful();
			$('#myStat4').circliful();

		}, {
			offset: 800,
			triggerOnce: true
		});
	});
	</script>
</body>

</html>