<?php echo $side_menu; ?>

</nav>