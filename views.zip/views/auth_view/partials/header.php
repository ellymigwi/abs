<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$title; ?></title>
	<link rel="shortcut icon" href="images/icons/favicon.png" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,700,800" rel="stylesheet">

	<!-- Bootstrap & Styles -->
	<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/bootstrap-theme.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/block_grid_bootstrap.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/owl.carousel.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/owl.theme.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/animate.min.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/css/jquery.circliful.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/css/slicknav.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/css/video-popup.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Loading-->
    <div class="loading animated-middle">
        <div class="loader">Loading...</div>
    </div>

    <!-- Top MiniBar-->
    <section class="topminibar">
     <div class="row">
     	<div class="container">
            <div class="col-sm-12 col-md-6 col-xs-12">
               <!--<ul class="list-inline">
                  <li><a href="#"><i class="fa fa-commenting"></i><span> Live Chat</span></a></li>
                  <li><a href="contact.html"><i class="fa fa-headphones"></i><span> Support</span></a></li>
               </ul>-->
            </div>
            <div class="col-sm-12 col-md-6 col-xs-12">
               <!--<div class="text-right loginbuttons">
                  <ul class="list-inline">
                  <li><a href="#"><i class="fa fa-commenting"></i><span> Live Chat</span></a></li>
                  <li><a href="contact.html"><i class="fa fa-headphones"></i><span> Support</span></a></li>
               </ul>-->
            </div>
         </div>
     	</div>
     </div>
    </section>
    <!-- End of Top MiniBar-->

	<!-- Top Bar-->
	<div class="top">
		<div class="row">
			<div class="container">
				<div class="col-sm-3">
					<div class="logo" style="width:550px;">
						<a href="<?php echo base_url('auth/index'); ?>"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="" ></a>
					</div>
				</div>
				<div class="col-sm-9">
					<ul class="nav nav-pills pull-right">
						<!--<li><b>Call Us : 1-855-476-6199</b></li>
						<li>
							<div class="btn-group country_select">
								<button aria-expanded="false" aria-haspopup="true" class="btn btn-link dropdown-toggle" data-toggle="dropdown" type="button">India
                                	<b class="caret"></b>
                                </button>
								<ul class="dropdown-menu">
									<li> <a href="#">India</a> </li>
									<li> <a href="#">Iran</a> </li>
									<li> <a href="#">England</a> </li>
									<li> <a href="#">Syria</a> </li>
									<li> <a href="#">Bangladesh</a> </li>
								</ul>
							</div>
						</li>
						<li> <a href="login.html">Login</a> </li>-->
						<li class="cart-link"> <a href="<?php echo base_url('auth/index/signin/');?>" class="btn btn-sm btn-new"><i class="fa fa-user"></i> <b>Account Login</b></a></li>
						<!--<a href="cart.html" class="btn btn-sm btn-default"><i class="fa fa-pencil"></i>  Sign Up </a>-->
						<li class="cart-link"> <a href="<?php echo base_url('auth/index/signup/');?>" class="btn btn-sm"><i class="fa fa-pencil"></i> <b>Create an Account</b></a> </li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- End of Top Bar-->