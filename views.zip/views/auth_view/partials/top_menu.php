<!-- Main Menu -->
	<div class="main_menu">
		<div class="row">
			<div class="container">
				<div class="col-sm-8">
					<nav id="desktop-menu" >
						<ul class="sf-menu" id="navigation">
							<li class="current"> <a href="<?php echo base_url('auth/index/');?>">Home</a></li>
                            <!--<li> <a href="#">About Us</a></li>-->
							<li> <a href="#">ABS Information</a>
								<ul>
									<li> <a href="<?php echo base_url('auth/index/biological-resources');?>">Biological Resources</a> </li>
									<li> <a href="<?php echo base_url('auth/index/application-guidline');?>">Appication Process</a> </li>
									<li> <a href="<?php echo base_url('auth/index/required-documents');?>">Required Documents</a> </li>
									<li> <a href="<?php echo base_url('auth/index/approved-institutions');?>#">Approved Institutions</a> </li>
									<li> <a href="<?php echo base_url('auth/index/lead-agencies');?>">Lead agencies & Mandate</a> </li>
                                    <li> <a href="<?php echo base_url('auth/index/documents-upload');?>">Documents to be Uploaded</a> </li>
								</ul>

							</li>
							<li> <a href="#">Contact Us</a>
                            	<ul>
									<li> <a href="<?php echo base_url('auth/index/contact/kws');?>">KWS</a> </li>
									<li> <a href="<?php echo base_url('auth/index/contact/nema');?>">NEMA</a> </li>
									<li> <a href="<?php echo base_url('auth/index/contact/nacosti');?>">NACOSTI</a> </li>
									<li> <a href="<?php echo base_url('auth/index/contact/kfs');?>#">KFS</a> </li>
									<li> <a href="<?php echo base_url('auth/index/contact/kephis');?>">KEPHIS</a> </li>
                                    <li> <a href="<?php echo base_url('auth/index/contact/dvs');?>">DVS</a> </li>
								</ul>
                            </li>
						</ul>
					</nav>
				</div>
				<!--<div class="col-sm-4">
					<ul class="sf-menu pull-right" id="user-menu">
						<li> <a href="contact.html"><i aria-hidden="true" class="fa fa-commenting"></i></a> </li>
						<li> <a href="#"><i aria-hidden="true" class="fa fa-user"></i> </a>
							<ul>
								<li> <a href="<?php echo base_url('auth/index/signin/');?>">Login</a> </li>
								<li> <a href="<?php echo base_url('auth/index/forgot');?>">Forgot Password ?</a> </li>
							</ul>
						</li>
					</ul>
				</div>-->
			</div>
		</div>
	</div>
	<!-- End of Main Menu -->