 <!--  Footer -->
    <footer class="footer">      
        <div class="row bg_white copyright">
            <div class="container">
                <div class=" padding-t30 clearfix">
                  
                </div>
            </div>
            <hr>
            <p class="copyright text-center">Copyright © 2017 - 2018 ABS. All Rights Reserved</p>
        </div>
    </footer>
    <!--  End of Footer -->


    <!--  Back to Top -->
    <a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

    <!--  Scripts -->
	<script src="<?php echo base_url();?>assets/assets/vendor/jquery/jquery.js"></script>
	<!--<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/hoverIntent.js"></script>
	<script src="<?php echo base_url();?>assets/js/superfish.min.js"></script>
	<script src="<?php echo base_url();?>assets/js/owl.carousel.js"></script>-->
	<script src="<?php echo base_url();?>assets/js/wow.min.js"></script>

	<script src="<?php echo base_url();?>assets/js/custom.js"></script>
</body>

</html>