<!-- Slider -->
	<div class="slidercontainer">
		<div id="mainslider" class="owl-carousel">

          <div class="item"  style="height: 430px;">
				<div class="row full-width no-gutter section_sapce bg_primary cover-image2" data-image-src="<?php echo base_url();?>assets/images/slider/banner1.jpg">
                   <!-- <div class="container">
                        <div class="col-sm-12 col-md-6 custom-info4-column radius" >
                            <div class="thequote">
                                <h5 class="text_dark">Apply for ABS Permits ChapChap!</h5>
                                <p class="text_dark">Now available across all devices!</p>
                                <a href="register.html" class="btn btn-lg btn-new">Create an Account</a>
                            </div>
                        </div>
                    </div>-->
				</div>
            </div>

			<!--<div class="item"  style="height: 430px;">
				<div class="row full-width no-gutter section_sapce bg_primary cover-image2" data-image-src="<?php echo base_url();?>assets/images/slider/slide-3.jpg">
                    <div class="container">
                        <div class="col-sm-12 col-md-8 center-block custom-info-column outer-glow">
                            <div class="thequote">
                                <h5>TheHost is an ICANN accredited leading provider</h5>
                                <p>We are is an ICANN accredited leading provider of web-presence solutions to small-businesses</p>
                                <a href="#" class="btn btn-lg btn-new">Buy Now</a>
                            </div>
                        </div>
                    </div>
				</div>
            </div>-->
		</div>
	</div>
	<!-- End of Slider -->