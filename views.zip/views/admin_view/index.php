 <div class="pcoded-content">
            <div class="pcoded-inner-content">
                     <div class="main-body">
                                <div class="page-wrapper">

                                    <div class="page-body">
                                        <div class="row">
                                        
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">
                                                        <i class="icofont icofont-pie-chart bg-c-blue card1-icon"></i>
                                                        <span class="text-c-blue f-w-600">My applications</span>
                                                        <h4> 1 </h4>
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i class="text-c-blue f-16 icofont icofont-warning m-r-10"></i><a href="">View All</a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- card1 end -->
                                            
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">
                                                        <i class="icofont icofont-ui-home bg-c-pink card1-icon"></i>
                                                        <span class="text-c-pink f-w-600">Notifications / Messages</span>
                                                        <h4>2</h4>
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i class="text-c-pink f-16 icofont icofont-calendar m-r-10"></i><a href="">View All</a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- card1 end -->
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">
                                                        <i class="icofont icofont-warning-alt bg-c-green card1-icon"></i>
                                                        <span class="text-c-green f-w-600">My Profile</span>
                                                        <h4>1</h4>
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i class="text-c-green f-16 icofont icofont-tag m-r-10"></i><a href="<?=base_url('account/index/frm_profile'); ?>">View / Edit Profile</a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- card1 end -->
                                            
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">
                                                        <i class="icofont icofont-social-twitter bg-c-yellow card1-icon"></i>
                                                        <span class="text-c-yellow f-w-600">News</span>
                                                        <h4>+562</h4>
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i class="text-c-yellow f-16 icofont icofont-refresh m-r-10"></i><a href="">View All</a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- card1 end -->
                                        </div><!-- End row-->                                        
                                 </div><!-- End panel--> 
                                 
                                 
                                 <div class="page-body">
                                        <div class="row">
                                        
                                            <!-- Visitor Map Start -->
                                            <div class="col-md-12 col-xl-7 ">
                                                
                                                	<div class="card unique-visitor-card o-hidden bg-c-green green-contain-card ">
                                                        <!--<div class="card-block-big p-t-30 ">
                                                            <h4 class="p-t-0">Summer Hits You Need For Your 2017 Playlist</h4>
                                                        </div>-->
                                                        <div class="card-header">
                                                            <div class="card-header-left ">
                                                                <h4 class="p-t-0">ABS PERMIT APPLICATION</h4>
                                                            </div>
                                                    	</div>
                                                         <div class="card m-b-0 ">
                                                        <div class=" card-block-big p-t-50 p-b-40 ">
                                                            	<strong>To register follow the steps Below.</strong></p>
                                                                <p class="card-text">1. Fill out the Registration form by clicking Register Button below.</p>
                                                                <p class="card-text">2. Fill all sections as directed</p>
                                                           
                                                                <!--<a href="<?=base_url('account/index/frm_register'); ?>" class="btn btn-danger"><b>APPLY NOW </b> <i class="fa fa-arrow-circle-right"></i></a></p>-->
                                                                 <a href="<?=base_url('account/index/frm_register'); ?>"><button class="btn btn-primary btn-block btn-out-dashed"><i class="icofont icofont-user-alt-3"></i> <b>Research Application / Submit research Proposal</b></button></a>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-12 col-xl-5 ">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5 class="card-header-text">APPLICATION PROCESS</h5>
                                                    </div>
                                                    <div class="card-block accordion-block color-accordion-block">
                                                        <div class="color-accordion" id="color-accordion">
                                                            <a class="accordion-msg b-none">Guideline to the Application Process</a>
                                                            <div class="accordion-desc">
                                                                <p>
                                                                   Information guiding researchers to the application process can be accessed by Clicking <a href="<?=base_url('auth/index/application-guidline'); ?>" target="_blank"> <span style="color:#600">Here>> </span></a>
                                                                </p>
                                                            </div>
                                                            <a class="accordion-msg bg-dark-primary b-none">Required Documents</a>
                                                            <div class="accordion-desc">
                                                            Information guiding researchers to the required Documents can be accessed by Clicking <a href="<?=base_url('auth/index/required-documents'); ?>" target="_blank"> <span style="color:#600">Here>> </span></a>
                                                                 
                                                            </div>
                                                            <!--<a class="accordion-msg bg-darkest-primary b-none">Lorem Message3</a>
                                                            <div class="accordion-desc">
                                                                <p>
                                                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has
                                                                    survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing
                                                                    Lorem Ipsum passages, and more .
                                                                </p>
                                                            </div>-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Visitor Map End -->

                                        </div>
                                    </div>
                                </div>
                                                                   
                         </div>
                   </div>
             </div>
       </div>