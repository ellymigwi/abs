<div class="pcoded-content">
                    <div class="pcoded-inner-content">

                        <!-- Main-body start -->
                        <div class="main-body">
                            <div class="page-wrapper">
                                <!-- Page-header start -->
                                <div class="page-header card">
                                    <div class="row align-items-end">
                                        <div class="col-lg-8">
                                            <div class="page-header-title">
                                                <i class="icofont icofont-navigation-menu bg-c-green"></i>
                                                <div class="d-inline">
                                                    <h4>ABS RESEARCH TOPICS/THEMES</h4>
                                                    <span>Below is a list of ABS Authorities</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="page-header-breadcrumb">
                                                <ul class="breadcrumb-title">
                                                    <li class="breadcrumb-item">
                                                        <a href="<?=base_url('account/index'); ?>">
                                                            <i class="icofont icofont-growth"></i>
                                                        </a>
                                                    </li>
                                                    <li class="breadcrumb-item"><a href="#!">ABS Research Topics</a>
                                                    </li>
                                                    <li class="breadcrumb-item"><a href="#!">Research</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Page-header end -->

                                <!-- Page-body start -->
                                <div class="page-body">
                                    <div class="row">
                                      <div class="col-sm-12">
                                            <!-- Zero config.table start -->
                                        <div class="card">
                                                <div class="card-header">
                                                    <span class="pull-right"><button type="button" class="btn btn-danger waves-effect waves-light btn-add"><i class="icofont icofont-ui-add"></i> Add New Research</button></span><div class="card-header-right"><i class="icofont icofont-spinner-alt-5"></i></div>
                                                </div>
                                                <div class="card-block">
                                                    <div class="dt-responsive table-responsive view-info"  >
                                                        <table id="simpletable" class="table table-striped table-bordered nowrap table-styling">
                                                            <thead>
                                                            <tr class="table-warning" style="color:#000">
                                                              <th>#</th>
                                                                <th>Authority_Name</th>
                                                                <th>Category</th>
                                                                <th>Address</th>
                                                                <th>Website</th>
                                                                <th>Action</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            
                                                                <tr>
                                                                  <td></td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                                                                    <td>
                                                                   <button class="btn btn-primary btn-outline-primary waves-effect waves-light btn-icon btn-edit" data-toggle="tooltip" data-placement="top" title="Edit"><i class="icofont icofont-ui-edit"></i></button>  
                                                                    <a href='' data-toggle="modal" data-target="#delete-Modal"><button class="btn btn-warning btn-outline-warning waves-effect waves-light btn-icon btn-delete" data-toggle="tooltip" data-placement="top" title="Delete"  ><i class="icofont icofont-ui-delete"></i></button></a>
                                                                    </td>
                                                                </tr>
                                                            
                                                            </tbody>
                                                            <tfoot>
                                                            </tfoot>
                                                        </table>
                                                       </div>  <!-- end of view-info -->
                                                       
                                                        <!-- start edit info -->
                                                        <div class="edit-info" style="display:none">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                   <div class="general-info">
                                                                      <div class="row">
                                                                                
                                         <div class="col-lg-12">
                                              <div class="page-body">
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                            <div class="card-block">
                                                                <div class="j-wrapper j-wrapper-640">
                                                                 <p> <div class="message alert alert-info border-info">All fields marked with <code>(*)</code> Asterisks are rquired.</div>  </p>
                                                                    <form action="#" method="post" class="j-pro" id="j-pro" novalidate>
                                                                        <div class="j-content">
                                                                            <!-- start email phone -->
                                                                            <div class="j-row">
                                                                                <!-- start name -->
                                                                                <div class="j-unit">
                                                                                     <label class="j-label">Institution Name <span class="text-danger"> *</span><br /><small></small></label>
                                                                                        <div class="j-input">
                                                                                            <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                            <input type="text" id="name" name="name">
                                                                                            <span class="j-tooltip j-tooltip-right-top">Institution Name</span>
                                                                                        </div>
                                                                                </div>
                                                                                <!-- end name -->
                                                                                
                                                                                 <!-- start name -->
                                                                                <div class="j-unit">
                                                                                    <label class="j-label">Institution Address</label>
                                                                                    <div class="j-input">
                                                                                        <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                        <input type="text" id="name" name="name">
                                                                                    </div>
                                                                                </div>
                                                                                <!-- end name -->
                                                                                
                                                                                 <!-- start name -->
                                                                                <div class="j-unit">
                                                                                       <label class="j-label">Institution Email</label>
                                                                                        <div class="j-input">
                                                                                            <label class="j-icon-right" for="email"><i class="icofont icofont-envelope"></i></label>
                                                                                            <input type="email" id="email" name="email">
                                                                                        </div>
                                                                                </div>
                                                                                <!-- end name -->
                                                                                
                                                                                <!-- start name -->
                                                                                <div class="j-unit">
                                                                                       <label class="j-label">Institution Website</label>
                                                                                        <div class="j-input">
                                                                                            <label class="j-icon-right" for="website"><i class="icofont icofont-envelope"></i></label>
                                                                                            <input type="email" id="website" name="website">
                                                                                        </div>
                                                                                </div>
                                                                                <!-- end name -->
                                                                                
                                                                           </div><!-- end /.row -->
                                                                        </div>
                                                                        <!-- end /.content -->
                                                                        
                                                                        <div class="j-footer text-center">
                                                                                 <a href="#!" class="btn btn-primary waves-effect waves-light m-r-20"><i class="icofont icofont-save"></i> Save</a>
                                                                                 <a href="#!" class="btn btn-warning waves-effect waves-light m-r-20" id="edit-cancel"><i class="icofont icofont-close-line-circled"></i>Cancel</a>
                                                                       </div>
                                                        		</form>
                                                			</div> 
                                                          </div> 
                                                       </div>
                                                    </div>
                             					</div>
                                                
                                                
                                                                         </div>
                                                                     </div>
                                                                 </div>
                                                            </div>
                                                       </div><!-- End of Edit Info -->
                                                       
        				  </div><!-- End of card block -->
  					</div><!--End of card -->
            	</div><!--col-sm-12 -->
          </div><!--page header -->
       </div><!--page-wrapper -->
     </div><!--main-body -->
   </div><!--pcoded-inner-content -->
</div><!--pcoded-content-->

<!-- Modals -->
<div class="modal fade" id="default-Modal" tabindex="-1" role="dialog">
     <div class="modal-dialog" role="document">
           <div class="modal-content">
                <div class="modal-header">
                 <h4 class="modal-title">Modal title</h4>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
                 </button>
           </div>
          <div class="modal-body">
          <h5>Static Modal</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing lorem impus dolorsit.onsectetur adipiscing</p>
 	</div>
 	<div class="modal-footer">
            <button type="button" class="btn btn-default waves-effect " data-dismiss="modal">Close</button>
           <button type="button" class="btn btn-primary waves-effect waves-light ">Save changes</button>
          </div>
     </div>
  </div>
</div>


<!-- Modals -->
<div class="modal fade" id="delete-Modal" tabindex="-1" role="dialog">
     <div class="modal-dialog" role="document">
           <div class="modal-content">
                <div class="modal-header">
                 <h4 class="modal-title">Confirm</h4>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
                 </button>
           </div>
          <div class="modal-body">
          
          <table width="50%" align="center">
            <tr>
              <td align="center"><button class="btn btn-warning btn-outline-warning waves-effect waves-light btn-icon" ><i class="icofont icofont-exclamation-circle"></i></button></td>
            </tr>
            <tr>
                  <td align="center"><h2>Are you sure?</h2>
                  <p>Your will not be able to recover this record!</p>
                 </td>
            </tr>
          </table>
          
 	</div>
 	<div class="modal-footer pull-center">
            <button type="button" class="btn btn-primary waves-effect waves-light ">Yes, delete it!</button>
            <button type="button" class="btn btn-default waves-effect " data-dismiss="modal">Cancel</button>
           
       </div>
     </div>
  </div>
</div>
