 <div class="pcoded-content">
                        <div class="pcoded-inner-content">
						<input type="hidden" name="base_url" id="base_url" value="<?=base_url(); ?>" />
                        
                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                <!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="row align-items-end">
                                            <div class="col-lg-8">
                                                <div class="page-header-title">
                                                    <i class="icofont icofont-clip-board bg-c-yellow"></i>
                                                    <div class="d-inline">
                                                         <h4>Harmonized Application Form</h4>
                                            <span>The applicant is requires to fill in neccessary documents</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="page-header-breadcrumb">
                                                    <ul class="breadcrumb-title">
                                                <li class="breadcrumb-item">
                                                    <a href="index.html">
                                                        <i class="icofont icofont-home"></i>
                                                    </a>
                                                </li>
                                                 <li class="breadcrumb-item"><a href="#!">Registration</a>
                                                </li>
                                                <li class="breadcrumb-item"><a href="#!">Harmonized Form</a>
                                                </li>
                                            </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->
                                    
                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="card">
                                                    
                                                    <div class="card-block">
                                                        <div class="j-wrapper j-wrapper-640">
                                                        <p> <div class="message alert alert-info border-info">All fields marked with <code>(*)</code> Asterisks are rquired.</div>  </p>
                                                            <form action="j-pro/php/action.php" method="post" class="j-pro j-multistep" id="j-pro" novalidate>
                                                                <!-- end /.header-->
                                                                <div class="j-content">
                                                                    <fieldset>
                                                                        <div class="j-divider-text j-gap-top-20 j-gap-bottom-45">
                                                                            <span>Step 1/4 - Personal info</span>
                                                                        </div>
                                                                        
                                                                        <!-- start email phone -->
                                                                        <div class="j-row">
                                                                            <div class="j-span6 j-unit">
                                                                                <label class="j-label">Are you a student? <span class="text-danger"> *</span><br /><small></small></label>
                                                                                <div class="j-unit">
                                                                                   <label class="j-input j-select">
                                                                                        <select name="position">
                                                                                            <option value="" selected>Choose option</option>
                                                                                            <option value="1">Yes</option>
                                                                                            <option value="2">No</option>
                                                                                        </select>
                                                                                        <i></i>
                                                                                    </label>
                                                                                 </div>
                                                                            </div>
                                                                            
                                                                            <div class="j-span6 j-unit">
                                                                                <label class="j-label">Applying As? <span class="text-danger"> *</span><br /><small></small></label>
                                                                               <div class="j-unit">
                                                                                   <label class="j-input j-select">
                                                                                        <select name="position">
                                                                                            <option value="" selected>Choose option</option>
                                                                                            <option value="Individual">Individual</option>
                                                                                            <option value="Academic Institution">Academic Institution</option>
                                                                                            <option value="Company">Company/Research Program</option>
                                                                                        </select>
                                                                                        <i></i>
                                                                                    </label>
                                                                                 </div>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end email phone -->
                                                                        
                                                                        <!-- start name -->
                                                                        <div class="j-unit">
                                                                             <label class="j-label">Researcher ID <span class="text-danger"> *</span><br /><small></small></label>
                                                                                <div class="j-input">
                                                                                    <label class="j-icon-right" for="adults"><i class="icofont icofont-ui-user"></i></label>
                                                                                    <input type="text" id="adults" name="adults">
                                                                                    <span class="j-tooltip j-tooltip-right-top">Researcher ID</span>
                                                                                </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                         <!-- start name -->
                                                                        <div class="j-unit">
                                                                            <label class="j-label">Institution Legal Officer Name</label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="name" name="name">
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                         <!-- start name -->
                                                                        <div class="j-unit">
                                                                               <label class="j-label">Institution Legal Officer Email</label>
                                                                                <div class="j-input">
                                                                                    <label class="j-icon-right" for="email"><i class="icofont icofont-envelope"></i></label>
                                                                                    <input type="email" id="email" name="email">
                                                                                </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                         
                                                                    
                                                                    <div class="j-divider-text j-gap-top-20 j-gap-bottom-45">
                                                                            <span>Upload below standard documents required by the authorities </span>
                                                                    </div>   
                                                                    
                                                                    <!-- start files -->
                                                                    <div class="j-row">
                                                                        <div class="j-span6 j-unit">
                                                                            <label class="j-label">Company Registration Document <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add Company Registration Document">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="j-span6 j-unit">
                                                                          <label class="j-label">Research Proposal <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add Research Proposal">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- end files -->
                                                                    
                                                                    <!-- start files -->
                                                                    <div class="j-row">
                                                                        <div class="j-span6 j-unit">
                                                                            <label class="j-label">Letter of Affiliation With local institution <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add Letter Document">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="j-span6 j-unit">
                                                                            <label class="j-label">Research Budget <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add Research Budget ">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- end files -->
                                                                    
                                                                    
                                                                    <!-- start files -->
                                                                    <div class="j-row">
                                                                        <div class="j-span6 j-unit">
                                                                           <label class="j-label">Curriculum Vitae <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add CV">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="j-span6 j-unit">
                                                                            <label class="j-label">PIC <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add PIC ">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- end files -->
                                                                    
                                                                    <!-- start files -->
                                                                    <div class="j-row">
                                                                        <div class="j-span6 j-unit">
                                                                           <label class="j-label">MAT <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add MAT">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="j-span6 j-unit">
                                                                            <label class="j-label">MTA <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input j-append-small-btn">
                                                                                <div class="j-file-button">
                                                                                    Browse
                                                                                    <input type="file" name="file1" onchange="document.getElementById('file1_input').value = this.value;">
                                                                                </div>
                                                                                <input type="text" id="file1_input" readonly="" placeholder="add MTA">
                                                                                <span class="j-hint">Only: doc / docx / xls /xlsx, less 1Mb</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- end files -->
                                                                        
                                                                    </fieldset>
                                                                    
                                                                    
                                                                    <fieldset>
                                                                        <div class="j-divider-text j-gap-top-20 j-gap-bottom-45">
                                                                            <span>Step 2/4 - Resources details</span>
                                                                        </div>
                                                                        <!-- start guests -->
                                                                        <div class="j-row">
                                                                            <div class="j-span12 j-unit">
                                                                                 <label class="j-label" style="text-align:center">Will you be Researching/Collecting and or exporting a genetic resource from Kenya?<span class="text-danger"> *</span><br /><small></small></label>
                                                                                <div class="j-span6 j-unit">
                                                                                   <label class="j-input j-select">
                                                                                        <select id="resources" name="name">
                                                                                            <option value="" selected>Choose option</option>
                                                                                            <option value="1">Yes</option>
                                                                                            <option value="2">No</option>
                                                                                        </select>
                                                                                        <i></i>
                                                                                    </label>
                                                                                 </div>
                                                                            </div>
                                                                          </div>
                                                                        <!-- end guests -->
                                                                        
                                                                    </fieldset>
                                                                    <fieldset>
                                                                        <div class="j-divider-text j-gap-top-20 j-gap-bottom-45">
                                                                            <span>Step 3/4 - Requirements</span>
                                                                        </div>
                                                                        
                                                                        <!-- start name -->
                                                                        <div class="j-unit">
                                                                            <label class="j-label">Type of genetic resource to be collected? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-input j-select">
                                                                                        <select name="position">
                                                                                            <option value="" selected>Choose option</option>
                                                                                            <option value="1">Plant Material</option>
                                                                                            <option value="2">Animal Material</option>
                                                                                            <option value="3">Forest/Protected Area Material</option>
                                                                                            <option value="4">Cultural & Heritage Material</option>
                                                                                            <option value="5">Plant or forest Seed</option>
                                                                                        </select>
                                                                                        <i></i>
                                                                                    </label>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                        
                                                                         <!-- start name -->
                                                                        <div class="j-unit">
                                                                             <label class="j-label">Species name of the genetic resource to be collected<span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="research" name="research" required>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                         <!-- start name -->
                                                                        <div class="j-unit">
                                                                              <label class="j-label">Scientific name of the genetic resource to be collected? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="research" name="research" required>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                         <!-- start name -->
                                                                        <div class="j-unit">
                                                                             <label class="j-label">Common name of the generic resource to be collected? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="research" name="research" required>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                         <!-- start name -->
                                                                        <div class="j-unit">
                                                                            <label class="j-label">Location or project area for genetic resource collection? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="research" name="research" required>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                        <!-- start name -->
                                                                        <div class="j-unit">
                                                                             <label class="j-label">Is the project area inside a conservation area, gazetted forest or protected area? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="research" name="research" required>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                        <!-- start name -->
                                                                        <div class="j-unit">
                                                                            <label class="j-label">Purpose of genetic resource allocation? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="name"><i class="icofont icofont-ui-user"></i></label>
                                                                                <input type="text" id="research" name="research" required>
                                                                            </div>
                                                                        </div>
                                                                        <!-- end name -->
                                                                        
                                                                        <div class="j-divider-text j-gap-top-20 j-gap-bottom-45">
                                                                            <span>Purpose of collection (Check all that apply) </span>
                                                                        </div>
                                                                        
                                                              <!-- start subscribe -->
                                                              <div class="j-row">
                                                              
                                                                  <div class="j-span6 j-unit j-input">
                                                                  
                                                                      <div class="checkbox-fade fade-in-primary">
                                                                         <label>
                                                                             <input type="checkbox" value="">
                                                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                             <span>Species management</span>
                                                                          </label>
                                                                      </div>
                                                                      <div class="checkbox-fade fade-in-primary">
                                                                         <label>
                                                                             <input type="checkbox" value="">
                                                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                             <span>Biomonitoring</span>
                                                                          </label>
                                                                      </div>
                                                                      <div class="checkbox-fade fade-in-primary">
                                                                         <label>
                                                                             <input type="checkbox" value="">
                                                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                             <span>Environental monitoring</span>
                                                                          </label>
                                                                      </div>
                                                                      <div class="checkbox-fade fade-in-primary">
                                                                        <label>
                                                                          <input type="checkbox" id="checkbox2" name="Language" value="CSS">
                                                                           <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                           <span>Others</span>
                                                                         </label>
                                                                    </div>
                                                              </div>
                                                              
                                                              <div class="j-span6 j-unit j-input">
                                                                      <div class="checkbox-fade fade-in-primary">
                                                                         <label>
                                                                             <input type="checkbox" value="">
                                                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                             <span>Species survey</span>
                                                                          </label>
                                                                      </div>
                                                                       <div class="checkbox-fade fade-in-primary">
                                                                         <label>
                                                                             <input type="checkbox" value="">
                                                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                             <span>Instructional</span>
                                                                          </label>
                                                                      </div>
                                                                      <div class="checkbox-fade fade-in-primary">
                                                                         <label>
                                                                             <input type="checkbox" value="">
                                                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                             <span>Research</span>
                                                                          </label>
                                                                      </div>
                                                              </div>
                                                              
                                                              <div class="j-span12 j-unit"><br />
                                                               <label class="j-label">Specify <span class="text-danger"> *</span><br /><small></small></label>
                                                               <div class="j-input">
                                                                  <label class="j-icon-right" for="children"><i class="icofont icofont-woman-in-glasses"></i>
            </label>
                                                                   <input type="text" id="nnn" name="nnn">
                                                                   <span class="j-tooltip j-tooltip-right-top">Genetic resource to be collected </span>
                                                             	</div>
                                                             </div>
                                                                                    
                                                           </div>
                                                            <!-- end subscribe -->
                                                                        
                                                           </fieldset>
                                                           
                                                           <fieldset>
                                                                  <div class="j-divider-text j-gap-top-20 j-gap-bottom-45">
                                                                     <span>Step 4/4 - Finish</span>
                                                                   </div>
                                                                        
                                                               <!-- start name -->
                                                               <div class="j-unit">
                                                                   <label class="j-label">Type of Research to be Carried out ? <span class="text-danger"> *</span><br /><small></small></label>
                                                                   <div class="j-input">
                                                                     <label class="j-icon-right" for="children"><i class="icofont icofont-woman-in-glasses"></i>
</label>
                                                                     <input type="text" id="names" name="names">
                                                                     <span class="j-tooltip j-tooltip-right-top">Research Details </span>
                                                                   </div>
                                                                </div>
                                                                <!-- end name -->
                                                                        
                                                                 <!-- start name -->
                                                               <div class="j-span12 j-unit">
                                                                            <label class="j-label">Number of proposed samples to be collected ? <span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="children"><i class="icofont icofont-woman-in-glasses"></i>
</label>
                                                                                <input type="text" id="children" name="children">
                                                                                <span class="j-tooltip j-tooltip-right-top">Number of samples</span>
                                                                            </div>
                                                                </div>
                                                                <!-- end name -->
                                                                
                                                               <!-- start name -->
                                                               <div class="j-span12 j-unit">
                                                                 <label class="j-label">Conservation status of the sample to be collected ?<span class="text-danger"> *</span><br /><small></small></label>
                                                                  <div class="j-input">
                                                                       <label class="j-icon-right" for="children"><i class="icofont icofont-woman-in-glasses"></i>
    </label>
                                                                       <input type="text" id="names" name="names">
                                                                       <span class="j-tooltip j-tooltip-right-top">Conservation status</span>
                                                                   </div>
                                                                </div>
                                                                <!-- end name -->
                                                                        
                                                               <!-- start name -->
                                                               <div class="j-span12 j-unit">
                                                                            <label class="j-label">Will research on traditional knowledge is to be collected ?<span class="text-danger"> *</span><br /><small></small></label>
                                                                            <div class="j-input">
                                                                                <label class="j-icon-right" for="names"><i class="icofont icofont-woman-in-glasses"></i>
</label>
                                                                                <input type="text" id="names" name="names">
                                                                                <span class="j-tooltip j-tooltip-right-top">traditional knowledge</span>
                                                                            </div>
                                                                </div>
                                                                <!-- end name -->
                                                                
                                                                <!-- start name -->
                                                                <div class="j-span12 j-unit">
                                                                  <label class="j-label">Will you need to export the collected genetic resourcess from kenya ?<span class="text-danger"> *</span><br /><small></small></label>
                                                                  <div class="j-input">
                                                                       <label class="j-icon-right" for="names"><i class="icofont icofont-woman-in-glasses"></i>
    </label>
                                                                       <input type="text" id="names" name="names">
                                                                        <span class="j-tooltip j-tooltip-right-top">genetic resourcess</span>
                                                                   </div>
                                                                </div>
                                                                <!-- end name -->
                                                                        
                                                             
                                                             <!-- end /.content -->
                                                            <!-- start name -->
                                                            <div class="j-span12 j-unit">
                                                                    <div class="j-footer">
                                                                    <table width="80%" align="center">
                                                                    
                                                                    	<tr>
                                                                        	<td> <button type="button" class="btn btn-primary alert-prompt m-b-10 btn-rev" onclick="_gaq.push(['_trackEvent', 'example', 'try', 'alert-prompt']);">Preview</button>
                                                                            </td>
                                                                            <td></td>
                                                                            <td> <button type="button" class="btn btn-primary alert-prompt m-b-10 btn-edit" onclick="_gaq.push(['_trackEvent', 'example', 'try', 'alert-prompt']);">Edit</button>
                                                                            </td>
                                                                            <td></td>
                                                                            <td> <button type="button" class="btn btn-primary alert-prompt m-b-10 btn-save" onclick="_gaq.push(['_trackEvent', 'example', 'try', 'alert-prompt']);">Save as Draft</button>
                                                                            </td>
                                                                            <td></td>
                                                                            
                                                                        </tr>
                                                                    </table>
                                                                 </div>  
                                                                  
                                                                </div>
                                                               <!-- end subscribe -->
                                                               
                                                               <div class="j-span12 j-unit">
                                                                   <div class="checkbox-fade fade-in-primary">
                                                                     <label><input type="checkbox" id="checkbox" name="Language" value="HTML">
                                                                     <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                                                     <span>I Agree with the natural legislation of kenya and conditions for acquiring an ABS permit</span>
                                                                    </label>
                                                                    </div>
                                                               </div>
                                                                        
                                                           </fieldset>
                                                           
                                                                    <!-- start response from server -->
                                                                    <div class="j-response"></div>
                                                                    <!-- end response from server -->
                                                                </div>
                                                                <!-- end /.content -->
                                                                <div class="j-footer">
                                                                    <button type="submit" class="btn btn-primary j-multi-submit-btn">Submit</button>
                                                                    <button type="button" class="btn btn-warning j-multi-next-btn">Next</button>
                                                                    <button type="button" class="btn btn-default m-r-20 j-multi-prev-btn">Back</button>
                                                                </div>
                                                                <!-- end /.footer -->
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page body end -->
                                </div>
                            </div>
                            <!-- Warning Section Starts -->
                            <!--<div id="styleSelector">

                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<!-- Required Jquery -->
<script type="text/javascript" src="<?php echo base_url();?>assets/admin/assets/bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		
		     //alert("yo");
			/*
			** Type Change
			*********************************************************/
			$( "#resources" ).change(function() {
				//alert($(this).val());
				
				if($(this).val()==2){
					window.location.href = 'https://www.nacosti.go.ke/';
					$(".btn").attr("disabled", true);
				}else{
					$(".btn").removeAttr("disabled");
				}
				
			});
	});
</script>