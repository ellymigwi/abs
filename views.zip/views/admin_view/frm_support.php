<div class="pcoded-content">
                        <div class="pcoded-inner-content">

                            <!-- Main-body start -->
                            <div class="main-body">
                                <div class="page-wrapper">
                                <!-- Page-header start -->
                                    <div class="page-header card">
                                        <div class="row align-items-end">
                                            <div class="col-lg-8">
                                                <div class="page-header-title">
                                                    <i class="icofont icofont-clip-board bg-c-yellow"></i>
                                                    <div class="d-inline">
                                                        <h4>Support Form</h4>
                                            <span>Send your request by filling the form below</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="page-header-breadcrumb">
                                                    <ul class="breadcrumb-title">
                                                <li class="breadcrumb-item">
                                                    <a href="index.html">
                                                        <i class="icofont icofont-home"></i>
                                                    </a>
                                                </li>
                                                <li class="breadcrumb-item"><a href="#!">Support Desk</a>
                                                </li>
                                                <li class="breadcrumb-item"><a href="#!">Contact Form</a>
                                                </li>
                                            </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page-header end -->
                                    
                                    <!-- Page body start -->
                                    <div class="page-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <!-- Contact details card start -->
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h5>Channel your query Here</h5>
                                                        <span>Fill Form below</span>
                                                        <div class="card-header-right">                                                             <i class="icofont icofont-spinner-alt-5"></i>                                                         </div>
                                                    </div>
                                                    <div class="card-block">
                                                        <div class="j-wrapper j-wrapper-640">
                                                            <form action="#" method="post" class="j-pro" id="j-pro" novalidate>
                                                                <!-- end /.header-->
                                                                <div class="j-content">
                                                                    <!-- start google map -->
                                                                    <!--<div class="j-unit">
                                                                        <label class="j-label m-b-10">Google Map</label>
                                                                        <div class="unit" id="google-map" style="width:100%;height:380px;">
                                                                        </div>
                                                                    </div>-->
                                                                    <!-- end google map -->
                                                                    <!-- start name -->
                                                                    <div class="j-unit">
                                                                        <label class="j-label">Name</label>
                                                                        <div class="j-input">
                                                                            <label class="j-icon-right" for="name">
                                                        <i class="icofont icofont-ui-user"></i>
                                                    </label>
                                                                            <input type="text" placeholder="e.g. John Doe" id="name" name="name">
                                                                        </div>
                                                                    </div>
                                                                    <!-- end name -->
                                                                    <!-- start email -->
                                                                    <div class="j-unit">
                                                                        <label class="j-label">Email</label>
                                                                        <div class="j-input">
                                                                            <label class="j-icon-right" for="email">
                                                        <i class="icofont icofont-envelope"></i>
                                                    </label>
                                                                            <input type="email" placeholder="email@example.com" id="email" name="email">
                                                                        </div>
                                                                    </div>
                                                                    <!-- end email -->
                                                                    <!-- start phone -->
                                                                    <div class="j-unit">
                                                                        <label class="j-label">Phone</label>
                                                                        <div class="j-input">
                                                                            <label class="j-icon-right" for="phone">
                                                        <i class="icofont icofont-phone"></i>
                                                    </label>
                                                                            <input type="text" placeholder="telephone or mobile" id="phone" name="phone">
                                                                        </div>
                                                                    </div>
                                                                    <!-- end phone -->
                                                                    <!-- start message -->
                                                                    <div class="j-unit">
                                                                        <label class="j-label">Message</label>
                                                                        <div class="j-input">
                                                                            <label class="j-icon-left" for="message">
                                                                                <i class="icofont icofont-file-text"></i>
                                                                            </label>
                                                                            <textarea placeholder="Your Inquiry" spellcheck="false" id="message" name="message"></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <!-- end message -->
                                                                    
                                                                    <!-- start notify me -->
                                                                    <!--<div class="j-unit">
                                                                        <label class="j-checkbox-toggle">
                                                                            <input type="checkbox" class="js-single" checked /> Notify me about new comments
                                                                        </label>
                                                                    </div>-->
                                                                    <!-- end notify me -->
                                                                    
                                                                    <!-- start response from server -->
                                                                    <div class="j-response"></div>
                                                                    <!-- end response from server -->
                                                                </div>
                                                                <!-- end /.content -->
                                                                <div class="j-footer">
                                                                    <button type="submit" class="btn btn-primary">Send</button>
                                                                </div>
                                                                <!-- end /.footer -->
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Contact details card end -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Page body end -->
                                </div>
                            </div>
                            <!-- Main-body end -->
                            <!--<div id="styleSelector">

                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>