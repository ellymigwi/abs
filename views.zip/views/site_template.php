  <!-- ========== Parse Header == -->
  <!--{header}-->
  <?php if(!empty($header))  $this->load->view($header); ?>
  
  <!--{top menu}-->
  <?php if(!empty($top_menu))  $this->load->view($top_menu); ?>
  
								
		 <?php if(!empty($banner))  $this->load->view($banner); ?>
         
       
		<!-- ============ Start Content ==================== -->				
        <!-- Content -->
         <?php  if(!empty($content)) $this->load->view($content); ?>
        <!-- // Content END -->
              

		<!-- // Sidebar menu & content wrapper END -->
      	 <?php  if(!empty($footer)) $this->load->view($footer); ?>
        <!-- {footer}-->
        
     		
	
</body>
</html>