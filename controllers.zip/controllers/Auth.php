<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	/**
	 * Auth controller using Authme
	 *
	 * @package Authentication
	 * @category Libraries
	 * @author Elijah Macharia
	 * @link http://www.mysite.com
	 * @version 3.1
 */
	 
	public $fullnames;
	public $email;
	
	public function __construct()
	{
		parent::__construct();
		
		$this->config->load('authme');
		$this->load->helper('authme');
		
		$this->load->library('authme');
		$this->load->library('pagination');
		$this->load->library('auth_lib');
		$this->load->library('facebook'); // Automatically picks appId and secret from config
		//$this->load->library('Ajax_pagination');
		
		#Datatable sturf
		#--------------------------------------------------------------
		$this->load->library('Datatables');
		$this->load->helper('datatables_helper');
        $this->load->library('table');
	}
	
	
	public function index($page='index',$type='',$number='')
	{	
			
		if($page=='signin' ){
			 if (!$this->auth_lib->signedIn($type,$number)) {
                $this->signIn('',$type,$number);
			 }
        }
		else{
			$this->display($page);
		}
	}
	
	#Auth functions
	# Function to Login
	#---------------------------------------------------------------------------------------------------
	function signOut($type='',$user_id=''){

		$post=array('online'=>0);
		if($val = $this->authme_model->_update($post,'tbl_users','user_id',$this->session->userdata('user_id'))){
        	$this->auth_lib->signOut($type,$user_id);
		}
    }	
	
	function signIn($type='',$message='',$number=''){
		
		if($message=='none') $message='';
		//echo "2".$message.'--'.$type;
		//die();
		
		$data['title'] = ':: ABS | Sign in ::..';
        $data['message'] = 'Log in with your email and password Below.';
		$data['type'] = $type;
		$data['number'] = $number;
        if($message !=''){
            $data['message'] = $message;
        }
		
		
		#Extract form data
        $post = $this->input->post();
        if($post == FALSE){
            $this->display('signin',$data,$number);
        }
		else{
            if ($this->form_validation->run()==FALSE) { 
                  echo json_encode(array('info'=>'invalid'));        
            }else{
						
                	//Fetch the user account details by email and get the access type
                	$userdata = $this->authme_model->get_user_by_roles($post['email_add']);
					if($userdata){
						
					 	if($userdata['active'] == 0){
							echo json_encode(array('info'=>'deactivated'));
						}else if($userdata['active'] == 1){
							echo json_encode(array('info'=>'inactive'));
						}else if(isset($userdata['inst_active']) && $userdata['inst_active']==0){
							echo json_encode(array('info'=>'inst_inactive'));
						}else if(isset($userdata['inst_active']) && $userdata['inst_active']==2){
							echo json_encode(array('info'=>'inst_deactived'));
						}else if($userdata['banned'] == 1 && $userdata['ban_message'] =='user'){
							echo json_encode(array('info'=>'user_ban'));
						}else if($userdata['banned'] == 1 && $userdata['ban_message'] =='institution'){
							echo json_encode(array('info'=>'inst_ban'));
						}else{
						
							#returns the redirection type after verifying password
                        	#i.e. account , account/completeprofile
							#Check if its first time
							$rec=$this->authme_model->select_table('tbl_users','first_time,user_id'," WHERE user_email='".strtolower($post['email_add'])."' AND first_time=1",'row');
													
							if(($rec) && ($rec->first_time==1)){
								
								$array=array('first_user_id'=>$rec->user_id,'user_email'=>strtolower($post['email_add']));
								$this->session->set_userdata($array);
								
								$page="auth/display/reset_user/";
								echo json_encode(array('info'=>$page));
							}
							else{
							
								$user_type=$post['user_type'];
								$user_number=$post['user_number'];
								
								$signin = $this->authme_model->signIn($userdata,$post);		
								
								
												
								if($signin){ 
									//echo json_encode(array('info'=>$userdata['inst_active']));
									$this->load->model('account_model');
									$this->account_model->log_user('Logged in',$this->session->userdata('id'));
														
									//This is used by the javascript to redirect to the neccessary page
									if($user_type=='job_seeker'){
										$page="auth/details/job-search-more/".$user_number;
									}else{
										$page="account/index";
									}
									echo json_encode(array('info'=>$page));
								}
								else{
									echo json_encode(array('info'=>'warning'));
								}
							}
							
						}
					}
					else{
                    	echo json_encode(array('info'=>'error'));
                	}
					
			}
		}
	}
	
	#Function to unsubscribe user
	public function unsubscribe($user='', $pass_key=''){
		echo "yes";
	}
	
	# Function to Reset Password
	#---------------------------------------------------------------------------------------------------
	function forgot(){
        $post = $this->input->post();
        if($post == FALSE){
            $this->signIn();
        }
        else{
            if ($this->form_validation->run()==FALSE) { 
                  echo json_encode(array('info'=>'invalid'));        
            }
            else{
				
                $userdata = $this->authme_model->get_user_by_roles($post['reset-email_add']);
                if($userdata){
					$this->load->helper('url');
                    $forgot = $this->authme_model->forgotPassword($userdata);
                    if($forgot){
						
						#Email Details
						 $config=array(
							'charset' => 'iso-8859-1',
							'wordwrap' => TRUE,
							'mailtype' => 'html',
							'crlf' => "\r\n",
							'newline' => "\r\n"
						 );
						$this->email->initialize($config);
						
						#Email Details
						$this->email->to($post['reset-email_add']);
						if($_SERVER['HTTP_HOST']=='www.buyelec.co.ke' || $_SERVER['HTTP_HOST']=='buyelec.co.ke')
						{
							$this->email->from('info@abs.co.ke', 'Password Reset:');									
						}else{
							$this->email->from('info@abs.co.ke', 'Password Reset:');
						}
						
						$this->email->subject('Password Reminder:');
						$data['user_email']=$post['reset-email_add'];
						$data['fullnames'] = $userdata['user_firstname'].' '.$userdata['user_lastname'];
						$data['subject'] = '<p><h2>Password Reminder:</h2></p>';
						$data['content'] = '<p>You have requested to have your password reset for your account at ABS Portal</p>
</p><p>Please visit this url to reset your password: <a href='.base_url('auth/reset/'.$userdata['user_id'].'/'.$forgot).'>Reset Password</a></p>
<p>If you received this email in error, you can safely ignore this email.</p>';
						$message= $this->load->view('email-template',$data,TRUE);
						$this->email->message($message);
						$val=$this->email->send(); //Send Email

                      												
                        echo json_encode(array('info'=>'reset'));
                    }
                    else{
                        echo json_encode(array('info'=>'warning'));
                    }
                }
                else{
                    echo json_encode(array('info'=>'error'));
                }
                
            }
        }
    }
	#Function to reset password
	public function reset($user='', $pass_key=''){
			
        	$post = $this->input->post();
            if($post == FALSE){
                $data['url'] = $user.'/'.$pass_key;
                $data['title'] = 'ABS : accounts\' Signup';
                $this->display('reset',$data);
            }
            else{
                if ($this->form_validation->run('auth/reset') == FALSE) {
                    echo json_encode($this->form_validation->error_array()); 
               }
                else{
					
					
					if($pass_key){
						$reset = $this->authme_model->resetPassword($user, $pass_key, $post['password']);
						if($reset){
							#Notification
							$notes=array('title'=>'Password Change Request','description'=>'You requested a password reset as specified on Update Date column.','type'=>'password','user_id'=>$user);
							$val = $this->account_model->_insert($notes,'tbl_notifications');
								 
							echo json_encode(array('info'=>'success'));
						}
						else{
							echo json_encode(array('info'=>'error'));
						}
					}
					else{
						
						$user_id=$this->session->userdata('first_user_id');
						//echo json_encode(array('info'=>$user_id));
						if($this->session->userdata('first_user_id')) {
							
							 
							 $set['user_password'] = $this->authme_model->hash($post['password']);
							 $set['first_time']=0;
							 if($this->authme_model->_update($set,'tbl_users','user_id',$user_id)){
								 
								 #Notification
								 $notes=array('title'=>'Password Change Request','description'=>'You requested a password reset as specified on Update Date column.','type'=>'password','user_id'=>$user_id);
								 $val = $this->account_model->_insert($notes,'tbl_notifications');
								
								echo json_encode(array('info'=>'success'));
								$this->session->unset_userdata('first_user_id');
							 }else{
								echo json_encode(array('info'=>'error'));
							 }
						}
							 
					}
            }
		}
    }  
	
	
	#Create Accounts
	#---------------------------------------------------------------------------------------------------------------------
	public function signup($type='',$user_type=false,$user_id=false){
		
		if($type=='')
        {
            $type='administrator';
        }
		
		
		#Captcha details
		$data['type']=$type;
        $data['captcha'] = $this->createCaptcha(); //Call captcha function
		
        #Extract form data
        $post = $this->input->post();
		//echo json_encode($post);
		//die();
		
        if($post == FALSE){
            $this->display('signup',$data);
        }
        else{
					
					$status = "";
					$msg = "";
					$targetPath = ""; $category=""; $marital="";$orphan="";
							
					$config['upload_path'] = './uploads/docs/';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['max_size'] = 1024 * 80 *80; //8MB
					$config['max_width'] = '1024';
					$config['max_height'] = '768';
					$config['filesize']= filesize($_FILES['userfile1']['tmp_name']);
					$config['filesize2']= filesize($_FILES['userfile2']['tmp_name']);
					$config['remove_spaces'] = FALSE;
					//$config['overwrite'] = TRUE;							 	
					$this->load->library('upload', $config);
						
					#Specify upload parameters
					/* Handle the file upload */
					if (!empty($_FILES['userfile1']['name']) && !$this->upload->do_upload('userfile1')){
						echo json_encode(array('cl_error' => $this->upload->display_errors()));
						die();
					}
					if (!empty($_FILES['userfile2']['name']) && !$this->upload->do_upload('userfile1')){
						echo json_encode(array('cv_error' => $this->upload->display_errors()));
						die();
					}
					if ( !$this->upload->do_upload('userfile1') && empty($_FILES['userfile1']['name']) ){
						echo json_encode(array('cl_error' => $this->upload->display_errors()));
						die();
					}
					if ( !$this->upload->do_upload('userfile2') && empty($_FILES['userfile2']['name']) ){
						echo json_encode(array('cv_error' => $this->upload->display_errors()));
						die();
					}
					if(!empty($_FILES['userfile1']['name']) && $config['filesize']>$config['max_size']) {
						echo json_encode(array('max_upload' => 'File is greater than maximum upload Size of 5Mb'));
						die();
					}
					if(!empty($_FILES['userfile2']['name']) && $config['filesize2']>$config['max_size']) {
						echo json_encode(array('max_upload2' => 'File is greater than maximum upload Size of 5Mb'));
						die();
					}if(!$this->upload->do_upload('userfile1')) {
						echo json_encode(array('cl_error' => $this->upload->display_errors()));
						die();
					}
					if(!$this->upload->do_upload('userfile2')) {
						echo json_encode(array('cv_error' => $this->upload->display_errors()));
						die();
					}else{
						
						 if ($this->upload->do_upload('userfile1') & $this->upload->do_upload('userfile1')){
							 
							$data = $this->upload->data();
						 	$uploadedFiles[0] = $data;
												
							$targetPath = "uploads/docs/".$_FILES['userfile1']['name'];
							$post['id_file_name']=$data['file_type'];
							$post['id_file_type']=$data['file_type'];
							$post['id_file_size']=$data['file_size'];
							$post['id_path']=$targetPath;
							
							$targetPath = "uploads/docs/".$_FILES['userfile2']['name'];
							$post['pass_file_name']=$data['file_type'];
							$post['pass_file_type']=$data['file_type'];
							$post['pass_file_size']=$data['file_size'];
							$post['pass_path']=$targetPath;
							
							/*echo json_encode($type);
							die();*/
							$signup = $this->authme_model->signUp($post,$type);
							
							 // Populate users table;
							 if($signup != FALSE){
								if($signup=='success')
								{
								
								}
								else
								{
									#Email Details
									$config=array(
										'charset' => 'iso-8859-1',
										'wordwrap' => TRUE,
										'mailtype' => 'html',
										'crlf' => "\r\n",
										'newline' => "\r\n"
									 );
									$this->email->initialize($config);
									
									$this->email->to($post['user_email']);
									
									if($_SERVER['HTTP_HOST']=='www.abs.co.ke' || $_SERVER['HTTP_HOST']=='abs.co.ke')
									{
										$this->email->from('info@abs.co.ke', 'ABS: Account Registration:');									
									}else{
										$this->email->from('info@abs.co.ke', 'ABS: Account Registration:');
									}
																	
									$this->email->subject('Account Created:');
									$data['fullnames'] = $post['user_firstname'].' '.$post['user_lastname'];
									$data['subject'] = '';
									$data['user_email'] = $post['user_email'];
									
									if($type=='students'){
										$data['subject'] = '<b>ABS Account Registration</b>';
										$data['content'] = '<p>An account has been created for you at ABS Portal.</p>
										<p>Please follow the link below to activate your account. </p><p>Activation Link >> <a href='.base_url('auth/verify/'.$type.'/'.$signup).'>Activate your Account</a></p>
										<p>If you received this email in error, you can safely ignore this email.</p>';
									}else{
										//$data['subject'] = '<b>Advertiser Registration</b>';
										$data['content'] = '<p>An account has been created for you on our website.</p>
										<p>Please follow the link below to activate your account. </p><p>Activation Link >> <a href='.base_url('auth/verify/'.$type.'/'.$signup).'>Activate your Account</a></p>
										<p>If you received this email in error, you can safely ignore this email.</p>';
									}
									
									
									$message= $this->load->view('email-template',$data,TRUE);
									$this->email->message($message);
									$val=$this->email->send(); //Send Email
								}
							   echo json_encode(array('info'=>'success'));
							}
							else if($signup == FALSE){
								echo json_encode(array('info'=>'error'));
							} 
						 }
					}
				 //}
	   		}
	}
	
	#Contact Us
	#---------------------------------------------------------------------------------------------------------------------
	public function contact_us($type='',$user_type=false,$user_id=false){
		
			#Validate form data
            if ($this->form_validation->run('auth/contacts') == FALSE) {
            	echo json_encode($this->form_validation->error_array()); 
            }
            else
            {
					#Extract form data
					$post = $this->input->post();	
					//echo json_encode(array('info'=>$post));
					//die();
					
					#Email Details
					$config=array(
						'charset' => 'iso-8859-1',
						'wordwrap' => TRUE,
						'mailtype' => 'html',
					);
					/*'crlf' => "\r\n",
					'newline' => "\r\n"*/
					$this->email->initialize($config);
					
					if($_SERVER['HTTP_HOST']=='www.buyelec.co.ke' || $_SERVER['HTTP_HOST']=='buyelec.co.ke')
					{
						$this->email->to('info@abs.co.ke');
						
					}else{
						$this->email->to('info@abs.co.ke');
						
					}
				
					////////////////////////////////////////////////////////////////
					$this->email->from($post['user_email']);
					$this->email->subject($post['subject']);
					$data['user_email'] = $post['user_email'];
					$data['fullnames'] = $post['name'];
					$data['subject'] = ''; 
					$data['content'] = '<p>'.$post['message'].'</p>';
					$message= $this->load->view('email-template',$data,TRUE);
					$this->email->message($message);
					$val=$this->email->send(); //Send Email
                  
				  	echo json_encode(array('info'=>'success'));
               }
	}
	
	#Mailing List
	#---------------------------------------------------------------------------------------------------------------------
	public function mailing_list($type='',$user_type=false,$user_id=false){
		
			#Validate data
			$this->form_validation->set_message('is_unique', 'Email Already Registered in the system');
            if ($this->form_validation->run($type) == FALSE) {
            	echo json_encode($this->form_validation->error_array()); 
            }
            else
            {
					#Extract form data
					$post = $this->input->post();	
					unset($post['s']);
										
					#Mailing List
					if($user_type=='general'){
						$array=array('uname'=>'','uemail'=>$post['uemail'],'group_id'=>1);
						#Populate table
						$val = $this->account_model->_insert($array,'tbl_mailing_list');
					}
					
					////////////////////////////////////////////////////////////////////////
					if($val){			          
				  		echo json_encode(array('info'=>'success'));
					}else{
						echo json_encode(array('info'=>'error'));
					}
               }
	}
	
	#Job Mailing List
	#---------------------------------------------------------------------------------------------------------------------
	public function search_mailing_list($type='',$user_type=false,$user_id=false){
		
			#Validate data
			$this->form_validation->set_message('is_unique', 'Email Already Registered in the system');
            if ($this->form_validation->run($type) == FALSE) {
            	echo json_encode($this->form_validation->error_array()); 
            }
            else
            {
					#Extract form data
					$post = $this->input->post();	
					unset($post['s']);
										
					#Mailing List
					if($user_type=='job_alerts'){
						$array=array('uname'=>'','uemail'=>$post['alerts_email'],'group_id'=>2);
						#Populate table
						$val = $this->account_model->_insert($array,'tbl_mailing_list');
					}
					
					
					
					if($val){			          
				  		echo json_encode(array('info'=>'success'));
					}else{
						echo json_encode(array('info'=>'error'));
					}
               }
	}

	
	#Captcha function
	function createCaptcha(){

      /* Setup vals to pass into the create_captcha function */
      $word = strtoupper(substr($this->auth_model->uniqueStr(6), 0,5));
      $vals = array(
        'word' => $word,
        'img_path' => './captcha/',
        'img_url' => base_url().'/captcha/',
        'img_width'  => '260',
        'img_height' => '30',
        'border' => '1',
        'expiration' => 7200,
        );

      /* Generate the captcha */
      $captcha = create_captcha($vals);
      
      /* Store the captcha value (or 'word') in a session to retrieve later */
      $this->session->set_userdata('captchaWord', $captcha['word']);

      return $captcha;
    } 
    function checkCaptcha($captcha){
        if(strtoupper($captcha) != ($this->session->userdata('captchaWord'))){
            $this->form_validation->set_message('checkcaptcha', 'Please enter the captcha code as it appears on the image!');
            return false;
        }

    }
	
	#Verify registered user
	#-----------------------------------------------------------------------------------------------------
	function verify($type='',$code = '', $activate = ''){
        
        if($type==''){
            redirect('auth/signIn');
        }
        elseif($code=='')
        {
            redirect('auth/signIn/'.$type);
        }
        else{
			
            $message = '';
			
			if($type=="user"){
				if($this->authme_model->verifyAcc($type,$code)){
					$message = 'Your account has been Activated, Log in with your email and password.';
				}
				else{
					$message = 'Use the verification link in your email address to activate your account.';
				}
				$this->signIn($message);
			}else{
				if($this->authme_model->verifyAcc($type,$code)){
					$message = 'Your account has been Activated, Log in with your email and password.';
				}
				else{
					$message = 'Use the verification link in your email address to activate your account.';
				}
				$this->signIn($message);
			}
        }
    }
	
   #Check if user is logged in
   function logged_on($page='',$number=''){
	   
	   if($this->session->userdata('logged_in')== true){
		   if($page=='job-seeker'){
		   	redirect('auth/index/job-application/'.$number);
		   }
	   }
	   else{
		   redirect('auth/index/signin/'.$page.'/'.$number);
	   }
   }
   
   
   /////////////////////////////////////////////////////////////////
   #function to save modules
   function save_form($page,$action,$id='',$code='',$acad_year=''){
	   
	   switch($page)
    	 {
			  case 'form_phone1':

			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					#Extract form data
					$val='';
					$post = $this->input->post();
						
					// generate "random" 6-digit verification code
  					$pcode = rand(100000, 999999);
					$post['verification_code']=$pcode;
					$post['user_mobile']=str_replace(' ', '', $post['user_mobile']); //trim($post['user_mobile']);
					//echo json_encode(array('info'=>$post));
					
					#Get Verification status
					$rec=$this->account_model->select_table('tbl_users','user_mobile,verified'," WHERE user_id=".$id,'row');
					$verified=$rec->verified;
					
					if($verified==0){
						
						$veri=0;
						$rec=$this->account_model->select_table('tbl_users','verified'," WHERE user_mobile='".$post['user_mobile']."'",'row');
						if($rec){
							$veri=$rec->verified;
							
						}
					
						if($veri==1){
							echo json_encode(array('info'=>'tel_error'));
							die();
						}
						
						#update Records
						////////////////////////////////////////////////////////////////////////////////////////
						//$uid=array('user_id'=>$user_id);
						if($val = $this->account_model->_update($post,'tbl_users','user_id',$id)){
							echo json_encode(array('info'=>'success'));
						}else{
							echo json_encode(array('info'=>'error'));
						}
								
					}else{
						echo json_encode(array('info'=>'success'));
					}

					
				}
			  break;
			  
			  case 'form_phone2':

			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					#Extract form data
					$val='';
					$post = $this->input->post();
					$vcode=$post['user_mobile2'];
					unset($post['user_mobile2']);
					//echo json_encode(array('info'=>$post));
					
					#Get Verification code
					$rec=$this->account_model->select_table('tbl_users','verification_code'," WHERE user_id=".$id,'row');
					$verified=$rec->verification_code;
					
					if($vcode==$verified){
						
						#Update verification status
						$post=array('verified'=>1);
						if($val = $this->account_model->_update($post,'tbl_users','user_id',$id)){
							
							$this->session->unset_userdata('verified');
							$this->session->set_userdata('verified',1);
							echo json_encode(array('info'=>'success'));
						}else{
							echo json_encode(array('info'=>'error_sys'));
						}
					}else{
						echo json_encode(array('info'=>'error'));
					}
										
				}
			  break;
			  
			  case 'form_personal2':

			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					#Extract form data
					$val='';
       				$post = $this->input->post();
					///////////////////////////////////////////////////////////////////////////////		
					#User_bios table
					$data['user_id']=$id;
					$post['user_firstname']=strtoupper($post['user_firstname']);
					$post['user_middlename']=strtoupper($post['user_middlename']);
					$post['user_lastname']=strtoupper($post['user_lastname']);
						
					unset($post['user_email']);	
					unset($post['mod_name']);
					unset($post['user_id']);	
						
						
					//echo json_encode(array('info'=>$post));
					#1. Update users table
					if($val = $this->account_model->_update($post,'tbl_users','user_id',$id)){
						$this->account_model->log_user('Updated tbl_users- with Trans ID='.$val.' New value for name: '.$post['user_firstname'].')',$this->session->userdata('id'));							
					}
					
					/************ output message ************************/
					if($val){
						 echo json_encode(array('info'=>'success'));
					}
					else{
						echo json_encode(array('info'=>'error'));
					}

					
				}
			  break;
			  
			  default :
                $page = 'frm_modules';
                break;
 		}
   }
	/*
		**Render Views
	*/
	#-----------------------------------------------------------------------------------------------------------------------------
	function display($page,$data='',$number=''){	
		
		if($page=="signin" ){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			# Load View
			#---------------------------------------------------------------------------------
			$page_type=$this->uri->segment(3);
			$data['title']='Home | ABS Ltd';
				
			$menu="";
			$breadcrumb="";
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			
			
			# Load View
			#---------------------------------------------------------------------------------
			$data['header'] = 'auth_view/partials/header_user'; // Load top header view
			$data['title'] = 'Login'; // Page Title
			$data['top_menu'] = 'auth_view/partials/top_menu'; // Load top_menu view
			//$data['bread_crumb'] = $breadcrumb;
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view

								
			$this->load->view('site_template',$data,false);
			
		}else if($page=="signin2" ){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			# Load View
			#---------------------------------------------------------------------------------
			$data['header'] = 'auth_view/partials/header_acc'; // Load top header view
			$data['title'] = 'Login'; // Page Title
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view
			
			$this->load->view('account_template',$data,false);
			
		}else if($page=="forgot" ){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			# Load View
			#---------------------------------------------------------------------------------
			$data['header'] = 'auth_view/partials/header_user'; // Load top header view
			$data['title'] = 'Recover Password'; // Page Title
			$data['top_menu'] = 'auth_view/partials/top_menu'; // Load top_menu view
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view
			
			$this->load->view('account_template',$data,false);
			
		}elseif($page=="lockscreen"){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			
			$user_id=$this->uri->segment(4);
			//$data=$this->account_model->select_table('tbl_users a left join  tbl_users_bio b on(a.user_id=b.user_id) left join tbl_counties c on(c.county_code=b.county)','a.user_firstname, a.user_lastname, a.user_gender, a.user_dob, a.user_city, a.user_country, a.user_mobile, a.user_email, DATE_FORMAT(a.last_login,"%D-%b-%Y %r") last_login,DATE_FORMAT(a.created_on,"%D-%b-%Y") created_on, b.staff_title, b.telephone, b.box_no, b.postal_code, b.town, b.home_address, b.user_marital, b.idnumber, b.county, c.county_name, b.const_code, b.ward, b.company, b.about_user, b.public, b.facebook, b.twitter, b.google, b.linkedin, b.skype, b.yahoo, b.website, b.file_name,b.file_type,b.file_size,b.path,b.type'," ",'result');
			$data='';
			
			# Load View
			#---------------------------------------------------------------------------------
			$data['title'] = 'Log Screen'; // Load top header view
			$data['header'] = 'auth_view/partials/header_lock'; // Load top header view
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view
			
			$this->load->view('account_template',$data,false);
			
		}elseif($page=="logout"){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			
			$user_id=$this->uri->segment(4);
			//$data=$this->account_model->select_table('tbl_users a left join  tbl_users_bio b on(a.user_id=b.user_id) left join tbl_counties c on(c.county_code=b.county)','a.user_firstname, a.user_lastname, a.user_gender, a.user_dob, a.user_city, a.user_country, a.user_mobile, a.user_email, DATE_FORMAT(a.last_login,"%D-%b-%Y %r") last_login,DATE_FORMAT(a.created_on,"%D-%b-%Y") created_on, b.staff_title, b.telephone, b.box_no, b.postal_code, b.town, b.home_address, b.user_marital, b.idnumber, b.county, c.county_name, b.const_code, b.ward, b.company, b.about_user, b.public, b.facebook, b.twitter, b.google, b.linkedin, b.skype, b.yahoo, b.website, b.file_name,b.file_type,b.file_size,b.path,b.type'," ",'result');
			$data='';
			
			# Load View
			#---------------------------------------------------------------------------------
			$data['title'] = 'Log Out'; // Load top header view
			$data['header'] = 'auth_view/partials/header_lock'; // Load top header view
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view
			
			$this->load->view('account_template',$data,false);
			
		}elseif($page=="signup"){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			
			# Load View
			#---------------------------------------------------------------------------------
			$data['title'] = 'User Registration'; // Load top header view
			$data['header'] = 'auth_view/partials/header_user'; // Load top header view
			$data['top_menu'] = 'auth_view/partials/top_menu'; // Load top_menu view
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_signup'; // Load footer view
			
			
			#Get Countries
			$data['countries']=$this->authme_model->select_table('cre_countries','*',' ORDER BY COUNTRYNAME ASC','result');
			
			$this->load->view('account_template',$data,false);
			
		}elseif($page=="reset"){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			# Load View
			#---------------------------------------------------------------------------------
			$data['header'] = 'auth_view/partials/header_user'; // Load top header view
			$data['title'] = 'Reset Password'; // Page Title
			$data['top_menu'] = 'auth_view/partials/top_menu'; // Load top_menu view
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view
			
			$this->load->view('account_template',$data,false);
			
		}elseif($page=="reset_user"){
			
			if ( ! file_exists('application/views/auth_view/account/'.$page.'.php'))
			{
				// Whoops, we don't have a page for that!
				show_404();
			}
			# Load View
			#---------------------------------------------------------------------------------
			$data['header'] = 'auth_view/partials/header_user'; // Load top header view
			$data['title'] = 'Reset Password'; // Page Title
			$data['content'] = 'auth_view/account/'.$page; // Load content view
			$data['footer'] = 'auth_view/partials/footer_acc'; // Load footer view
			
			$this->load->view('account_template',$data,false);
			
		}else{
				if ( ! file_exists('application/views/auth_view/site/'.$page.'.php'))
				{
					// Whoops, we don't have a page for that!
					show_404();
				}
			
				//echo "yo";
				# Load View
				#---------------------------------------------------------------------------------
				$page_type=$this->uri->segment(3);
				$data['title']='Home | ABS';
				//Variable declaration
				$menu="";$breadcrumb="";$dates='';$active='';
				
				
				
			    if($page=="index"){
															
					$data['banner'] = 'auth_view/partials/banner'; // Load banner view	
								
				}else if($page=="contact"){
					
					$data['title']='Contact Us | ABS';
					
					$url="".$this->uri->segment(4);
					if($url=='kws'){
						$data['stel']='Toll free: 0800597000';
						$data['semail']='customerservice@kws.go.ke';
						$data['slocation']='HQ - Nairobi,Kenya';	
						$data['side_menus']='Kenya Wildlife Service <br /> P.O. Box 40241 - 00100 <br />Nairobi, Kenya';
						$data['contacts']='+254 (20) 2379407<br />+254 (20) 2379408<br />+254 (20) 2379409<br />Toll free: 0800597000';
						$data['facebook']='';
						$data['twitter']='';
						$data['site']=" (Kenya Wildlife Service)";
						
					}else if($url=='nema'){
						$data['stel']='+254 724 253398, +254 735 01304';
						$data['semail']='dgnema@nema.go.ke';
						$data['slocation']='Popo Road,South C, off Mombasa Road';	
						$data['side_menus']='National Environment Management Authority <br /> P.O.BOX: 67839-00200 <br />Nairobi, Kenya';
						$data['contacts']='+254 724 253398<br />+254 735 01304';
						$data['facebook']='';
						$data['twitter']='';
						$data['site']=" (National Environment Management Authority)";
						
					}else if($url=='nacosti'){
						$data['stel']='+254 713 788 787 , +254 735 404 245';
						$data['semail']='info@nacosti.go.ke';
						$data['slocation']='Off Waiyaki Way, Upper Kabete';	
						$data['side_menus']='National Commission for Science Technology and Innovation <br /> P. O. Box 30623, 00100 <br />Nairobi, Kenya';
						$data['contacts']=' +25420 4007000<br />+25420 2241349 <br /> +25420 3310571';
						$data['facebook']='';
						$data['twitter']='';
						$data['site']=" (National Commission for Science Technology and Innovation)";
						
					}else if($url=='kfs'){
						$data['stel']='+254-2014663 ';
						$data['semail']='	info@kenyaforestservice.org';
						$data['slocation']=' Karura, Off Kiambu Road, Opposite CID headquarters';	
						$data['side_menus']='Kenya Forest Service <br /> P.O Box 30513-00100  <br />Nairobi, Kenya';
						$data['contacts']='+254 720 14663';
						$data['facebook']='';
						$data['twitter']='';
						$data['site']=" (Kenya Forest Service)";
						
					}else if($url=='kephis'){
						$data['stel']='+254 709 891 000';
						$data['semail']='kephisinfo@kephis.org';
						$data['slocation']=' KEPHIS Headquarters, Nairobi';	
						$data['side_menus']='Kenya Plant Health Inspectorate Service <br /> P.O. Box 49592-00100, <br />Nairobi, Kenya';
						$data['contacts']='+254 709 891 000';
						$data['facebook']='';
						$data['twitter']='';
						$data['site']=" (Kenya Plant Health Inspectorate Service)";
					}else if($url=='dvs'){
						$data['stel']='+254 20 – 80434410';
						$data['semail']='infodvs@kilimo.go.ke';
						$data['slocation']=' KEPHIS Headquarters, Nairobi';	
						$data['side_menus']='Directorate of Veterinary Services <br /> P.O Private Bag, Kangemi 00625, <br />Nairobi, Kenya';
						$data['contacts']='+254 20 – 8043441';
						$data['facebook']='';
						$data['twitter']='';
						$data['site']=" (Directorate of Veterinary Services)";
					}
					
					
				}
				
				#Pass variables
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				$menu='';
				$data['header'] = 'auth_view/partials/header'; // Load top header view
				$data['top_menu'] = 'auth_view/partials/top_menu'; // Load top_menu view
				$data['content'] = 'auth_view/site/'.$page; // Load content view
				$data['side_menu'] = $menu; // Load footer view
				$data['footer'] = 'auth_view/partials/footer'; // Load footer view

				$this->load->view('site_template',$data,false);
		}		
    }
	
	#Function to loaad datatable
	public function datatable($page="",$val='')
    {
		 $can_edit='';
		 $can_delete='';
		  
		 switch($page)
    	 {
			
			
			case 'frm_campus':
			
				$role_id =$this->session->userdata('role_id'); //Get category by role
				//$url="".$this->uri->segment(1)."/".$this->uri->segment(2)."/".$this->uri->segment(3)."";
				$url="account/index/frm_campus";
				$perm=$this->account_model->select_table('tbl_modules a inner join  tbl_applications b on(a.mod_id=b.mod_id) inner join tbl_permissions  d on(b.app_id=d.app_id)  inner join tbl_role_perm  e on(d.perm_id=e.perm_id)','a.mod_id,a.mod_name,b.app_id,d.can_view,d.can_add, d.can_edit,d.can_delete'," where d.can_view=1 and d.access_type='applications' and e.role_id=".$role_id." and b.controller='".trim($url)."'",'row');				
				
				$user_id =$this->session->userdata('role_id'); //Get category by role
				if($role_id !=1 && $role_id !=3){
					$rec=$this->account_model->select_table('tbl_campus','*'," where created_by=".$user_id." ORDER BY inst_name ASC",'row');
					$inst_id=$rec->inst_id;
					$array=array('c.inst_id'=>$inst_id);
				}else{
					$inst_id="c.inst_id >= 1";
				}
				
				$this->datatables->select('a.role_id,c.id, e.uniname,c.campus_name, c.location,c.description, b.user_id, CONCAT(b.user_firstname, " ", b.user_lastname) AS name',FALSE)
				->unset_column('a.role_id')
				->unset_column('b.user_id')
				//->add_column('Actions',  '$1', 'get_button(a.role_id, a.is_predefined,"frm_campus")')
				->add_column('Actions',  '$1', 'get_button(a.role_id, c.id,"frm_campus","'.$perm->can_edit.'-'.$perm->can_delete.'")')
				->from('tbl_roles a')
				->join('tbl_users b','a.role_id=b.role_id')
				->join('tbl_campus c','b.user_id=c.created_by')
				->join('tbl_institution_det d ','c.inst_id=d.inst_id')
				->join('cre_university_codes e','d.inst_name=e.uncode')
				->where("c.inst_id = $inst_id");
        
        		echo $this->datatables->generate();
				
            break;			
							
			default :
                $page = '';
                break;
 		}
        
    }
}
