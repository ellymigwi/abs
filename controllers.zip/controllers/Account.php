<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	*/
	public $role_id="";
	
	public function __construct()
	{
		parent::__construct();
		
		$this->load->library('authme');
		$this->load->library('auth_lib');
		$this->config->load('authme');
		$this->load->helper('authme');
		$this->load->library('pagination');
		$this->load->library('Ajax_pagination');
		
		#Datatable sturf
		#--------------------------------------------------------------
		$this->load->library('Datatables');
		$this->load->helper('datatables_helper');
        $this->load->library('table');
		
		#Load SMS Class
		#------------------------------------------------------
		//$this->load->library('sms');
		
		#Start Session
		#------------------------------------------------------
		if (!isset($_SESSION))
	  	{
			session_start();
	  	}
	}
	
	public function index($page='index')
	{
		if(!logged_in()) $this->auth_lib->signOut();		
		$this->displayMain($page);
	}
	
	/*
	** Call back functions
	**/
	#check if module is unique
	public function _valid_module($mod_name) {
		
		$row=$this->account_model->select_table('tbl_modules','mod_name'," where mod_name='".$mod_name."'",'row');
		
		if(!empty($row)){
			if ($row->mod_name) {
	
				$this->form_validation->set_message('_valid_module', "Module Name Already exists in the system");
		
				return false;
			}
		}
		
	
		return true;
	}
	
	
	//Send invoice
	public function mail_pdf()
    {
		#Get user details
		$rec=$this->account_model->select_table('tbl_users','user_firstname,user_lastname,user_email',' where user_id='.$this->session->userdata('user_id'),'row');
		$names=$rec->user_firstname.' '.$rec->user_lastname;
		
		//Load the library
	    $this->load->library('html2pdf');
	    
	    $this->html2pdf->folder('./uploads/pdfs/');
	    $this->html2pdf->filename("Invoice -".$names.".pdf");
	    $this->html2pdf->paper('a4', 'portrait');
	    
	    $data = array(
			'title' => 'PDF Created',
	    	'table' => 'PDF Created',
	    	'message' => 'Hello World!'
	    );
	    //Load html view
	    $this->html2pdf->html($this->load->view('pdf', $data, true));
	    
	    //Check that the PDF was created before we send it
	    if($path = $this->html2pdf->create('save')) {
	    	//echo "PDF saved";
						
			#Email Details
			#Email Details
			$config=array(
				'charset' => 'iso-8859-1',
				'wordwrap' => TRUE,
				'mailtype' => 'html',
				'crlf' => "\r\n",
				'newline' => "\r\n"
			);
			
			$message="";
			
			//header('Content-Type: application/pdf');
			//$this->load->library('email', $config);
			$this->email->initialize($config);
			
			
			$this->email->from('info@kssha.or.ke', 'KSSHA Secretariat');
			$this->email->to($rec->user_email); 
			$this->email->subject('2018 ABS CONFERENCE');
			
			$data['names']=$names;
			
			$message= $this->load->view('pdf_table',$data,TRUE);
			$this->email->message($message);
			//$this->email->message('Testing the email a freshly created PDF');	

			//$this->email->attach($path,  'attachment', 'report.pdf');
			$this->email->attach($path);

			$val=$this->email->send();
			
			return $val;
			//echo $this->email->print_debugger();
						
	    }
	    
    } 
	
	
	#Get Profile Pic
	#------------------------------------------------------------------------------------------------------
	public function get_img_data($user_id=""){
		
	       #Get profile Data
		   $profile=$this->account_model->select_table('tbl_users a left join  tbl_users_bio b on(a.user_id=b.user_id) left join cre_counties c on(c.county_code=b.county)','a.user_firstname, a.user_lastname, a.user_gender, a.user_dob, a.user_city, a.user_country, a.user_mobile, a.user_email, DATE_FORMAT(a.last_login,"%D-%b-%Y %r") last_login,DATE_FORMAT(a.created_on,"%D-%b-%Y") created_on, b.staff_title, b.telephone, b.box_no, b.postal_code, b.town, b.home_address, b.user_marital, b.idnumber, b.county, c.county_name, b.const_code, b.ward, b.company, b.about_user, b.public, b.facebook, b.twitter, b.google, b.linkedin, b.skype, b.yahoo, b.website, b.file_name,b.file_type,b.file_size,b.path,b.type'," where a.user_id=".$user_id,'result');
		   
		   $pic=null;
		   
		   foreach($profile as $row){	
				if($row->path==""){
					$pic.='<img src="'.base_url().'assets/assets/images/!logged-user.jpg" class="rounded img-responsive" alt="'.$this->session->userdata('full_names').'"/>';
				}else{
                    $pic.='<img src="'.base_url().$row->path.'" class="rounded img-responsive" alt="'.$this->session->userdata('full_names').'" />';
				}
			}
			
			echo $pic;
	}
	
	
	#Get Profile
	function get_mobile(){
		echo json_encode( $this->account_model->select_table('tbl_users','*'," WHERE user_id=".$this->session->userdata('user_id'),'row'));
	}
	
	#function to Save Data to Database
	#-------------------------------------------------------------------------------------------------------
	function save_form($page,$action,$id='',$code=''){
		
		switch($page)
    	{
			
			case 'frm_reg':

			  	#Extract form data
				$val=false;
       			$post = $this->input->post();
					
				if ($post)
				{
					$this->form_validation->set_rules('user_firstname', 'First Name', 'trim|required|min_length[2]|alpha');
					$this->form_validation->set_rules('user_lastname', 'Last Name', 'trim|required|min_length[2]|alpha');
					$this->form_validation->set_rules('user_mobile', 'Mobile', 'trim|required|numeric|min_length[6]|max_length[12]');
					$this->form_validation->set_rules('user_gender', 'Gender', 'trim|required');
					$this->form_validation->set_rules('user_country', 'Country', 'trim|required');
					$this->form_validation->set_rules('user_email', 'email address', 'trim|required|valid_email|is_unique[tbl_users.user_email]');
					$this->form_validation->set_rules('agreeterms', 'Terms and Condition', 'trim|required');
					$this->form_validation->set_rules('user_password', 'password', 'trim|required|min_length[6]|max_length[12]');
					$this->form_validation->set_rules('password-conf', 'confirmation', 'trim|required|matches[user_password]');
					
					$this->form_validation->set_message('is_unique', 'Email Already exists in the system');
					if($this->form_validation->run() == FALSE) {
						echo json_encode($this->form_validation->error_array()); 
						die();
					}else{
						
						$val=true;
					}
					
				}
					
				/************ output message ************************/
				if($val){
					echo json_encode(array('info'=>'success'));
				}
				else{
					echo json_encode(array('info'=>'error'));
				}
			 break;
			 
			 case 'frm_reg2':

			  	#Extract form data
				$val=false;
       			$post = $this->input->post();
					
				if($post){
					
					//echo json_encode($post);	
					#Populate Staff images
					$status = "";
					$msg = "";
					$targetPath = ""; $category=""; $marital="";$orphan="";
							
					$config['upload_path'] = './uploads/docs/';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['max_size'] = 1024 * 80 *80; //8MB
					$config['max_width'] = '1024';
					$config['max_height'] = '768';
					$config['filesize']= filesize($_FILES['userfile1']['tmp_name']);
					$config['filesize2']= filesize($_FILES['userfile2']['tmp_name']);
					$config['remove_spaces'] = FALSE;
					//$config['overwrite'] = TRUE;							 	
					$this->load->library('upload', $config);
						
					#Specify upload parameters
					/* Handle the file upload */
					if (!empty($_FILES['userfile1']['name']) && !$this->upload->do_upload('userfile1')){
						echo json_encode(array('cl_error' => $this->upload->display_errors()));
						die();
					}
					if (!empty($_FILES['userfile2']['name']) && !$this->upload->do_upload('userfile1')){
						echo json_encode(array('cv_error' => $this->upload->display_errors()));
						die();
					}
					if ( !$this->upload->do_upload('userfile1') && empty($_FILES['userfile1']['name']) ){
						echo json_encode(array('cl_error' => $this->upload->display_errors()));
						die();
					}
					if ( !$this->upload->do_upload('userfile2') && empty($_FILES['userfile2']['name']) ){
						echo json_encode(array('cv_error' => $this->upload->display_errors()));
						die();
					}
					if(!empty($_FILES['userfile1']['name']) && $config['filesize']>$config['max_size']) {
						echo json_encode(array('max_upload' => 'File is greater than maximum upload Size of 5Mb'));
						die();
					}
					if(!empty($_FILES['userfile2']['name']) && $config['filesize2']>$config['max_size']) {
						echo json_encode(array('max_upload2' => 'File is greater than maximum upload Size of 5Mb'));
						die();
					}if(!$this->upload->do_upload('userfile1')) {
						echo json_encode(array('cl_error' => $this->upload->display_errors()));
						die();
					}
					if(!$this->upload->do_upload('userfile2')) {
						echo json_encode(array('cv_error' => $this->upload->display_errors()));
						die();
					}else{
						$val=true;
					}
				}

				@unlink($_FILES['userfile1']);
				@unlink($_FILES['userfile2']);
							
					
				/************ output message ************************/
				if($val){
					echo json_encode(array('info'=>'success'));
				}
				else{
					echo json_encode(array('info'=>'error'));
				}
			 break;
			 
			  case 'frm_modules':

			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					 #Extract form data
					 $val='';
       				 $post = $this->input->post();
					 $post['mod_name']=ucfirst($post['mod_name']);
					 $post['created_by'] = $this->session->userdata('user_id'); //Get category by role
					
					if($action=='insert'){ 				     
						 unset($post['mod_id']);
                 	 	 if($val = $this->account_model->_insert($post,'tbl_modules')){
						 	$this->account_model->log_user('Created new module- with Trans ID='.$val.', Name: '.$post['mod_name'],$this->session->userdata('id'));
						 }
					}else if($action=='update'){ 		
						unset($post['mod_id']);
						if($val = $this->account_model->_update($post,'tbl_modules','mod_id',$id)){
							$this->account_model->log_user('Updated Module- with Trans ID='.$id.' New value for name: '.$post['mod_name'].')',$this->session->userdata('id'));
						}
					}
					
					/************ output message ************************/
					if($val){
						 echo json_encode(array('info'=>'success'));
					}
					else{
						echo json_encode(array('info'=>'error'));
					}
				}
			 break;
			  
			 case 'frm_support':

			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
       				#Extract form data
					$val='';
       				$post = $this->input->post();
					 //echo json_encode(array('info'=>$post));
					 //die();
					 
					#Email Details
					$config=array(
						'charset' => 'iso-8859-1',
						'wordwrap' => TRUE,
						'mailtype' => 'html',
						'crlf' => "\r\n",
						'newline' => "\r\n"
					);
					$this->email->initialize($config);
										
					$user_id = $this->session->userdata('user_id'); //Get category by role
					$rec=$this->account_model->select_table('tbl_users','user_email'," WHERE user_id=".$user_id,'row');
					$user_email=$rec->user_email;
					
				
					if($_SERVER['HTTP_HOST']=='www.buyelec.co.ke' || $_SERVER['HTTP_HOST']=='buyelec.co.ke')
					{
						$this->email->to('info@kessha.or.ke'); //Support email
					}else{
						$this->email->to('support@buyelec.co.ke'); //Support email
					}
						
					$this->email->from($user_email, 'Support Query:');
					$this->email->subject($post['subject']);
					$data['fullnames'] = 'Support Team';
					$data['subject'] = '<p><p><b>Support Query:</b></p></p>';
					$data['content'] = $post['msg'];
					$message= $this->load->view('email-template',$data,TRUE);
					$this->email->message($message);
					$val=$this->email->send(); //Send Email
					
					// echo json_encode(array('info'=>"yo".$val));
					 //die();
					/************ output message ************************/
					if($val){
						 echo json_encode(array('info'=>'success'));
					}
					else{
						echo json_encode(array('info'=>'error'));
					}
				}
			  break;
			  
			  
			  case 'frm_applications':
			  
			  	$this->form_validation->set_message('is_unique', 'Name Already exists in the system');
			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					 #Extract form data
					 $val='';
       				 $post = $this->input->post();
					 $post['app_name']=ucfirst($post['app_name']);
					 $post['app_desc']=ucfirst($post['app_desc']);
					 $post['created_by'] = $this->session->userdata('user_id'); //Get category by role
					
					if($action=='insert'){ 				     
						 unset($post['app_id']);
                 	 	 if($val = $this->account_model->_insert($post,'tbl_applications')){
						 	$this->account_model->log_user('Created new System Application- with Trans ID='.$val.', Name='.$post['app_name'],$this->session->userdata('id'));
						 }
					}else if($action=='update'){ 		
						unset($post['app_id']);
						if($val = $this->account_model->_update($post,'tbl_applications','app_id',$id)){
							$this->account_model->log_user('Updated System Application module- with Trans ID='.$id.' New value for name='.$post['app_name'].')',$this->session->userdata('id'));
						}
					}
					
					//*********** output message ***********************
					if($val){
						 echo json_encode(array('info'=>'success'));
					}
					else{
						echo json_encode(array('info'=>'error'));
					}
				}
				
			  break;
			  
			  case 'frm_sub_applications':
			  	
				$this->form_validation->set_message('is_unique', 'Name Already exists in the system');
			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					 #Extract form data
					 #--------------------------------------------------------------------------------
					 $val='';
       				 $post = $this->input->post();
					 $post['sub_name']=ucfirst($post['sub_name']);
					 $post['sub_desc']=ucfirst($post['sub_desc']);
					 $post['created_by'] = $this->session->userdata('user_id'); //Get category by role
					
					if($action=='insert'){ 				     
						 unset($post['sub_id']);
                 	 	 if($val = $this->account_model->_insert($post,'tbl_sub_applications')){
						 	$this->account_model->log_user('Created new Child Application- with Trans ID='.$val.', Name: '.$post['sub_name'],$this->session->userdata('id'));
						 }
					}else if($action=='update'){ 		
						unset($post['sub_id']);
						if($val = $this->account_model->_update($post,'tbl_sub_applications','app_id',$id)){
							$this->account_model->log_user('Updated System Child Application module- with Trans ID='.$id.' New value for name='.$post['sub_name'].')',$this->session->userdata('id'));
						}
					}
					
					#*********** output message ***********************
					if($val){
						 echo json_encode(array('info'=>'success'));
					}
					else{
						echo json_encode(array('info'=>'error'));
					}
				}
				
			  break;
			  
			  case 'frm_users':
			  	
				//$type='administrator';
			  	$this->form_validation->set_message('is_unique', 'Email Already exists in the system');
			  	if ($this->form_validation->run($page) == FALSE) {
                	echo json_encode($this->form_validation->error_array()); 
				}
				else
				{
					 #Extract form data
					 $val='';
       				 $post = $this->input->post();
					 $post['user_firstname']=ucfirst($post['user_firstname']);
					 $post['user_lastname']=ucfirst($post['user_lastname']);
					 $post['created_by'] = $this->session->userdata('user_id'); //Get category by role
					 $post['user_password']=$post['user_lastname'].'123!';
					 $post['role_id'] = $id;
					 
					
					if($action=='insert'){ 
						unset($post['cid']);
						unset($post['q']);
                 		$signup = $this->authme_model->signUp($post,'users');
						
				
						 if($signup != FALSE){
							 
								$item['first_time']=1;
								//echo json_encode(array('info'=>$item['first_time'].strtolower($post['user_lastname'])));	
								if($val = $this->account_model->_update($item,'tbl_users','user_email',strtolower($post['user_email']))){
									
										#Email Details
										$config=array(
											'charset' => 'iso-8859-1',
											'wordwrap' => TRUE,
											'mailtype' => 'html',
											'crlf' => "\r\n",
											'newline' => "\r\n"
										 );
										$this->email->initialize($config);
										
										$this->email->to($post['user_email']);
										$this->email->from('info@kessha.or.ke', 'Account Registration:');
										$this->email->subject('Account Created:');
										$data['fullnames'] = $post['user_firstname'].' '.$post['user_lastname'];
										$data['subject'] = '<p><p><b>Account Creation:</b></p></p>';
										$data['content'] = '<p>An account has been created for you at Eazzy Masomo Portal.Please follow the link below to activate your account. </p><p>Activation Link >>  <a href='.base_url('auth/verify/user/'.$signup).'>Activate your Account</a></p>
										<p><b>N/B:</b> You will be required to change your password in the first Login.</p><p>Your temporary Password is: user123</p>
										<p><p>_______________________________________________________________________________________<br />
										If you received this email in error, you can safely ignore this email.</p></p>';
										$message= $this->load->view('email-template',$data,TRUE);
										$this->email->message($message);
										$val=$this->email->send(); //Send Email
										
										echo json_encode(array('info'=>'success'));
		
								}else{
									echo json_encode(array('info'=>'error'));	
								}
								
							}else if($signup == FALSE){
								echo json_encode(array('info'=>'error'));
							} 
						
					}else if($action=='update'){ 		
						unset($post['app_id']);
						if($val = $this->account_model->_update($post,'tbl_applications','app_id',$id)){
							$this->account_model->log_user('Updated System Application module- with Trans ID='.$id.' New value for name='.$post['app_name'].')',$this->session->userdata('id'));
						}
						
						//*********** output message ***********************
						if($val){
							 echo json_encode(array('info'=>'success'));
						}
						else{
							echo json_encode(array('info'=>'error'));
						}
					}
					
					
				}
				
			  break;
			  
			  case 'frm_profile':
				
					if($action=='insert'){ 
				
							if ($this->form_validation->run($page) == FALSE) {
								echo json_encode($this->form_validation->error_array()); 
							}
							else
							{
							
								 #Extract form data
								 $val='';
								 $post = $this->input->post();
								 $post['user_firstname']=ucfirst($post['user_firstname']);
								 $post['user_lastname']=ucfirst($post['user_lastname']);
								 $bio['home_address']=$post['home_address'];
								 $bio['company']=ucfirst($post['company']);
								 $bio['about_user']=$post['about_user'];
								 if(!empty($post['public'])){ $bio['public']=$post['public'];}
								 $bio['facebook']=$post['facebook'];
								 $bio['twitter']=$post['twitter'];
								 $bio['linkedin']=$post['linkedin'];
								 $bio['google']=$post['google'];
								 $bio['skype']=$post['skype'];
								 $user_id=$this->session->userdata('user_id');
								 
								$user_dob=$post['user_dob'];
								if(!empty($post['user_dob'])){
									$keywords = explode('/',$user_dob);
									$mm=trim($keywords[0]);
									$dd=trim($keywords[1]);
									$yy=trim($keywords[2]);
									$post['user_dob']=$yy.'-'.$mm.'-'.$dd;
								}
					
								unset($post['q']);
								unset($post['title']);
								unset($post['reset-email_add']);
								unset($post['cid']);
								unset($post['campus_name']);
								unset($post['location']);
								unset($post['description']);
								unset($post['home_address']);unset($post['company']);unset($post['about_user']);unset($post['public']);
								unset($post['facebook']);unset($post['twitter']);unset($post['linkedin']);unset($post['google']);unset($post['skype']);
								
								//echo json_encode(array('info'=>$post));
								if($val = $this->account_model->_update($post,'tbl_users','user_id',$user_id)){
										
									if(!empty($bio['public'])){
										$bio['public']=1;
									}
									else{
										$bio['public']=0;
									}
									
									#update user biodata
									//echo json_encode(array('info'=>$bio));
									if($val = $this->account_model->_update($bio,'tbl_users_bio','user_id',$user_id)){
										
										$notes=array('title'=>'Updated Personal Profile','description'=>'You updated your person bio data. To check on the changes click on the header.','type'=>'user','user_id'=>$this->session->userdata('user_id'));
										
										#Update Notifications
										$rec=$this->account_model->select_table('tbl_notifications','*'," WHERE title='Updated Personal Profile!'",'row');
										if(!$rec){
											$val = $this->account_model->_insert($notes,'tbl_notifications');
										}
									}
								}
								
								/************ output message ************************/
								if($val){
									 echo json_encode(array('info'=>'success'));
								}
								else{
									echo json_encode(array('info'=>'error'));
								}
							}
						
					}else if($action=='insert_social'){ 
						
						 #Extract form data
						 $val='';
						 $post = $this->input->post();
						 $user_id=$this->session->userdata('user_id');

						 if($val = $this->account_model->_update($post,'tbl_users_bio','user_id',$user_id)){
								#Notification
								$notes=array('title'=>'Updated Social Media!','description'=>'You updated your social media links as specified on Update Date column.','type'=>'user_social','user_id'=>$this->session->userdata('user_id'));
								$val = $this->account_model->_insert($notes,'tbl_notifications');
						 }
						
						/************ output message ************************/
						if($val){
							 echo json_encode(array('info'=>'success'));
						}
						else{
							echo json_encode(array('info'=>'error'));
						}
					}else if($action=='insert_pic'){ 
							#Get form input
							$post = $this->input->post();
							$user_id=$this->session->userdata('user_id');
							
							//echo json_encode(array('info'=>$user_id));
							if($user_id){
								
									#Populate Staff images
									$status = "";
									$msg = "";
									$file_element_name = 'userfile1';
									$targetPath = "";
									
									$config['upload_path'] = './uploads/profile/';
									$config['allowed_types'] = 'gif|jpg|png|jpeg|bnp';
									$config['max_size'] = 1024 * 8;
									$config['max_width'] = '1024';
									$config['max_height'] = '768';
									$config['remove_spaces'] = FALSE;
									$config['overwrite'] = TRUE;							 	
									$this->load->library('upload', $config);
									
									#Specify upload parameters
									//$upload = $this->upload->do_upload('userfile1');
									if (!$this->upload->do_upload('userfile1')){
										 echo json_encode(array('error_image' => $this->upload->display_errors()));
										 die();
									}else{
											
											/* Get the data about the file */
											$data = $this->upload->data();
											$uploadedFiles = $data;
											
											$targetPath = "uploads/profile/".$_FILES['userfile1']['name'];
											$file['file_name']=$data['file_name'];
											$file['file_type']=$data['file_type'];
											$file['file_size']=$data['file_size'];
											$file['path']=$targetPath;
											$file['user_id']=$user_id;
											
											//echo json_encode(array('info'=>$file));
											//echo json_encode(array('info'=>$file));
											if(!$rec=$this->account_model->select_table('tbl_users_bio','*'," WHERE user_id=".$user_id." ",'result')){
													$val = $this->account_model->_insert($file,'tbl_users_bio');
													if(!$val)
													{
														$error='image_error';
													}else{
														
														#Notification
														$notes=array('title'=>'Updated Profile Pic!','description'=>'You updated your profile picture as specified on Update Date column.','type'=>'user_pic','user_id'=>$this->session->userdata('user_id'));
														$val = $this->account_model->_insert($notes,'tbl_notifications');	
													}
											}else{
												
												if($val = $this->account_model->_update($file,'tbl_users_bio','user_id',$user_id)){
														#Notification
														$notes=array('title'=>'Updated Profile Pic!','description'=>'You updated your profile picture as specified on Update Date column.','type'=>'user_pic','user_id'=>$this->session->userdata('user_id'));
														$val = $this->account_model->_insert($notes,'tbl_notifications');
												}
											}
											//unlink($data['full_path']);
											//echo '<img src="'.base_url().$targetPath .'" width="100px" height="100px" alt=""/>';
										}
										@unlink($_FILES['userfile1']);
								  	}
									
									/************ output message ************************/
									if($val){
										echo json_encode(array('info'=>'success'));
									}
									else{
										echo json_encode(array('info'=>$error));
									}
					}else if($action=='insert_tasks'){ 
						
						 #Extract form data
						 $val='';
						 $post = $this->input->post();
						 $post['user_id']=$this->session->userdata('user_id');

						if ($this->form_validation->run('tasks') == FALSE) {
								echo json_encode($this->form_validation->error_array()); 
						}
						else
						{
							
						  	//echo json_encode(array('info'=>$post));
							if($val = $this->account_model->_insert($post,'tbl_tasks')){
								#Notification
								$notes=array('title'=>'Added Task!','description'=>'You Added a New task: '.$post['title'],'type'=>'user_tasks','user_id'=>$this->session->userdata('user_id'));
								$val = $this->account_model->_insert($notes,'tbl_notifications');
							}
						 
							/************ output message ************************/
							if($val){
								 echo json_encode(array('info'=>'success'));
							}
							else{
								echo json_encode(array('info'=>'error'));
							}
						}
						
						
					}
					
			  break;
			 
			 case 'frm_roles':
			    
				$post = $this->input->post();
				if ($post == false) {
					echo json_encode(array('info' => 'warning'));
				} else {
					$this->form_validation->set_message('is_unique', 'Role Already exists in the system');
					if ($this->form_validation->run($page) == FALSE) {
						echo json_encode($this->form_validation->error_array());
					} else {
						 #Extract form data
						 #--------------------------------------------------------------------------------
						 $val='';
						 $post['role_name']=strtoupper($post['role_name']);
						 $post['role_description']=ucfirst($post['role_description']);
						 $post['created_by'] = $this->session->userdata('user_id'); //Get category by role
						
						if($action=='insert'){ 	
										 
							 unset($post['role_id']);
							 if($val = $this->account_model->_insert($post,'tbl_roles')){
								$this->account_model->log_user('Created new Role with Trans ID='.$val.', and Role Name: '.$post['role_name'],$this->session->userdata('id'));
							 }
						}else if($action=='update'){ 		
							unset($post['role_id']);
							if($val = $this->account_model->_update($post,'tbl_roles','role_id',$id)){
								$this->account_model->log_user('Updated Roles table- with Trans ID='.$id.' New value for name='.$post['role_name'].')',$this->session->userdata('id'));
							}
						}
					
					
						#*********** output message ***********************
						if($val){
							 echo json_encode(array('info'=>'success'));
						}
						else{
							echo json_encode(array('info'=>'error'));
						}
					}
				}
				
			  break;
			  
			  
			  
			default :
                $page = 'frm_modules';
                break;
 		}
	}
   
 	
	#Delete Record
	public function delete_form($page='',$id,$msg='',$email='') {

		switch($page)
    	 {
			case 'frm_modules':
			
				#Delete array
				$delete = array('mod_id' => $id);
				
            	if($val = $this->account_model->_delete($delete,'tbl_modules')){
				 	echo json_encode(array('info'=>'success'));
		 		}else{
					echo json_encode(array('info'=>'error'));
				}
				
            break;
			
			case 'frm_applications':
			
				#Delete array
				$delete = array('app_id' => $id);
				
            	if($val = $this->account_model->_delete($delete,'tbl_applications')){
				 	echo json_encode(array('info'=>'success'));
		 		}else{
					echo json_encode(array('info'=>'error'));
				}
					
            break;
			
			case 'frm_sub_applications':
			
				#Delete array
				$delete = array('sub_id' => $id);
				
				if($val = $this->account_model->_delete($delete,'tbl_sub_applications')){
				 	echo json_encode(array('info'=>'success'));
		 		}else{
					echo json_encode(array('info'=>'error'));
				}
					
            break;
			
			case 'frm_users':
			
				#Delete array
				$delete = array('user_id' => $id);
				$val='';
				
				if($msg=='activate'){
					$post=array('active' => 2,'banned' => 0);
					$val = $this->account_model->_update($post,'tbl_users','user_id',$id);
					
				}else if($msg=='deactivate'){
					$post=array('active' => 0,'banned' => 0);
					$val = $this->account_model->_update($post,'tbl_users','user_id',$id);
				}else if($msg=='ban'){
					$post=array('banned' => 1,'active' => 3,'ban_message' => 'user');
					$val = $this->account_model->_update($post,'tbl_users','user_id',$id);
				}else if($msg=='delete'){
					
					$row=$this->account_model->select_table('tbl_users','user_email'," WHERE user_id=".$id,'row');
					$email=$row->user_email;
					$email= $this->authme_model->hash($email);
					
					$post=array('deleted' => 1,'active' => 4,'isPredefined' => 1,'user_email'=>$email);
					$val = $this->account_model->_update($post,'tbl_users','user_id',$id);
					
				}else if($msg=='restore'){
					
					$row=$this->account_model->select_table('tbl_users','user_email'," WHERE user_id=".$id,'row');
					$email=$row->user_email;
					//$email= $this->account_model->unhash($email,$email);
					
					$post=array('deleted' => 0,'user_email'=>$email);
					$val = $this->account_model->_update($post,'tbl_users','user_id',$id);
				}else if($msg=='purge'){
					$val = $this->account_model->_delete($delete,'tbl_users');
				}
				
				if($val){
				 	echo json_encode(array('info'=>'success'));
		 		}else{
					echo json_encode(array('info'=>'error'));
				}
				
            break;
										
			default :
                $page = '';
                break;
 		}
	}
	
	#Function to loaad datatable
	public function datatable($page="",$cademic_year="",$val='',$inst="")
    {
		 $can_edit='';
		 $can_delete='';
		  
		 switch($page)
    	 {
			 case 'frmModules':
			
				$role_id =$this->session->userdata('role_id'); //Get category by role
				//$url="".$this->uri->segment(1)."/".$this->uri->segment(2)."/".$this->uri->segment(3)."";
				$url="account/index/frmModules";
				$perm=$this->account_model->select_table('tbl_modules a inner join tbl_applications b on(a.mod_id=b.mod_id)
inner join tbl_sub_applications c on(c.app_id=b.app_id) inner join tbl_permissions  d on(c.sub_id=d.sub_id)  inner join tbl_role_perm  e on(d.perm_id=e.perm_id)',' a.mod_id,a.mod_name,b.app_id,c.sub_id,c.app_id id,c.sub_name,c.sub_type,c.controller,d.can_view,d.can_add, d.can_edit,d.can_delete'," where d.can_view=1 and d.access_type='sub applications' and e.role_id=".$role_id." and c.controller='".trim($url)."'",'row');
			
				#Fetch Data and Display on Grid
				$this->datatables->select('b.role_id,a.is_predefined,a.mod_id,a.mod_name,a.mod_desc,a.mod_class,CONCAT(b.user_firstname, " ", b.user_lastname) AS name',FALSE)
				->unset_column('b.role_id')
				->unset_column('a.is_predefined')
				->add_column('Actions',  '$1', 'get_button(a.mod_id, a.is_predefined,"frm_modules","'.$perm->can_edit.'-'.$perm->can_delete.'")')
				->from('tbl_modules a')
				->join('tbl_users b','a.created_by=b.user_id');
        
        		echo $this->datatables->generate();
            break;
				
			case 'frm_applications':
				
				$role_id =$this->session->userdata('role_id'); //Get category by role
				//$url="".$this->uri->segment(1)."/".$this->uri->segment(2)."/".$this->uri->segment(3)."";
				$url="account/index/frm_applications";
				$perm=$this->account_model->select_table('tbl_modules a inner join tbl_applications b on(a.mod_id=b.mod_id)
inner join tbl_sub_applications c on(c.app_id=b.app_id) inner join tbl_permissions  d on(c.sub_id=d.sub_id)  inner join tbl_role_perm  e on(d.perm_id=e.perm_id)',' a.mod_id,a.mod_name,b.app_id,c.sub_id,c.app_id id,c.sub_name,c.sub_type,c.controller,d.can_view,d.can_add, d.can_edit,d.can_delete'," where d.can_view=1 and d.access_type='sub applications' and e.role_id=".$role_id." and c.controller='".trim($url)."'",'row');
				$this->datatables->select('c.role_id,b.is_predefined, b.app_id, a.mod_name, b.app_name, b.app_desc, b.controller, CONCAT(c.user_firstname, " ", c.user_lastname) AS name',FALSE)
				->unset_column('c.role_id')
				->unset_column('b.is_predefined')
				->add_column('Actions',  '$1', 'get_button(b.app_id, b.is_predefined,"frm_applications","'.$perm->can_edit.'-'.$perm->can_delete.'")')
				->from('tbl_modules a')
				->join('tbl_applications b','a.mod_id=b.mod_id')
				->join('tbl_users c','b.created_by=c.user_id');
				//->order_by("mod_name", "asc"); 
        
        		echo $this->datatables->generate();
            break;
			
			case 'frm_sub_applications':
			
				$role_id =$this->session->userdata('role_id'); //Get category by role
				//$url="".$this->uri->segment(1)."/".$this->uri->segment(2)."/".$this->uri->segment(3)."";
				$url="account/index/frm_sub_applications";
				$perm=$this->account_model->select_table('tbl_modules a inner join tbl_applications b on(a.mod_id=b.mod_id)
inner join tbl_sub_applications c on(c.app_id=b.app_id) inner join tbl_permissions  d on(c.sub_id=d.sub_id)  inner join tbl_role_perm  e on(d.perm_id=e.perm_id)',' a.mod_id,a.mod_name,b.app_id,c.sub_id,c.app_id id,c.sub_name,c.sub_type,c.controller,d.can_view,d.can_add, d.can_edit,d.can_delete'," where d.can_view=1 and d.access_type='sub applications' and e.role_id=".$role_id." and c.controller='".trim($url)."'",'row');

				$this->datatables->select('c.role_id,b.is_predefined, b.sub_id, a.app_name, b.sub_name, b.sub_desc, b.controller, CONCAT(c.user_firstname, " ", c.user_lastname) AS name',FALSE)
				->unset_column('c.role_id')
				->unset_column('b.is_predefined')
				->add_column('Actions',  '$1', 'get_button(b.sub_id, b.is_predefined,"frm_sub_applications","'.$perm->can_edit.'-'.$perm->can_delete.'")')
				->from('tbl_applications a')
				->join('tbl_sub_applications b','a.app_id=b.app_id')
				->join('tbl_users c','b.created_by=c.user_id');
				//->order_by("mod_name", "asc"); 
        
        		echo $this->datatables->generate();
                break;
				
			case 'frm_roles':
				$this->datatables->select('a.role_id,a.role_name,count(b.role_id) users,a.role_description,a.is_predefined',FALSE)
				->unset_column('a.role_id')
				->unset_column('a.is_predefined')
				->edit_column('a.role_name',  '$1', 'get_label(a.role_id, a.role_name)')
				->add_column('Actions',  '$1', 'get_button(a.role_id, a.is_predefined,"frm_roles")')
				->from('tbl_roles a')
				->join('tbl_users b','a.role_id=b.role_id','left')
				->group_by("a.role_name");
        
        		echo $this->datatables->generate();
             break;
			
			case 'frm_users':
			
				$role=$this->session->userdata('role_id');
				
				if($val=='all'){
					$array=array('a.deleted'=>0);
				}else if($val=='inactive'){
					$array=array('a.active'=>0,'a.deleted'=>0);
				}else if($val=='banned'){
					$array=array('a.banned'=>1,'a.deleted'=>0);
				}else if($val=='deleted'){
					$array=array('a.deleted'=>1);
				}
				
				 $this->datatables->select('a.user_id,a.role_id,a.isPredefined,CONCAT(a.user_firstname, " ", a.user_lastname) AS name,b.role_name,a.user_gender,DATE_FORMAT(a.user_dob,"%D-%b-%Y") AS user_dob, a.user_country, a.first_time,a.user_mobile, a.user_email, DATE_FORMAT(a.last_login,"%D-%b-%Y %r ") as last_login,a.active',FALSE)
				->unset_column('a.role_id')
				->unset_column('a.isPredefined')
				->edit_column('a.active',  '$1', 'get_status(a.active,"frm_users","status")')
				->add_column('Actions',  '$1', 'get_button(a.user_id,a.isPredefined,"frm_users","'.$val.'")')
				->from('tbl_users a')
				->join('tbl_roles b','a.role_id=b.role_id');
  				//->where($array);
				
        		echo $this->datatables->generate();
				
            break;
			
							
			default :
                $page = '';
                break;
 		}
        
    }
	
	
	#Retrieve values for update
    public function getById($id,$page="",$option1='') {
				
		switch($page)
    	 {
			case 'frm_modules':
				if( isset( $id ) ){
					echo json_encode( $this->account_model->getById( 'mod_id',$id,'tbl_modules','WHERE mod_id='.$id) );
				}
            break;
			
			case 'frm_applications':
				if( isset( $id ) ){
					echo json_encode( $this->account_model->getById( 'app_id',$id,'tbl_applications','WHERE app_id='.$id) );
				}
            break;
			
			case 'frm_sub_applications':
				if( isset( $id ) ){
					echo json_encode( $this->account_model->getById( 'sub_id',$id,'tbl_sub_applications','WHERE sub_id='.$id) );
				}
            break;
			
				
		   case 'frm_roles':
				if( isset( $id ) ){
					$field='role_id';
					echo json_encode( $this->account_model->getById( $field,$id,'tbl_roles','WHERE role_id='.$id) );
				}
           break;
		   
		   case 'tbl_permissions':
				if( isset( $id ) ){
					$field='perm_id';
					echo json_encode( $this->account_model->getById( $field,$id,'tbl_permissions','WHERE perm_id='.$id) );
				}
           break;
		   
		  
			default :
                $page = '';
                break;
 		}
	}
	
	#Function to display views
	function displayMain($page,$data=''){
		
		if(!logged_in()) $this->auth_lib->signOut();	
		
		if ( ! file_exists('application/views/admin_view/'.$page.'.php'))
		{
			// Whoops, we don't have a page for that!
			show_404();
		}
		
		#Sessions
		//////////////////////////////////////////////////////////////////////////////////////////////////////////
		$role_id =$this->session->userdata('role_id'); //Get category by role
		$url="".$this->uri->segment(1)."/".$this->uri->segment(2)."/".$this->uri->segment(3)."";
		
		# Load View
		#---------------------------------------------------------------------------------
		$data['title'] = 'ABS  | DashBoard';
		$data['class']='true';
		$data['header'] = 'auth_view/partials/header_admin'; // Load top header view
		$data['top_bar'] = ''; // Load top header view
		$data['side_menu'] = 'auth_view/partials/side_menu'; //'auth_view/partials/admin_menu'; // Load top header view
		
		$data['content'] = 'admin_view/'.$page; // Load content view
		$data['footer'] = 'auth_view/partials/footer_admin'; // Load footer view
			
					
		//////////////////////////////////////////////////////////////////////////////////////////////////
		$data['notifications']=$this->account_model->select_table('tbl_notifications','distinct id,title,description,active,type,created_on',' where user_id='.$this->session->userdata('user_id').' AND active=1 ','result');
		$rec=$this->account_model->select_table('tbl_notifications','count(*) count',' where user_id='.$this->session->userdata('user_id').' AND active=1 ','row');
		$data['count_notifications']=$rec->count;
		
		#Messages
		$data['messages']=$this->account_model->select_table('tbl_users a inner join tbl_messages b on(a.user_id=b.useridfrom) left join tbl_users_bio c on(c.user_id=b.useridfrom) inner join tbl_roles d on(a.role_id=d.role_id)','a.user_firstname, a.user_lastname, b.id, b.useridfrom, b.useridto, b.subject, b.smallmessage, b.fullmessage, b.notification, c.pass_path, d.role_name',' where b.useridto='.$this->session->userdata('user_id').' AND b.active=0 ','result');
		$rec=$this->account_model->select_table('tbl_messages','count(*) count',' where useridto='.$this->session->userdata('user_id').' AND active=0 ','row');
		$data['count_messages']=$rec->count;
		
		#Generate Menu
		#----------------------------------------------------------------------
		#1. Get Modules
		$data['modules']=$this->account_model->select_table('tbl_modules a inner join tbl_permissions  b on(a.mod_id=b.mod_id) inner join tbl_role_perm  c on(b.perm_id=c.perm_id)','a.mod_id,a.mod_name,a.mod_controller,a.mod_class,a.tab_class,a.tab_id,b.name,b.mod_id id'," Where c.role_id=".$this->session->userdata('role_id')." AND b.access_type='module' AND b.can_view=1",'result');
		//var_dump($data['modules']);
		
		#Bio Data
		$data['bio']=$this->account_model->select_table('tbl_users_bio','*'," WHERE user_id=".$this->session->userdata('user_id'),'row');
			
		#Start Evaluation				
		switch($page){
		
			case "index":
			
				#Get profile Data
				$data['profile']=$this->account_model->select_table('tbl_users a left join  tbl_users_bio b on(a.user_id=b.user_id)  left join cre_counties c on(c.county_code=b.county)','a.user_firstname,a.user_lastname,a.user_gender, DATE_FORMAT(a.user_dob,"%m/%d/%Y") user_dob, a.user_city, a.user_country ,a.user_mobile, a.user_email, 
DATE_FORMAT(a.last_login,"%D-%b-%Y %r") last_login,DATE_FORMAT(a.created_on,"%D-%b-%Y") created_on, b.staff_title, b.telephone, b.box_no, b.postal_code, b.town, b.home_address, b.user_marital, b.idnumber, b.county, c.county_name, b.const_code, b.ward, b.company, b.about_user, b.public, b.facebook, b.twitter, b.google, b.linkedin, b.skype, b.yahoo, b.website, b.pass_file_name,b.pass_file_type,b.pass_file_size,b.pass_path,b.type'," where a.user_id=".$this->session->userdata('user_id'),'result');
				
						
				#Visitors
				$data['visitors']=$this->account_model->select_table('tbl_users','count(*) count'," WHERE online=1 AND user_id=".$this->session->userdata('user_id'),'result');
				
				#Applications
				$data['online']=$this->account_model->select_table('tbl_users','online'," WHERE user_id=".$this->session->userdata('user_id'),'result');
				$data['notify']=$this->account_model->select_table('tbl_notifications','active'," WHERE user_id=".$this->session->userdata('user_id')."  AND active=1",'result');
				
				$posts=array('online'=>0);
				$val = $this->account_model->_update($posts,'tbl_users','user_id',$this->session->userdata('user_id'));
				
				$rec=$this->account_model->select_table('tbl_users a inner join  tbl_institution_det b on(a.user_id=b.user_id)','b.location'," where b.user_id=".$this->session->userdata('user_id'),'row');
				
				if(empty($rec->location)){
					$data['profiles']=0;
				}else{
					$data['profiles']=1;
				}
				
				if($this->session->userdata('role_id')==2){
					$data['title'] = 'ADMINISTRATOR Portal';
					
				}else if($this->session->userdata('role_id')==3){
					$data['title'] = 'INSTITUTIONS Portal';
				}else if($this->session->userdata('role_id')==7){
					$data['title'] = 'Employers Portal';
				}else if($this->session->userdata('role_id')==8){
					$data['title'] = 'Advertisers Portal';
				}else{
					$data['title'] = 'Students Portal';
				}				
			
				#Load Views
				#----------------------------------------------------------------------------------
				$data['title'] = 'ABS | DashBoard';	
				
				
			break;
			
			case "frm_profile":	
							
				$role_id =$this->session->userdata('role_id'); //Get category by role
				$url="".$this->uri->segment(1)."/".$this->uri->segment(2)."/".$this->uri->segment(3)."";
				
				$data['perm']=$this->account_model->select_table('tbl_modules a inner join  tbl_applications b on(a.mod_id=b.mod_id) inner join tbl_permissions  d on(b.app_id=d.app_id)  inner join tbl_role_perm  e on(d.perm_id=e.perm_id)','a.mod_id,a.mod_name,b.app_id,d.can_view,d.can_add, d.can_edit,d.can_delete'," where d.access_type='applications' and e.role_id=".$role_id." and b.controller='".trim($url)."'",'result');
				
				foreach($data['perm'] as $row){
					
					if($row->can_view==0 || empty($row->can_view)){
						$data['content'] = 'admin_view/404_page'; // Load content view
					}
				}

				#Get profile Data
				$data['profile']=$this->account_model->select_table('tbl_users a left join  tbl_users_bio b on(a.user_id=b.user_id) left join cre_countries c on(a.user_country=c.id)','a.user_firstname,a.user_lastname,a.user_middlename,a.user_gender,DATE_FORMAT(a.user_dob,"%m/%d/%Y") user_dob, a.user_city, a.user_country ,c.countryname,a.user_mobile, a.user_email, DATE_FORMAT(a.last_login,"%D-%b-%Y %r") last_login,DATE_FORMAT(a.created_on,"%D-%b-%Y") created_on, b.staff_title, b.telephone, b.box_no, b.postal_code, b.town, b.home_address, b.user_marital, b.idnumber, b.county,  b.const_code, b.ward, b.company, b.about_user, b.public, b.facebook, b.twitter, b.google, b.linkedin, b.skype, b.yahoo, b.website, b.pass_file_name,b.pass_file_type,b.pass_file_size,b.pass_path,b.type'," where a.user_id=".$this->session->userdata('user_id'),'row');

				//var_dump($data['profile']);
				
				$data['title'] = 'ABS | My Profile';
				$data['header'] = 'auth_view/partials/header_admin'; // Load top header view
				$data['footer_js'] = 'auth_view/partials/footer_profile'; // Load footer view*/
						
			break;
			
			case "frm_reports":				
				$tmpl = array ( 'table_open'  => '<table id="big_table" class="display table table-bordered table-striped">' );
				$this->table->set_template($tmpl);         
				$this->table->set_heading('#','Module Name','Description','Mod Class','Created By','Actions');
				
				$data['title'] = 'ABS | Manage Reports';
				$data['class']='stickyheader leftpanel-collapsed';
				$data['footer'] = 'auth_view/partials/footer_table'; // Load footer view
			break;
			
			
			case "frm_reports":				
				$tmpl = array ( 'table_open'  => '<table id="big_table" class="display table table-bordered table-striped">' );
				$this->table->set_template($tmpl);         
				$this->table->set_heading('#','Module Name','Description','Mod Class','Created By','Actions');
				
				$data['title'] = 'ABS | Register';
				$data['header'] = 'auth_view/partials/header_admin'; // Load top header view
				$data['footer_js'] = 'auth_view/partials/footer_register'; // Load footer view*/
			break;
			
			
			default:
			
				$page="";
				break;
		}
		$this->load->view('admin_template',$data,false);

	}
	
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */