<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');  
/* 
| ------------------------------------------------------------------- 
| EMAIL CONFIG 
| ------------------------------------------------------------------- 
| Configuration of outgoing mail server. 
| */   
//$config['protocol']='sendmail';  
/*$config['smtp_host']='portal.helb.co.ke';  
$config['smtp_port']='465';  
$config['smtp_timeout']='60';  
$config['smtp_user']='wallace@dotsavvyafrica.com';  
$config['smtp_pass']='Sweet2991';*/
//$config['mailpath']='/usr/sbin/sendmail';
//$config['mailtype']='html';
//$config['smtp_crypto'] = 'ssl';
//$config['charset']='utf-8';  
//$config['newline']="\r\n";  
$config['protocol'] = 'smtp';


$config['smtp_host']    = '192.168.1.87';
$config['smtp_port']    = '25';
$config['smtp_timeout'] = '60';

//$config['charset'] = 'utf-8'; 
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['newline']    = "\r\n";
$config['mailtype'] = 'text'; // or html
$config['validation'] = TRUE; // bool whether to validate email or not
  
/* End of file email.php */  
/* Location: /application/config/email.php */ 
