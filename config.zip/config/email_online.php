<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');  
/* 
| ------------------------------------------------------------------- 
| EMAIL CONFIG 
| ------------------------------------------------------------------- 
| Configuration of outgoing mail server. 
| */   
$config['protocol'] = 'smtp';
//$config['smtp_host']    = 'mail.opriansystems.com';
//$config['smtp_host']    = 'www.opriansystems.com';
$config['smtp_host']    = '192.185.115.190';
$config['smtp_port']    = '25';
$config['smtp_timeout'] = '60';

//$config['charset'] = 'utf-8'; 
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
$config['newline']    = "\r\n";
$config['mailtype'] = 'text'; // or html
$config['validation'] = TRUE; // bool whether to validate email or not
  
/* End of file email.php */  
/* Location: /application/config/email.php */ 
